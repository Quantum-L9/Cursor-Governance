# L9_META
#   l9_schema: 1
#   repo: Quantum-L9/l9-graphiti-memory
#   path: src/l9_graphite_memory/services/memory_service.py
#   layer: service
#   owner: memory-control-plane
#   status: active
#   version: 2.2.0
#   updated: 2026-07-22

"""Single canonical service for reads, writes, hydration, locks, and curation."""

from __future__ import annotations

from datetime import timedelta
from uuid import UUID, uuid4

from l9_graphite_memory.admission import AdmissionEngine, normalize_candidate
from l9_graphite_memory.admission.normalization import (
    NormalizationResult,
    canonical_json,
    sha256_text,
)
from l9_graphite_memory.authz import NamespacePolicy
from l9_graphite_memory.contracts import (
    AdmissionDecision,
    ArchiveReceipt,
    AuthorizationAction,
    AuthorizationReceipt,
    CloseReceipt,
    CloseRequest,
    Confidence,
    ConflictItem,
    ConflictLinkReceipt,
    ConflictReport,
    DeletionReceipt,
    DeletionRequest,
    DeletionStatus,
    EvidenceKind,
    EvidenceRef,
    HealthReport,
    HydrationRequest,
    HydrationResult,
    LifecycleTransition,
    LifecycleTransitionReceipt,
    MemoryClass,
    MemoryPrincipal,
    MemoryRecord,
    MemorySearchRequest,
    MemoryState,
    MemoryStatusEvent,
    MemoryWriteRequest,
    OperationStatus,
    OutboxEvent,
    PhaseLockReceipt,
    PhaseLockRequest,
    PhaseLockVerification,
    ProjectionRebuildReceipt,
    PromotionRequest,
    Provenance,
    QuarantineReviewVerdict,
    QuarantineVerdict,
    RetentionReceipt,
    SearchReceipt,
    TemporalCoordinates,
    WriteReceipt,
    WriteStatus,
)
from l9_graphite_memory.curation import (
    PromotionPolicy,
    RetentionEngine,
    RetentionPolicy,
)
from l9_graphite_memory.errors import (
    AdmissionError,
    AuthorizationError,
    IdempotencyConflict,
    StoreError,
)
from l9_graphite_memory.lineage import LineageReplay, LineageReplayer
from l9_graphite_memory.ports import (
    SERVICE_WRITE_CAPABILITY,
    Clock,
    ProjectionAdapter,
    RecordStore,
    SystemClock,
)
from l9_graphite_memory.ports.phase_lock import PhaseLockPrecondition, snapshot_digest
from l9_graphite_memory.retrieval import ContextBudgetAllocator, RetrievalPlanner
from l9_graphite_memory.version import MEMORY_SCHEMA_VERSION, PACKAGE_VERSION

#: Lifecycle states a new record may supersede. A record in review, or one a
#: verified deletion has already tombstoned, is not current truth that a
#: successor can replace: superseding it would move a quarantined candidate out
#: of review without approval, or contradict a COMPLETE deletion receipt.
_SUPERSEDABLE_STATES: frozenset[MemoryState] = frozenset(
    {MemoryState.ACTIVE, MemoryState.SUPERSEDED, MemoryState.ARCHIVED}
)

#: Governed lifecycle transitions and the least authority each requires.
#: Anything not listed is refused: deletion and rejection have their own
#: paths and receipts, and this method must not become a back door around
#: them. Releasing a quarantined record needs ADMIN unless a review verdict
#: that clears the review policy accompanies it, in which case MAINTAIN
#: suffices and the verdict is recorded as evidence (ADR-080).
_LIFECYCLE_TRANSITIONS: dict[tuple[MemoryState, MemoryState], AuthorizationAction] = {
    (MemoryState.ACTIVE, MemoryState.SUPERSEDED): AuthorizationAction.MAINTAIN,
    (MemoryState.ACTIVE, MemoryState.ARCHIVED): AuthorizationAction.MAINTAIN,
    (MemoryState.SUPERSEDED, MemoryState.ARCHIVED): AuthorizationAction.MAINTAIN,
    (MemoryState.SUPERSEDED, MemoryState.ACTIVE): AuthorizationAction.ADMIN,
    (MemoryState.ARCHIVED, MemoryState.ACTIVE): AuthorizationAction.ADMIN,
    (MemoryState.QUARANTINED, MemoryState.ACTIVE): AuthorizationAction.ADMIN,
}


class MemoryService:
    """The only production-authorized path into canonical memory state."""

    def __init__(
        self,
        store: RecordStore,
        projection: ProjectionAdapter,
        *,
        namespace_policy: NamespacePolicy | None = None,
        admission: AdmissionEngine | None = None,
        clock: Clock | None = None,
        retrieval: RetrievalPlanner | None = None,
        budget_allocator: ContextBudgetAllocator | None = None,
        promotion_policy: PromotionPolicy | None = None,
        retention_policy: RetentionPolicy | None = None,
        retention_engine: RetentionEngine | None = None,
        projection_required: bool = False,
    ) -> None:
        self.store = store
        self.projection = projection
        self.namespace_policy = namespace_policy or NamespacePolicy()
        self.admission = admission or AdmissionEngine()
        self.clock = clock or SystemClock()
        self.retrieval = retrieval or RetrievalPlanner(
            store,
            projection,
            projection_required=projection_required,
        )
        self.budget_allocator = budget_allocator or ContextBudgetAllocator()
        self.promotion_policy = promotion_policy or PromotionPolicy()
        self.retention_policy = retention_policy or RetentionPolicy()
        self.retention_engine = retention_engine or RetentionEngine(self.retention_policy)
        self.lineage_replayer = LineageReplayer(store)

    def initialize(self) -> None:
        self.store.initialize()

    @staticmethod
    def _operation_identity(request: MemoryWriteRequest) -> str:
        """Resolve the retry identity of this write, never its meaning.

        An explicit ``idempotency_key`` names the operation, so a retry of that
        operation collapses onto the same record. Without one, each call is a
        distinct operation and is admitted on its own merits even when another
        record already holds identical content. The semantic digest is recorded
        on the record as a maintenance candidate signal and never governs
        admission (ADR-071).
        """

        return request.idempotency_key or f"operation:{request.namespace}:{uuid4()}"

    def write(self, principal: MemoryPrincipal, request: MemoryWriteRequest) -> WriteReceipt:
        """Admit a new memory under the caller's WRITE grant."""

        return self._admit(principal, request, action=AuthorizationAction.WRITE)

    def _admit(
        self,
        principal: MemoryPrincipal,
        request: MemoryWriteRequest,
        *,
        action: AuthorizationAction,
        expected_phase_lock: PhaseLockPrecondition | None = None,
    ) -> WriteReceipt:
        """Single admission implementation behind an explicit authority gate.

        ``action`` names which grant admits this record. Ingestion uses WRITE.
        Scheduled maintenance uses MAINTAIN, so a nightly principal can derive
        consolidated memories from records the store already holds without
        gaining the authority to ingest new source material (ADR-075).
        """

        authorization = self.namespace_policy.evaluate(
            principal,
            action,
            request.namespace,
        )
        normalization = normalize_candidate(
            request.content,
            context={
                "namespace": request.namespace,
                "memory_class": request.memory_class.value,
                "assertion": request.assertion.model_dump(mode="json")
                if request.assertion
                else None,
                "consent_id": str(request.consent.consent_id) if request.consent else None,
            },
        )
        idempotency_key = self._operation_identity(request)
        existing = (
            self.store.find_by_idempotency(
                principal.tenant_id,
                request.namespace,
                idempotency_key,
            )
            if request.idempotency_key
            else None
        )
        admission = self.admission.evaluate(
            request,
            normalization,
            authorization,
            duplicate_record_exists=existing is not None,
        )

        if admission.status is WriteStatus.DUPLICATE:
            if existing is None:
                raise StoreError("admission reported duplicate but store returned no record")
            return self._duplicate_receipt(
                request, existing, normalization, admission, authorization, idempotency_key
            )

        if admission.status is WriteStatus.REJECTED:
            receipt = WriteReceipt(
                status=WriteStatus.REJECTED,
                namespace=request.namespace,
                schema_version=MEMORY_SCHEMA_VERSION,
                normalized_digest=normalization.normalized_digest,
                original_digest=normalization.original_digest,
                idempotency_key=idempotency_key,
                idempotency_key_supplied=request.idempotency_key is not None,
                admission=admission,
                authorization=authorization,
                warnings=admission.warnings,
            )
            if not request.dry_run:
                self.store.commit_write(SERVICE_WRITE_CAPABILITY, None, receipt)
            return receipt

        now = self.clock.now()
        state = (
            MemoryState.QUARANTINED
            if admission.status is WriteStatus.QUARANTINED
            else MemoryState.ACTIVE
        )
        temporal = TemporalCoordinates(
            valid_from=request.valid_from,
            valid_to=request.valid_to,
            recorded_at=now,
            source_observed_at=request.source_observed_at,
        )
        record = MemoryRecord(
            tenant_id=principal.tenant_id,
            namespace=request.namespace,
            memory_class=request.memory_class,
            content=normalization.redacted_content,
            assertion=request.assertion,
            temporal=temporal,
            provenance=request.provenance,
            evidence=request.evidence,
            confidence=request.confidence,
            state=state,
            tags=request.tags,
            metadata={
                **request.metadata,
                "pii_redacted": bool(normalization.pii_types),
                "pii_types": list(normalization.pii_types),
                "safety_signals": list(normalization.safety_signals),
            },
            normalized_digest=normalization.normalized_digest,
            original_digest=normalization.original_digest,
            idempotency_key=idempotency_key,
            supersedes=request.supersedes,
            references=request.references,
            consent=request.consent,
            created_by=principal.audit_subject,
            created_at=now,
        )
        warnings = list(admission.warnings)
        effective_supersedes = request.supersedes if state is MemoryState.ACTIVE else ()
        if request.supersedes and state is MemoryState.QUARANTINED:
            warnings.append("supersession deferred until the quarantined candidate is approved")

        status_events: list[MemoryStatusEvent] = []
        for record_id in effective_supersedes:
            prior = self.store.get_record(record_id)
            if prior is None:
                raise StoreError(f"superseded record does not exist: {record_id}")
            if prior.tenant_id != principal.tenant_id or prior.namespace != request.namespace:
                raise AuthorizationError(
                    "cannot supersede a record outside the authorized tenant and namespace"
                )
            if prior.state not in _SUPERSEDABLE_STATES:
                raise AdmissionError(
                    f"cannot supersede record {record_id} in state {prior.state.value}; "
                    "only active, superseded, or archived records carry truth a "
                    "successor can replace"
                )
            status_events.append(
                MemoryStatusEvent(
                    record_id=record_id,
                    previous_state=prior.state,
                    new_state=MemoryState.SUPERSEDED,
                    reason=f"superseded by {record.record_id}",
                    actor=principal.audit_subject,
                    occurred_at=now,
                )
            )

        outbox_events: tuple[OutboxEvent, ...] = ()
        if state is MemoryState.ACTIVE and self.projection.name != "none":
            events = [
                OutboxEvent(
                    event_type="memory.record.project",
                    aggregate_id=record.record_id,
                    namespace=record.namespace,
                    payload={
                        "record_id": str(record.record_id),
                        "schema_version": record.schema_version,
                    },
                    created_at=now,
                    next_attempt_at=now,
                )
            ]
            # A superseded record must stop being projected, or retrieval keeps
            # surfacing truth the canonical store has already replaced. The
            # retirement intent commits in the same transaction as the
            # supersession itself, so the two cannot diverge (ADR-074).
            events.extend(
                OutboxEvent(
                    event_type="memory.record.retire",
                    aggregate_id=superseded_id,
                    namespace=record.namespace,
                    payload={
                        "record_id": str(superseded_id),
                        "reason": f"superseded by {record.record_id}",
                        "superseded_by": str(record.record_id),
                    },
                    created_at=now,
                    next_attempt_at=now,
                )
                for superseded_id in effective_supersedes
            )
            outbox_events = tuple(events)

        receipt = WriteReceipt(
            status=admission.status,
            record_id=record.record_id,
            namespace=record.namespace,
            schema_version=record.schema_version,
            normalized_digest=record.normalized_digest,
            original_digest=record.original_digest,
            idempotency_key=record.idempotency_key,
            idempotency_key_supplied=request.idempotency_key is not None,
            admission=admission,
            authorization=authorization,
            outbox_event_ids=tuple(event.event_id for event in outbox_events),
            superseded_record_ids=effective_supersedes,
            warnings=tuple(warnings),
            created_at=now,
        )
        initial_reason = (
            "record quarantined by admission policy"
            if state is MemoryState.QUARANTINED
            else "record admitted and supersedes prior records"
            if effective_supersedes
            else "record admitted by admission policy"
        )
        initial_event = MemoryStatusEvent(
            record_id=record.record_id,
            previous_state=None,
            new_state=state,
            reason=initial_reason,
            actor=principal.audit_subject,
            occurred_at=now,
            receipt_id=receipt.receipt_id,
        )
        status_events = [
            initial_event,
            *(
                event.model_copy(update={"receipt_id": receipt.receipt_id})
                for event in status_events
            ),
        ]
        if not request.dry_run:
            try:
                self.store.commit_write(
                    SERVICE_WRITE_CAPABILITY,
                    record,
                    receipt,
                    outbox_events=outbox_events,
                    status_events=tuple(status_events),
                    expected_phase_lock=expected_phase_lock,
                )
            except IdempotencyConflict as exc:
                # A retry of this operation won the race between our duplicate
                # lookup and our commit. The unique index is the authority; the
                # outcome is the same DUPLICATE receipt the lookup would have
                # produced had it run a moment later (ADR-008).
                if request.idempotency_key is None:
                    raise StoreError(
                        "minted operation identity collided, which cannot happen"
                    ) from exc
                winner = self.store.find_by_idempotency(
                    principal.tenant_id, request.namespace, idempotency_key
                )
                if winner is None:
                    raise StoreError(
                        "idempotency conflict reported but the winning record is not readable"
                    ) from exc
                duplicate = self.admission.evaluate(
                    request, normalization, authorization, duplicate_record_exists=True
                )
                return self._duplicate_receipt(
                    request, winner, normalization, duplicate, authorization, idempotency_key
                )
        return receipt

    def _duplicate_receipt(
        self,
        request: MemoryWriteRequest,
        existing: MemoryRecord,
        normalization: NormalizationResult,
        admission: AdmissionDecision,
        authorization: AuthorizationReceipt,
        idempotency_key: str,
    ) -> WriteReceipt:
        """Receipt for a replayed operation, naming any payload drift.

        An explicit key says "same operation". When the replay carries different
        content, class, assertion, or consent, the caller sent two different
        things under one retry identity. The original record stays authoritative
        and nothing is overwritten, but the receipt says so instead of implying
        the second payload was stored.
        """

        warnings = list(admission.warnings)
        if existing.normalized_digest != normalization.normalized_digest:
            warnings.append(
                "idempotent replay payload differs from the stored record "
                f"(stored digest {existing.normalized_digest[:12]}, "
                f"replay digest {normalization.normalized_digest[:12]}); "
                "the original record remains authoritative"
            )
        receipt = WriteReceipt(
            status=WriteStatus.DUPLICATE,
            record_id=existing.record_id,
            namespace=request.namespace,
            schema_version=existing.schema_version,
            normalized_digest=normalization.normalized_digest,
            original_digest=normalization.original_digest,
            idempotency_key=idempotency_key,
            idempotency_key_supplied=request.idempotency_key is not None,
            admission=admission,
            authorization=authorization,
            warnings=tuple(warnings),
        )
        if not request.dry_run:
            self.store.commit_write(SERVICE_WRITE_CAPABILITY, None, receipt)
        return receipt

    def transition_lifecycle(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        *,
        record_ids: tuple[UUID, ...],
        new_state: MemoryState,
        reason: str,
        review: QuarantineReviewVerdict | None = None,
        evidence: tuple[EvidenceRef, ...] = (),
    ) -> LifecycleTransitionReceipt:
        """Move already-canonical records between lifecycle states, with receipt.

        This is the only production path for a lifecycle change that is not
        itself a write, an archive by retention, or a verified deletion. Each
        transition is checked against the governed table: maintenance may
        supersede or archive current records under MAINTAIN, and governance may
        restore a superseded or archived record to active under ADMIN. The
        status events, the receipt, and the projection intent the transition
        implies -- retirement when a record stops being current, projection when
        it becomes current again -- commit in one transaction (ADR-074).

        Releasing a quarantined record is governance unless ``review`` carries
        a RELEASE verdict for that exact record with no blocker, in which case
        the release is a maintenance act and the verdict is recorded as
        evidence on the receipt (ADR-080). A verdict that is anything but a
        clean RELEASE never lowers the authority required.
        """

        if not record_ids:
            raise AdmissionError("lifecycle transition requires at least one record")
        now = self.clock.now()
        transitions: list[LifecycleTransition] = []
        status_events: list[MemoryStatusEvent] = []
        required: set[AuthorizationAction] = set()
        evidence_items: list[EvidenceRef] = list(evidence)
        for record_id in dict.fromkeys(record_ids):
            record = self.store.get_record(record_id)
            if record is None:
                raise StoreError(f"record not found: {record_id}")
            if record.tenant_id != principal.tenant_id or record.namespace != namespace:
                raise AuthorizationError(
                    "lifecycle transition target is outside the authorized tenant or namespace"
                )
            action = _LIFECYCLE_TRANSITIONS.get((record.state, new_state))
            if action is None:
                raise AdmissionError(
                    f"lifecycle transition {record.state.value} -> {new_state.value} is not "
                    f"governed by this path: {record_id}"
                )
            if record.state is MemoryState.QUARANTINED and review is not None:
                if review.record_id != record_id:
                    raise AdmissionError(
                        f"review verdict is for record {review.record_id}, not {record_id}"
                    )
                if review.verdict is not QuarantineVerdict.RELEASE or review.requires_human:
                    raise AdmissionError(
                        f"review verdict {review.verdict.value} does not authorize releasing "
                        f"{record_id} from quarantine"
                    )
                action = AuthorizationAction.MAINTAIN
                evidence_items.append(
                    EvidenceRef(
                        kind=EvidenceKind.INFERENCE,
                        description=review.summary()[:2_000],
                        source_id=review.reviewer,
                        observed_at=review.reviewed_at,
                    )
                )
            required.add(action)
            transitions.append(
                LifecycleTransition(
                    record_id=record_id, previous_state=record.state, new_state=new_state
                )
            )
            status_events.append(
                MemoryStatusEvent(
                    record_id=record_id,
                    previous_state=record.state,
                    new_state=new_state,
                    reason=reason,
                    actor=principal.audit_subject,
                    occurred_at=now,
                )
            )
        authorization = self.namespace_policy.require(
            principal, AuthorizationAction.READ, namespace
        )
        for action in sorted(required, key=lambda item: item.value):
            authorization = self.namespace_policy.require(principal, action, namespace)

        outbox_events: tuple[OutboxEvent, ...] = ()
        if self.projection.name != "none":
            if new_state is MemoryState.ACTIVE:
                outbox_events = tuple(
                    OutboxEvent(
                        event_type="memory.record.project",
                        aggregate_id=item.record_id,
                        namespace=namespace,
                        payload={
                            "record_id": str(item.record_id),
                            "reason": reason,
                            "reactivated": True,
                        },
                        created_at=now,
                        next_attempt_at=now,
                    )
                    for item in transitions
                )
            else:
                outbox_events = tuple(
                    OutboxEvent(
                        event_type="memory.record.retire",
                        aggregate_id=item.record_id,
                        namespace=namespace,
                        payload={"record_id": str(item.record_id), "reason": reason},
                        created_at=now,
                        next_attempt_at=now,
                    )
                    for item in transitions
                )
        receipt = LifecycleTransitionReceipt(
            namespace=namespace,
            transitions=tuple(transitions),
            authorization=authorization,
            outbox_event_ids=tuple(event.event_id for event in outbox_events),
            reason=reason,
            actor=principal.audit_subject,
            evidence=tuple(evidence_items),
            created_at=now,
        )
        self.store.commit_lifecycle(
            SERVICE_WRITE_CAPABILITY,
            receipt,
            status_events=tuple(
                event.model_copy(update={"receipt_id": receipt.receipt_id})
                for event in status_events
            ),
            outbox_events=outbox_events,
        )
        return receipt

    def write_governed(
        self,
        principal: MemoryPrincipal,
        request: MemoryWriteRequest,
        *,
        task_signature: str,
    ) -> WriteReceipt:
        verification = self.verify_phase_lock(principal, request.namespace, task_signature)
        if not verification.valid:
            raise AuthorizationError(
                "memory.write_governed requires a held phase-lock: "
                + "; ".join(verification.reasons)
            )
        # This check is advisory on its own: the namespace can change between
        # here and the commit. The store re-verifies the same digest inside the
        # transaction that admits the record and refuses the write if it moved,
        # which is what actually closes the window (ADR-079).
        return self._admit(
            principal,
            request,
            action=AuthorizationAction.WRITE,
            expected_phase_lock=PhaseLockPrecondition(
                tenant_id=principal.tenant_id,
                namespace=request.namespace,
                expected_snapshot_digest=verification.current_snapshot_digest,
            ),
        )

    def close(self, principal: MemoryPrincipal, request: CloseRequest) -> CloseReceipt:
        write_receipt = self.write(
            principal,
            MemoryWriteRequest(
                namespace=request.namespace,
                memory_class=MemoryClass.META,
                content=request.summary,
                provenance=Provenance(
                    source="memory.close",
                    source_agent_id=principal.agent_id,
                    tool="memory.close",
                    extraction_method="session-close/v1",
                    source_trust=1.0,
                ),
                evidence=(
                    EvidenceRef(
                        kind=EvidenceKind.EXPLICIT,
                        description="authenticated caller committed session close through MemoryService",
                        source_id=principal.audit_subject,
                    ),
                ),
                tags=("session-close", "async-work-obligation"),
                metadata={
                    "close": True,
                    "session_id": request.session_id,
                    "capsule_digest": request.capsule_digest,
                    "graphiti_accepted": False,
                },
                idempotency_key=request.idempotency_key,
                dry_run=request.dry_run,
            ),
        )
        replayed = False
        replay_payload_matched: bool | None = None
        stored_digest: str | None = None
        if write_receipt.status is WriteStatus.DUPLICATE:
            # The caller replayed a close it already committed under this
            # key. Exactly one logical close exists; report it as complete
            # and name the first record rather than failing the retry or
            # minting a second close (ADR-082). Whether the replay carried
            # the same payload is evidence the caller needs: the stored
            # record stays authoritative either way, but a drifted retry
            # means the retry identity was reused for a different operation.
            status = OperationStatus.COMPLETE
            record_id = write_receipt.record_id
            replayed = True
            stored = self.store.get_record(record_id) if record_id is not None else None
            stored_digest = stored.normalized_digest if stored is not None else None
            replay_payload_matched = (
                stored_digest == write_receipt.normalized_digest
                if stored_digest is not None
                else None
            )
        elif write_receipt.status is not WriteStatus.ADMITTED:
            status = OperationStatus.FAILED
            record_id = write_receipt.record_id
        elif request.dry_run:
            # A dry run passes admission but deliberately skips commit_write, so
            # no record exists. Reporting COMPLETE with a record id would tell a
            # close consumer that session state is canonically durable when it
            # is not; PARTIAL with no record id is what actually happened.
            status = OperationStatus.PARTIAL
            record_id = None
        else:
            status = OperationStatus.COMPLETE
            record_id = write_receipt.record_id
        return CloseReceipt(
            status=status,
            namespace=request.namespace,
            write_receipt_id=write_receipt.receipt_id,
            record_id=record_id,
            graphiti_accepted=False,
            replayed=replayed,
            replay_payload_matched=replay_payload_matched,
            stored_digest=stored_digest,
            replay_digest=write_receipt.normalized_digest if replayed else None,
            warnings=write_receipt.warnings,
            authorization=write_receipt.authorization,
        )

    def get(self, principal: MemoryPrincipal, record_id: UUID) -> MemoryRecord | None:
        record = self.store.get_record(record_id)
        if record is None:
            return None
        if record.tenant_id != principal.tenant_id and not principal.can_cross_tenant:
            raise AuthorizationError("record belongs to a different tenant")
        self.namespace_policy.require(principal, AuthorizationAction.READ, record.namespace)
        if record.state is MemoryState.QUARANTINED and not principal.is_admin:
            raise AuthorizationError("quarantined records require administrator authority")
        if (
            record.state in {MemoryState.DELETION_PENDING, MemoryState.DELETED}
            and not principal.is_admin
        ):
            raise AuthorizationError("deleted records require administrator authority")
        return record

    @staticmethod
    def _concrete_namespaces(patterns: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(
            pattern for pattern in patterns if not any(character in pattern for character in "*?[]")
        )

    def _authorized_search_namespaces(
        self,
        principal: MemoryPrincipal,
        requested: tuple[str, ...],
    ) -> tuple[str, ...]:
        namespaces = requested or self._concrete_namespaces(principal.read_namespaces)
        if not namespaces:
            raise AuthorizationError(
                "explicit namespace is required when read grants contain only wildcards"
            )
        for namespace in namespaces:
            self.namespace_policy.require(principal, AuthorizationAction.READ, namespace)
        return tuple(dict.fromkeys(namespaces))

    def search(self, principal: MemoryPrincipal, request: MemorySearchRequest) -> SearchReceipt:
        namespaces = self._authorized_search_namespaces(principal, request.namespaces)
        now = self.clock.now()
        effective_request = (
            request
            if request.recorded_before is not None
            else request.model_copy(update={"recorded_before": now})
        )
        return self.retrieval.search(
            principal.tenant_id,
            effective_request,
            namespaces,
            now=now,
        )

    def hydrate(self, principal: MemoryPrincipal, request: HydrationRequest) -> HydrationResult:
        query_parts = [request.task, *request.entities, *request.topics]
        search_request = MemorySearchRequest(
            query=" ".join(part for part in query_parts if part),
            namespaces=request.namespaces,
            memory_classes=request.memory_classes,
            valid_at=request.valid_at,
            limit=request.max_records,
            token_budget=request.token_budget,
            tags=request.tags,
        )
        search = self.search(principal, search_request)
        return self.budget_allocator.allocate(
            search, task=request.task, token_budget=request.token_budget
        )

    @staticmethod
    def _overlaps(left: MemoryRecord, right: MemoryRecord) -> bool:
        left_end = left.temporal.valid_to
        right_end = right.temporal.valid_to
        return (left_end is None or right.temporal.valid_from < left_end) and (
            right_end is None or left.temporal.valid_from < right_end
        )

    @staticmethod
    def _snapshot_digest(records: tuple[MemoryRecord, ...] | list[MemoryRecord]) -> str:
        # Delegates so the service and every store adapter digest a namespace
        # identically; the stores re-verify this value inside their own
        # committing transaction (ADR-079).
        return snapshot_digest(records)

    def conflicts(self, principal: MemoryPrincipal, namespace: str) -> ConflictReport:
        self.namespace_policy.require(principal, AuthorizationAction.READ, namespace)
        # Unbounded on purpose: the stores re-verify the phase-lock snapshot
        # over every active record in the namespace, so a bounded listing here
        # would make the two digests disagree once the namespace outgrew the
        # bound and refuse every governed write (ADR-079).
        records = self.store.list_records(
            principal.tenant_id,
            namespace,
            states=(MemoryState.ACTIVE,),
            limit=None,
        )
        # A conflict is a link that governed reconciliation wrote onto both
        # records (ADR-081). Reading the links is the whole cost of the report,
        # so a phase lock or a promotion check does not re-derive every
        # contradiction in the namespace on each call. A link is live only
        # while both sides are active: superseding or archiving either side
        # resolves it without anyone editing the link.
        active_by_id = {record.record_id: record for record in records}
        conflicts: list[ConflictItem] = []
        seen: set[tuple[UUID, UUID]] = set()
        for left in sorted(records, key=lambda item: str(item.record_id)):
            for right_id in left.conflicts_with:
                right = active_by_id.get(right_id)
                if right is None:
                    continue
                pair = tuple(sorted((left.record_id, right_id), key=str))
                if pair in seen:
                    continue
                seen.add((pair[0], pair[1]))
                assertion = left.assertion or right.assertion
                conflicts.append(
                    ConflictItem(
                        left_record_id=pair[0],
                        right_record_id=pair[1],
                        subject=assertion.subject if assertion else None,
                        predicate=assertion.predicate if assertion else None,
                        reason="records are linked as contradicting by governed reconciliation",
                    )
                )
        return ConflictReport(
            namespace=namespace,
            conflicts=tuple(conflicts),
            checked_record_count=len(records),
            snapshot_digest=self._snapshot_digest(records),
            checked_at=self.clock.now(),
        )

    def link_conflicts(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        *,
        links: tuple[ConflictItem, ...],
        reason: str,
    ) -> ConflictLinkReceipt:
        """Record that pairs of active records contradict each other (ADR-081).

        Reconciliation identifies contradictions it must not resolve; this is
        how it makes them durable. Both sides of every link must be active
        records of this tenant and namespace. Pairs already linked are not
        written again, so a rerun is a no-op that still returns a receipt.
        """

        authorization = self.namespace_policy.require(
            principal, AuthorizationAction.MAINTAIN, namespace
        )
        fresh: list[ConflictItem] = []
        seen: set[tuple[UUID, UUID]] = set()
        for link in links:
            if link.left_record_id == link.right_record_id:
                raise AdmissionError(f"a record cannot conflict with itself: {link.left_record_id}")
            pair = tuple(sorted((link.left_record_id, link.right_record_id), key=str))
            if pair in seen:
                continue
            seen.add((pair[0], pair[1]))
            sides = []
            for record_id in pair:
                record = self.store.get_record(record_id)
                if record is None:
                    raise StoreError(f"conflict link target not found: {record_id}")
                if record.tenant_id != principal.tenant_id or record.namespace != namespace:
                    raise AuthorizationError(
                        "conflict link target is outside the authorized tenant or namespace"
                    )
                if record.state is not MemoryState.ACTIVE:
                    raise AdmissionError(
                        f"only active records can be linked as conflicting; {record_id} is "
                        f"{record.state.value}"
                    )
                sides.append(record)
            if pair[1] in sides[0].conflicts_with and pair[0] in sides[1].conflicts_with:
                continue
            fresh.append(link)
        now = self.clock.now()
        receipt = ConflictLinkReceipt(
            namespace=namespace,
            links=tuple(fresh),
            authorization=authorization,
            reason=reason,
            actor=principal.audit_subject,
            created_at=now,
        )
        if fresh:
            self.store.commit_conflict_links(SERVICE_WRITE_CAPABILITY, receipt)
        return receipt

    def phase_lock(self, principal: MemoryPrincipal, request: PhaseLockRequest) -> PhaseLockReceipt:
        self.namespace_policy.require(principal, AuthorizationAction.WRITE, request.namespace)
        report = self.conflicts(principal, request.namespace)
        now = self.clock.now()
        receipt = PhaseLockReceipt(
            tenant_id=principal.tenant_id,
            namespace=request.namespace,
            task_signature=request.task_signature,
            granted=report.status is OperationStatus.COMPLETE and not report.has_conflicts,
            conflict_report=report,
            snapshot_digest=report.snapshot_digest,
            expires_at=now + timedelta(seconds=request.ttl_seconds),
            principal_id=principal.principal_id,
            created_at=now,
        )
        self.store.save_phase_lock(SERVICE_WRITE_CAPABILITY, receipt)
        return receipt

    def verify_phase_lock(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        task_signature: str,
    ) -> PhaseLockVerification:
        self.namespace_policy.require(principal, AuthorizationAction.READ, namespace)
        now = self.clock.now()
        lock = self.store.get_phase_lock(principal.tenant_id, namespace, task_signature)
        report = self.conflicts(principal, namespace)
        reasons: list[str] = []
        if lock is None:
            reasons.append("phase lock does not exist")
        else:
            if not lock.granted:
                reasons.append("phase lock was not granted")
            if lock.principal_id != principal.principal_id and not principal.is_admin:
                reasons.append("phase lock belongs to a different principal")
            if lock.expires_at <= now:
                reasons.append("phase lock expired")
            if lock.snapshot_digest != report.snapshot_digest:
                reasons.append("namespace changed after phase lock issuance")
            if report.has_conflicts:
                reasons.append("current namespace contains conflicts")
        return PhaseLockVerification(
            lock_id=lock.lock_id if lock else None,
            namespace=namespace,
            task_signature=task_signature,
            valid=not reasons,
            reasons=tuple(reasons or ["phase lock is current and conflict-free"]),
            current_snapshot_digest=report.snapshot_digest,
            verified_at=now,
        )

    def lineage(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        record_id: UUID,
    ) -> LineageReplay:
        self.namespace_policy.require(principal, AuthorizationAction.READ, namespace)
        record = self.store.get_record(record_id)
        if record is None:
            raise StoreError(f"record not found: {record_id}")
        if record.tenant_id != principal.tenant_id or record.namespace != namespace:
            raise AuthorizationError("record is outside the authorized tenant or namespace")
        return self.lineage_replayer.replay(principal.tenant_id, namespace, record_id)

    def promote(self, principal: MemoryPrincipal, request: PromotionRequest) -> WriteReceipt:
        record = self.get(principal, request.record_id)
        if record is None:
            raise StoreError(f"record not found: {request.record_id}")
        self.namespace_policy.require(principal, AuthorizationAction.PROMOTE, record.namespace)
        for supporting_id in request.supporting_record_ids:
            supporting = self.store.get_record(supporting_id)
            if supporting is None:
                raise StoreError(f"supporting record not found: {supporting_id}")
            if (
                supporting.tenant_id != principal.tenant_id
                or supporting.namespace != record.namespace
            ):
                raise AuthorizationError("promotion support crosses tenant or namespace boundary")
        conflict_report = self.conflicts(principal, record.namespace)
        if conflict_report.has_conflicts and not request.governance_approval:
            raise AuthorizationError("promotion denied while unresolved conflicts exist")
        decision = self.promotion_policy.evaluate(record, request)
        if not decision.approved:
            raise AuthorizationError("promotion denied: " + "; ".join(decision.reasons))
        evidence = list(record.evidence)
        if request.governance_approval:
            evidence.append(
                EvidenceRef(
                    kind=EvidenceKind.GOVERNANCE_APPROVAL,
                    description=request.reason,
                    source_id=principal.audit_subject,
                )
            )
        provenance = Provenance(
            source="memory-promotion",
            source_id=str(record.record_id),
            source_digest=record.normalized_digest,
            source_agent_id=principal.agent_id,
            extraction_method=decision.policy_version,
        )
        write_request = MemoryWriteRequest(
            namespace=record.namespace,
            memory_class=request.target_class,
            content=record.content,
            assertion=record.assertion,
            provenance=provenance,
            evidence=tuple(evidence),
            confidence=record.confidence,
            valid_from=record.temporal.valid_from,
            valid_to=record.temporal.valid_to,
            source_observed_at=record.temporal.source_observed_at,
            tags=tuple({*record.tags, "promoted"}),
            metadata={
                **record.metadata,
                "promotion_policy": decision.policy_version,
                "promotion_reasons": list(decision.reasons),
            },
            idempotency_key=f"promotion:{record.record_id}:{request.target_class.value}",
            supersedes=(record.record_id,),
            references=tuple(dict.fromkeys((*request.supporting_record_ids, record.record_id))),
            consent=request.consent or record.consent,
        )
        return self.write(principal, write_request)

    def apply_retention(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        *,
        apply: bool,
    ) -> RetentionReceipt:
        authorization = self.namespace_policy.require(
            principal,
            AuthorizationAction.ARCHIVE if apply else AuthorizationAction.READ,
            namespace,
        )
        now = self.clock.now()
        records = tuple(
            self.store.list_records(
                principal.tenant_id,
                namespace,
                states=(MemoryState.ACTIVE, MemoryState.SUPERSEDED),
                limit=100_000,
            )
        )
        decisions = self.retention_engine.evaluate(records, now=now)
        archived_ids = tuple(
            decision.record_id for decision in decisions if decision.action == "archive"
        )
        archive_receipt = ArchiveReceipt(
            namespace=namespace,
            applied=apply,
            archived_record_ids=archived_ids,
            authorization=authorization,
            reason=f"reference-aware retention under {self.retention_policy.policy_version}",
            actor=principal.audit_subject,
            created_at=now,
        )
        if apply and archived_ids:
            by_id = {record.record_id: record for record in records}
            status_events = tuple(
                MemoryStatusEvent(
                    record_id=record_id,
                    previous_state=by_id[record_id].state,
                    new_state=MemoryState.ARCHIVED,
                    reason=archive_receipt.reason,
                    actor=principal.audit_subject,
                    occurred_at=now,
                    receipt_id=archive_receipt.receipt_id,
                )
                for record_id in archived_ids
            )
            # Archiving withdraws the record from active retrieval, so its
            # projection must be withdrawn too. This is retirement, not privacy
            # erasure: the canonical content is preserved (ADR-074).
            retire_events = (
                tuple(
                    OutboxEvent(
                        event_type="memory.record.retire",
                        aggregate_id=record_id,
                        namespace=namespace,
                        payload={
                            "record_id": str(record_id),
                            "reason": archive_receipt.reason,
                            "archive_receipt_id": str(archive_receipt.receipt_id),
                        },
                        created_at=now,
                        next_attempt_at=now,
                    )
                    for record_id in archived_ids
                )
                if self.projection.name != "none"
                else ()
            )
            self.store.commit_archive(
                SERVICE_WRITE_CAPABILITY,
                archive_receipt,
                status_events=status_events,
                outbox_events=retire_events,
            )
        return RetentionReceipt(
            namespace=namespace,
            applied=apply,
            decisions=decisions,
            archive_receipt=archive_receipt,
            created_at=now,
        )

    def delete(self, principal: MemoryPrincipal, request: DeletionRequest) -> DeletionReceipt:
        record = self.store.get_record(request.record_id)
        if record is None:
            raise StoreError(f"record not found: {request.record_id}")
        if record.tenant_id != principal.tenant_id and not principal.can_cross_tenant:
            raise AuthorizationError("deletion target belongs to a different tenant")
        authorization = self.namespace_policy.require(
            principal,
            AuthorizationAction.ADMIN,
            record.namespace,
        )
        if record.state in {MemoryState.DELETION_PENDING, MemoryState.DELETED}:
            # A second request would mint a second tombstone, receipt, and
            # erase event over content that is already gone. The first receipt
            # is the deletion's evidence; a pending erasure completes through
            # the outbox on its own.
            raise AdmissionError(
                f"record {record.record_id} is already {record.state.value}; "
                "verified deletion was recorded once and is not repeated"
            )
        now = self.clock.now()
        tombstone_digest = sha256_text(
            canonical_json(
                {
                    "record_id": str(record.record_id),
                    "tenant_id": record.tenant_id,
                    "namespace": record.namespace,
                    "reason_digest": sha256_text(request.reason),
                    "verification_reference_digest": sha256_text(request.verification_reference),
                    "requested_by": principal.audit_subject,
                    "requested_at": now,
                }
            )
        )
        if request.dry_run:
            return DeletionReceipt(
                record_id=record.record_id,
                namespace=record.namespace,
                status=DeletionStatus.DRY_RUN,
                tombstone_digest=tombstone_digest,
                authorization=authorization,
                reason=request.reason,
                verification_reference=request.verification_reference,
                requested_by=principal.audit_subject,
                created_at=now,
            )

        projection_enabled = self.projection.name != "none"
        event = (
            OutboxEvent(
                event_type="memory.record.erase",
                aggregate_id=record.record_id,
                namespace=record.namespace,
                payload={},
                created_at=now,
                next_attempt_at=now,
            )
            if projection_enabled
            else None
        )
        status = (
            DeletionStatus.PENDING_PROJECTION if projection_enabled else DeletionStatus.COMPLETE
        )
        receipt = DeletionReceipt(
            record_id=record.record_id,
            namespace=record.namespace,
            status=status,
            tombstone_digest=tombstone_digest,
            authorization=authorization,
            reason=request.reason,
            verification_reference=request.verification_reference,
            projection_event_id=event.event_id if event else None,
            requested_by=principal.audit_subject,
            created_at=now,
            completed_at=now if not projection_enabled else None,
        )
        if event is not None:
            event = event.model_copy(
                update={
                    "payload": {
                        "record_id": str(record.record_id),
                        "deletion_receipt_id": str(receipt.receipt_id),
                    }
                }
            )
        redacted_state = MemoryState.DELETION_PENDING if projection_enabled else MemoryState.DELETED
        redacted_record = record.model_copy(
            update={
                "content": f"[deleted:{receipt.tombstone_id}]",
                "assertion": None,
                "provenance": Provenance(
                    source="verified-deletion",
                    extraction_method="privacy-deletion/v1",
                    source_trust=1.0,
                    transformed_at=now,
                ),
                "evidence": (),
                "confidence": Confidence(score=0.0, evidence_count=0),
                "state": redacted_state,
                "tags": ("deleted", "privacy-tombstone"),
                "metadata": {
                    "tombstone_id": str(receipt.tombstone_id),
                    "tombstone_digest": tombstone_digest,
                    "deletion_receipt_id": str(receipt.receipt_id),
                },
                "normalized_digest": tombstone_digest,
                "original_digest": tombstone_digest,
                "consent": None,
            }
        )
        self.store.commit_deletion(
            SERVICE_WRITE_CAPABILITY,
            receipt,
            redacted_record,
            outbox_event=event,
            status_event=MemoryStatusEvent(
                record_id=record.record_id,
                previous_state=record.state,
                new_state=redacted_state,
                reason="verified deletion tombstoned the record",
                actor=principal.audit_subject,
                occurred_at=now,
                receipt_id=receipt.receipt_id,
            ),
        )
        return receipt

    def prune(self, principal: MemoryPrincipal, namespace: str, *, apply: bool) -> ArchiveReceipt:
        """Compatibility surface for archive-first retention."""

        return self.apply_retention(principal, namespace, apply=apply).archive_receipt

    def rebuild_projection(
        self,
        principal: MemoryPrincipal,
        namespace: str,
        *,
        apply: bool,
        limit: int = 1_000,
        reason: str = "projection rebuild",
    ) -> ProjectionRebuildReceipt:
        """Re-project active canonical records that have no live projection.

        Retirement under a withdraw-only provider removes the projected copy
        (ADR-076), so this is how it is undone: every active record without a
        projection link is queued for projection again. Projections are
        derivations, so rebuilding is always safe and never touches canonical
        state.
        """

        authorization = self.namespace_policy.require(
            principal,
            AuthorizationAction.MAINTAIN if apply else AuthorizationAction.READ,
            namespace,
        )
        if self.projection.name == "none":
            raise StoreError("projection backend is 'none'; there is nothing to rebuild")
        now = self.clock.now()
        candidates = self.store.list_unprojected_records(
            principal.tenant_id,
            namespace,
            self.projection.name,
            limit=limit,
        )
        total_active = len(
            self.store.list_records(
                principal.tenant_id,
                namespace,
                states=(MemoryState.ACTIVE,),
                limit=limit,
            )
        )
        events = tuple(
            OutboxEvent(
                event_type="memory.record.project",
                aggregate_id=record.record_id,
                namespace=namespace,
                payload={
                    "record_id": str(record.record_id),
                    "schema_version": record.schema_version,
                    "rebuild": True,
                },
                created_at=now,
                next_attempt_at=now,
            )
            for record in candidates
        )
        receipt = ProjectionRebuildReceipt(
            namespace=namespace,
            projection_name=self.projection.name,
            applied=apply,
            considered_record_count=total_active,
            already_projected_count=max(total_active - len(candidates), 0),
            queued_record_ids=tuple(record.record_id for record in candidates),
            outbox_event_ids=tuple(event.event_id for event in events),
            authorization=authorization,
            reason=reason,
            actor=principal.audit_subject,
            created_at=now,
        )
        if apply and events:
            self.store.commit_projection_rebuild(
                SERVICE_WRITE_CAPABILITY, receipt, outbox_events=events
            )
        return receipt

    def health(self) -> HealthReport:
        store_health = self.store.health()
        projection_health = self.projection.health()
        degraded: list[str] = []
        if not store_health.get("healthy"):
            status = OperationStatus.FAILED
            degraded.append("canonical store is unhealthy")
        elif self.projection.name != "none" and not projection_health.get("healthy"):
            status = OperationStatus.PARTIAL
            degraded.append("projection is unhealthy")
        else:
            status = OperationStatus.COMPLETE
        return HealthReport(
            status=status,
            package_version=PACKAGE_VERSION,
            schema_version=MEMORY_SCHEMA_VERSION,
            store=store_health,
            projection=projection_health,
            outbox_backlog=self.store.outbox_backlog(),
            degraded_reasons=tuple(degraded),
            checked_at=self.clock.now(),
        )

    def stats(self) -> dict[str, object]:
        return self.store.stats()
