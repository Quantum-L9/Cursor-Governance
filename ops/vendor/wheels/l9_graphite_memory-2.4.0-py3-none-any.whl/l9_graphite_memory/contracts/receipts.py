# L9_META
#   l9_schema: 1
#   repo: Quantum-L9/l9-graphiti-memory
#   path: src/l9_graphite_memory/contracts/receipts.py
#   layer: contract
#   owner: memory-control-plane
#   status: active
#   version: 2.2.0
#   updated: 2026-07-22

"""Evidence-bearing outcomes for every public memory operation."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from l9_graphite_memory.version import (
    ADMISSION_POLICY_VERSION,
    AUTHORIZATION_POLICY_VERSION,
    CONTROL_PLANE_CONTRACT_VERSION,
    PHASE_LOCK_POLICY_VERSION,
    RANKING_POLICY_VERSION,
    RETENTION_POLICY_VERSION,
)

from .enums import (
    AuthorizationAction,
    DeletionStatus,
    MemoryClass,
    MemoryState,
    OperationStatus,
    OutboxStatus,
    QueryPattern,
    WriteStatus,
)
from .evidence import EvidenceRef
from .memory import MemoryRecord
from .temporal import utc_now


class AuthorizationReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    principal_id: str
    action: AuthorizationAction
    namespace: str
    allowed: bool
    reasons: tuple[str, ...] = ()
    policy_version: str = AUTHORIZATION_POLICY_VERSION
    evaluated_at: datetime = Field(default_factory=utc_now)


class AdmissionDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    decision_id: UUID = Field(default_factory=uuid4)
    status: WriteStatus
    reasons: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    policy_version: str = ADMISSION_POLICY_VERSION
    candidate_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    evaluated_at: datetime = Field(default_factory=utc_now)


class WriteReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: WriteStatus
    record_id: UUID | None = None
    namespace: str
    schema_version: str
    normalized_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    original_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    idempotency_key: str
    idempotency_key_supplied: bool = False
    admission: AdmissionDecision
    authorization: AuthorizationReceipt
    outbox_event_ids: tuple[UUID, ...] = ()
    superseded_record_ids: tuple[UUID, ...] = ()
    warnings: tuple[str, ...] = ()
    created_at: datetime = Field(default_factory=utc_now)


class ArchiveReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus = OperationStatus.COMPLETE
    namespace: str
    applied: bool
    archived_record_ids: tuple[UUID, ...] = ()
    authorization: AuthorizationReceipt
    reason: str
    actor: str
    created_at: datetime = Field(default_factory=utc_now)


class LifecycleTransition(BaseModel):
    """One record moving between lifecycle states under governance."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    record_id: UUID
    previous_state: MemoryState
    new_state: MemoryState


class LifecycleTransitionReceipt(BaseModel):
    """Evidence for lifecycle transitions that are not part of a write.

    Supersession caused by a write is evidenced by the ``WriteReceipt``;
    archive by retention is evidenced by the ``ArchiveReceipt``. Every other
    governed transition -- maintenance superseding a replaced fact, maintenance
    archiving, governance restoring a withdrawn record to active -- commits
    under this receipt together with its status events and the projection
    intent the transition implies (ADR-074).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus = OperationStatus.COMPLETE
    namespace: str
    transitions: tuple[LifecycleTransition, ...]
    authorization: AuthorizationReceipt
    outbox_event_ids: tuple[UUID, ...] = ()
    reason: str = Field(min_length=1, max_length=2_000)
    actor: str = Field(min_length=1, max_length=400)
    #: What justified the transition beyond the actor's authority: the review
    #: verdict that released a quarantined record, for instance (ADR-080).
    evidence: tuple[EvidenceRef, ...] = ()
    created_at: datetime = Field(default_factory=utc_now)


class DeletionReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    tombstone_id: UUID = Field(default_factory=uuid4)
    record_id: UUID
    namespace: str
    status: DeletionStatus
    tombstone_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    authorization: AuthorizationReceipt
    reason: str
    verification_reference: str
    projection_event_id: UUID | None = None
    requested_by: str
    created_at: datetime = Field(default_factory=utc_now)
    completed_at: datetime | None = None


class ScoreFactors(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    lexical: float = Field(default=0.0, ge=0.0, le=1.0)
    projection: float = Field(default=0.0, ge=0.0, le=1.0)
    relevance: float = Field(default=0.0, ge=0.0, le=1.0)
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    trust: float = Field(default=0.0, ge=0.0, le=1.0)
    importance: float = Field(default=0.0, ge=0.0, le=1.0)
    recency: float = Field(default=0.0, ge=0.0, le=1.0)


class SearchHit(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    record: MemoryRecord
    score: float = Field(ge=0.0, le=1.0)
    factors: ScoreFactors
    matched_by: tuple[str, ...] = ()


class SearchReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus
    query: str
    namespaces_authorized: tuple[str, ...]
    # MEM-P2-01: the query alone does not identify the search. Every selector
    # below changes which records come back, so the receipt binds each one and
    # carries a digest over the whole normalized set — a consumer can then
    # prove these hits answer the request it made, rather than assuming it.
    # Values are the EFFECTIVE ones the planner filtered on (recorded_before
    # is resolved to the service clock when the caller left it open), because
    # a receipt that echoed the caller's blanks would prove nothing about what
    # actually ran.
    # Scalars are None when unstated, never a default that happens to look
    # like an answer: a consumer must be able to tell "memory did not bind
    # this" from "memory bound it, and it equals the default". Defaulting
    # `limit` to 0 would be worse than useless — it would read to the consumer
    # as a receipt CONTRADICTING the limit that was requested. Empty tuples
    # are different: an empty tag or class selector is a real, unfiltered
    # value, not an absence.
    tags: tuple[str, ...] = ()
    memory_classes: tuple[MemoryClass, ...] = ()
    limit: int | None = Field(default=None, ge=1)
    valid_at: datetime | None = None
    recorded_before: datetime | None = None
    include_superseded: bool | None = None
    include_archived: bool | None = None
    min_confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    selector_canonicalization: str | None = None
    request_digest: str | None = None
    hits: tuple[SearchHit, ...] = ()
    query_pattern: QueryPattern = QueryPattern.DEFAULT
    classification_reason: str = ""
    strategies_attempted: tuple[str, ...] = ()
    strategies_succeeded: tuple[str, ...] = ()
    strategies_failed: dict[str, str] = Field(default_factory=dict)
    stores_attempted: tuple[str, ...] = ()
    stores_succeeded: tuple[str, ...] = ()
    stores_failed: dict[str, str] = Field(default_factory=dict)
    ranking_policy_version: str = RANKING_POLICY_VERSION
    result_digest: str
    created_at: datetime = Field(default_factory=utc_now)


class ContextSection(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    memory_class: MemoryClass
    content: str
    record_ids: tuple[UUID, ...]
    tokens_estimated: int = Field(ge=0)
    highest_score: float = Field(ge=0.0, le=1.0)


class HydrationResult(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus
    task: str
    sections: tuple[ContextSection, ...] = ()
    token_budget: int
    tokens_used: int
    search_receipt_id: UUID
    result_digest: str
    warnings: tuple[str, ...] = ()
    created_at: datetime = Field(default_factory=utc_now)


class ConflictItem(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    left_record_id: UUID
    right_record_id: UUID
    subject: str | None = None
    predicate: str | None = None
    reason: str


class ConflictLinkReceipt(BaseModel):
    """Evidence that two active records were linked as contradicting each other.

    Reconciliation identifies the contradiction; governance resolves it later
    by superseding or archiving one side. Until then the link lives on both
    records' ``conflicts_with`` and is what the conflict report, phase locks,
    and promotion consult (ADR-081).
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus = OperationStatus.COMPLETE
    namespace: str
    links: tuple[ConflictItem, ...]
    authorization: AuthorizationReceipt
    reason: str = Field(min_length=1, max_length=2_000)
    actor: str = Field(min_length=1, max_length=400)
    created_at: datetime = Field(default_factory=utc_now)


class ConflictReport(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    namespace: str
    status: OperationStatus = OperationStatus.COMPLETE
    conflicts: tuple[ConflictItem, ...] = ()
    checked_record_count: int = Field(default=0, ge=0)
    snapshot_digest: str = Field(default="0" * 64, pattern=r"^[a-f0-9]{64}$")
    policy_version: str = PHASE_LOCK_POLICY_VERSION
    checked_at: datetime = Field(default_factory=utc_now)

    @property
    def has_conflicts(self) -> bool:
        return bool(self.conflicts)


class PhaseLockReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    lock_id: UUID = Field(default_factory=uuid4)
    tenant_id: str
    namespace: str
    task_signature: str
    granted: bool
    conflict_report: ConflictReport
    snapshot_digest: str = Field(default="0" * 64, pattern=r"^[a-f0-9]{64}$")
    expires_at: datetime
    principal_id: str
    policy_version: str = PHASE_LOCK_POLICY_VERSION
    created_at: datetime = Field(default_factory=utc_now)


class PhaseLockVerification(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    lock_id: UUID | None = None
    namespace: str
    task_signature: str
    valid: bool
    reasons: tuple[str, ...]
    current_snapshot_digest: str = Field(pattern=r"^[a-f0-9]{64}$")
    verified_at: datetime = Field(default_factory=utc_now)


class RetentionDecision(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    record_id: UUID
    action: str
    reason: str
    reference_count: int = Field(default=0, ge=0)
    decay_score: float = Field(default=1.0, ge=0.0, le=1.0)


class RetentionReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    namespace: str
    applied: bool
    decisions: tuple[RetentionDecision, ...]
    archive_receipt: ArchiveReceipt
    policy_version: str = RETENTION_POLICY_VERSION
    created_at: datetime = Field(default_factory=utc_now)


class OutboxEvent(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    event_id: UUID = Field(default_factory=uuid4)
    event_type: str
    aggregate_id: UUID
    namespace: str
    payload: dict[str, Any]
    status: OutboxStatus = OutboxStatus.PENDING
    attempts: int = Field(default=0, ge=0)
    next_attempt_at: datetime = Field(default_factory=utc_now)
    last_error: str | None = None
    created_at: datetime = Field(default_factory=utc_now)
    delivered_at: datetime | None = None
    # A PROCESSING claim is a time-bounded lease, not ownership in perpetuity.
    # A worker that dies mid-delivery leaves lease_expires_at in the past, and
    # the next claim cycle recovers the event (ADR-073).
    lease_id: UUID | None = None
    lease_owner: str | None = Field(default=None, max_length=200)
    lease_expires_at: datetime | None = None


class HealthReport(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    status: OperationStatus
    package_version: str
    schema_version: str
    # Consumers bind to this rather than to tool presence (ADR-082).
    contract_version: str = CONTROL_PLANE_CONTRACT_VERSION
    store: dict[str, Any]
    projection: dict[str, Any]
    gate: dict[str, Any] = Field(default_factory=lambda: {"name": "gate", "configured": False})
    outbox_backlog: int = Field(ge=0)
    degraded_reasons: tuple[str, ...] = ()
    checked_at: datetime = Field(default_factory=utc_now)


class CloseReceipt(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")

    receipt_id: UUID = Field(default_factory=uuid4)
    status: OperationStatus
    namespace: str
    write_receipt_id: UUID
    record_id: UUID | None = None
    graphiti_accepted: bool = False
    # True when the close was an idempotent replay: the record named is the
    # one the first close committed, and no second close record exists.
    replayed: bool = False
    # Replay forensics (ADR-082 amendment, audit P2-01). A replay under the
    # same key with a different payload keeps the first record authoritative;
    # the caller must be told that its retry carried a different operation
    # than the one that committed instead of reading ``replayed`` as "same".
    # ``None`` unless the close was a replay.
    replay_payload_matched: bool | None = None
    stored_digest: str | None = None
    replay_digest: str | None = None
    warnings: tuple[str, ...] = ()
    authorization: AuthorizationReceipt
    created_at: datetime = Field(default_factory=utc_now)
