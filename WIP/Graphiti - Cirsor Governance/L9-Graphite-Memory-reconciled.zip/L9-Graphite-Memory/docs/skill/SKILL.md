---
name: l9-graphiti-memory
description: Graphiti memory via Zep Cloud MCP — prefetch, group resolution, T0 memory-bank, episode writes, GMP Phase 0 MEMORY_PREFETCH. Use when wiring memory, debugging prefetch, bootstrap, or Graphiti health.
skill_schema: 1
layer: control_plane
role: skill_entrypoint
tags: [l9, graphiti, memory, prefetch, gmp, zep-cloud, infisical]
owner: igor_beylin
status: active
version: 2.0.0
updated: 2026-07-05
disable-model-invocation: false
---

# Graphiti Global Memory

## Purpose

Operate the Graphiti memory layer via Zep Cloud (T1/T2) with local **memory-bank/** (T0) as resume SSOT. Secrets from Infisical Universal Auth. Any MCP-compatible agent can connect.

## Feature Flags

| Env | Default | Meaning |
|-----|---------|---------|
| `GRAPHITI_MEMORY_ENABLED` | `0` | Master switch for prefetch + writes |
| `GRAPHITI_WRITE_GATES` | `0` | Fail-closed edit/shell/subagent gates |
| `GRAPHITI_TRANSPORT` | `zep` | Transport backend (`zep` or `http` for legacy opt-in) |
| `GRAPHITI_MEMORY_REQUIRED` | `0` | Hard-fail if memory unavailable (default: fail-soft) |

Secrets: Infisical vault via `load_secrets_sync()`. Bootstrap vars: `INFISICAL_CLIENT_ID`, `INFISICAL_CLIENT_SECRET`, `INFISICAL_PROJECT_ID`.

## CLI

```bash
l9-memory health
l9-memory resolve
l9-memory search "query" --limit 5
l9-memory conflicts
l9-memory phase-lock
l9-memory inject "current task"
l9-memory write --body "..." --kind lesson
l9-memory bootstrap --dry-run
l9-memory stats
```

Or via Python module:

```bash
python -m l9_graphite_memory.graphiti_memory_client health
```

## Session Lifecycle

1. **sessionStart** — MCP server boots, `load_secrets_sync()` fetches credentials, prefetch runs.
2. **Resume** — read `memory-bank/activeContext.md` first; then cite prefetch episode names.
3. **sessionEnd** — `graphiti-session-end.sh` writes T0 distill to memory-bank.

## GMP Phase 0

Run `conflicts` then `phase-lock` before GMP file edits when gates on:

```bash
l9-memory conflicts
l9-memory phase-lock
```

## Gate Activation

See `docs/GATES-ACTIVATION.md`. Flip `GRAPHITI_WRITE_GATES=1` only after soak checklist passes.

## Wiring Verify

```bash
bash scripts/preflight.sh
bash tests/test_gate_e2e_full.sh
```

## Authority

1. `rules/03-graphiti-memory.mdc`
2. `docs/MEMORY_BANK_POLICY.md`
3. `config/group_registry.yaml`
4. `rules/97-graph-layer-boundary.mdc`, `98-graphiti-memory-gate.mdc`, `99-graphiti-temporal.mdc`

## Deployment

See `docs/DEPLOY.md` — Zep Cloud managed service. No VPS, no tunnel, no local Neo4j. Secrets from Infisical vault. See `docs/adr/ADR-001-*` and `docs/adr/ADR-002-*` for architecture decisions.
