<!-- L9_META
l9_schema: 1
parent: l9-graphite-memory
layer: docs
role: instantiation-brief
tags: [cursor, mcp, zep-cloud, infisical, setup]
owner: platform
status: active
version: 2.0.0
updated: 2026-07-05
/L9_META -->

# Graphiti Instantiation in Cursor — Requirements Brief

**Purpose:** Checklist of everything required for Graphiti memory to load in Cursor via MCP (Infisical secrets → Zep Cloud transport → prefetch → memory-bank).
**Authority:** `QUICKSTART.md`, `docs/DEPLOY.md`, `docs/adr/ADR-001-*`, `docs/adr/ADR-002-*`
**Updated:** 2026-07-05

---

## 1. Infisical Vault (one-time org setup)

| # | Requirement | Detail |
|---|-------------|--------|
| 1.1 | **Infisical project** | Create project in Infisical (cloud or self-hosted) |
| 1.2 | **Machine Identity** | Create Universal Auth machine identity with access to the project |
| 1.3 | **Secrets stored** | `ZEP_API_KEY` stored in vault (environment: `prod` or as configured) |
| 1.4 | **Optional secrets** | `L9_OPENAI_API_KEY` if using custom entity extraction (Zep handles default) |

---

## 2. Machine — Bootstrap Environment (3 vars only)

| # | Requirement | Detail |
|---|-------------|--------|
| 2.1 | **`INFISICAL_CLIENT_ID`** | Machine identity client ID (from step 1.2) |
| 2.2 | **`INFISICAL_CLIENT_SECRET`** | Machine identity client secret |
| 2.3 | **`INFISICAL_PROJECT_ID`** | Infisical project ID |

Set these in your shell profile (`~/.zshrc`, `~/.bashrc`) or pass them in the MCP server env block (step 3).

No `.env` files. No macOS Keychain. No SSH keys. No tunnel.

---

## 3. Cursor MCP Configuration

Run the config writer:

```bash
python scripts/write_cursor_config.py
```

This writes to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "l9-graphite-memory": {
      "command": "python",
      "args": ["-m", "l9_graphite_memory.server"],
      "env": {
        "INFISICAL_CLIENT_ID": "<your-client-id>",
        "INFISICAL_CLIENT_SECRET": "<your-client-secret>",
        "INFISICAL_PROJECT_ID": "<your-project-id>"
      }
    }
  }
}
```

The MCP server boots → calls `load_secrets_sync()` → fetches `ZEP_API_KEY` from Infisical → connects to Zep Cloud. No tunnel, no VPS, no local Neo4j.

---

## 4. Package Installation

```bash
pip install -e ".[all]"
```

Or from GitHub Packages once published:

```bash
pip install l9-graphite-memory[all]
```

---

## 5. Pre-flight Validation

```bash
bash scripts/preflight.sh
```

8 gates checked:
1. Python version (>=3.10)
2. Package installed
3. Infisical bootstrap vars present
4. `infisical-python` importable
5. `zep-python` importable
6. Secrets loadable from vault
7. Zep Cloud transport healthy
8. MCP server can boot

---

## 6. Group Resolution (required for writes; reads use fallback)

| # | Requirement | Detail |
|---|-------------|--------|
| 6.1 | **`group_registry.yaml`** | `config/group_registry.yaml` — maps repo → `group_id` |
| 6.2 | **Repo match** | Git remote or path hint must match a registry entry |
| 6.3 | **Forbidden groups** | Never use: `main`, `default`, `test`, empty string |
| 6.4 | **Fallback** | Unmatched repos → `igor-workspace` readonly (reads OK, writes blocked) |

Add repo entry to `config/group_registry.yaml` for full read/write.

---

## 7. Repo memory-bank (T0 resume — required)

| # | Requirement | Detail |
|---|-------------|--------|
| 7.1 | **`memory-bank/` directory** | Repo root — scaffolded by `activate_gate.sh` or manually |
| 7.2 | **`activeContext.md`** | T0 SSOT — read on sessionStart, written on sessionEnd |
| 7.3 | **Template source** | `config/memory-bank-template/` |
| 7.4 | **Git policy** | Tracked or `.gitignore`'d per `group_registry.yaml` |

---

## 8. Gate Activation (optional — enables write enforcement)

```bash
bash scripts/activate_gate.sh /path/to/target-repo
```

Installs hooks and rules. See `docs/GATES-ACTIVATION.md`.

---

## 9. Verification (prove instantiation)

From any terminal after Cursor restart:

```bash
# 1. Health (liveness + Zep Cloud connectivity)
l9-memory health

# 2. Group resolve (confirm repo mapping)
l9-memory resolve

# 3. Session prefetch (same as hook)
l9-memory inject "session start"

# 4. Full gate E2E (optional)
bash tests/test_gate_e2e_full.sh
```

**Healthy instantiation:** `healthy: true`, `transport: zep`
**Degraded:** `healthy: false` — check Infisical vars and `ZEP_API_KEY` in vault.

---

## 10. Rules + Skills (agent behavior)

| Asset | Path |
|-------|------|
| Graphiti memory rule | `rules/03-graphiti-memory.mdc` |
| Graph layer boundary | `rules/97-graph-layer-boundary.mdc` |
| Graph engine architecture | `rules/97-graph-engine-architecture.mdc` |
| Graphiti memory gate | `rules/98-graphiti-memory-gate.mdc` |
| Temporal rule | `rules/99-graphiti-temporal.mdc` |
| Skill | `skill/SKILL.md` |

---

## 11. Common Failure Modes

| Symptom | Fix |
|---------|-----|
| `INFISICAL_CLIENT_ID not set` | Export the 3 bootstrap vars or add to MCP env block |
| `ZEP_API_KEY not found in vault` | Add key to Infisical project under correct environment |
| `zep-python not installed` | `pip install l9-graphite-memory[zep]` |
| `Transport unhealthy` | Verify Zep Cloud API key is valid at https://app.getzep.com |
| `fallback_readonly` group | Add repo to `config/group_registry.yaml` |
| Hooks not firing | Run `bash scripts/activate_gate.sh /path/to/repo` |
| Write gates blocking | Set `GRAPHITI_WRITE_GATES=0` until soak complete |
| Rate limited | Wait 2s between writes (circuit breaker auto-handles) |

---

## 12. Legacy (Decommissioned)

The following are no longer required and have been archived:

- SSH tunnel to Hetzner VPS — replaced by Zep Cloud HTTPS
- `~/.cursor/graphiti.env` — replaced by Infisical vault
- macOS Keychain — replaced by Infisical Universal Auth
- `ensure_graphiti_tunnel.sh` — no tunnel needed
- `docker-compose.yml` (self-hosted Neo4j) — replaced by Zep Cloud managed service
- VPS `46.62.243.82` — decommissioned

See `_archived/` for legacy files preserved for reference.

---

*See also: `QUICKSTART.md`, `docs/DEPLOY.md`, `docs/GATES-ACTIVATION.md`, `docs/MEMORY_BANK_POLICY.md`*
