
# EIE + CEG Domain Intelligence Mesh | Phased Development Pack v1.3.0

**Status:** Architectural/development handoff; NO executable CTO campaign, no repository edits, no PR, merge, deployment, live graph or credentialed provider test. This is a **source-aligned successor of `EIE_Inference_Provider_Update_DevPack_v1.2.0`**, retaining all original v1.2 P0 inference/research/provider work as **Phase P3** while expanding the authorized *development-design scope* to both sibling engines and their existing Gate seam.

**Vision:** **"We turn 2D CRM data into 3D graphs"** and **"We identify and backfill fields you didn't know you needed."** A client's CRM is a source, not the domain ontology. **EIE** maps source facts, identifies critical missing prerequisites, infers and researches them at the lowest justified cost. **CEG** builds and owns a persistent, domain-defined entity/relationship graph, evaluates its readiness, scores/matches against that graph and returns useful gaps and graph inferences to EIE. The two engines are a single intelligence product with bidirectional leverage.

**Governing EIE invariant:** **Acquire the smallest, cheapest piece of information that unlocks the greatest downstream intelligence.** Not merely "fill CRM fields" or "make the cheapest provider call." Work within the approved tenant spec, factual evidence, domain permissions, signed Gate interfaces, source independence, budgets, stable identity and frozen consumer contracts.

## Read order

1. `10_PRODUCT_ARCHITECTURE_AND_BOUNDARIES.md` — product promise, three different graphs/projections, authority and architectural constraints.
2. `11_PHASED_BUILD_AND_WORK_PACKAGES.md` — **five sequential real-work phases** with source owners, implementation tasks, dependencies and independent phase exits.
3. `12_CROSS_ENGINE_SEAM_AND_LOSS_LEDGER.md` — concrete source-observed seams S01-S16, minimum correction and proof.
4. `13_ACCEPTANCE_AND_HANDOFF.md` — one PlasticOS graph journey, G1-G6 integrated acceptance, negative cases, phase proof and future campaign conversion boundary.
5. `01_LOCKED_DESIGN.md` through `09_P0_INFERENCE_MESH_SV_HARVEST.md` — preserved original **P3** EIE inference/provider/research design. `08` reliability and `09` inference mesh remain mandatory and linked, not optional polish.
6. `07_SOURCE_BASELINE.json` — immutable source snapshots, confidence and unresolved deployment/runtime unknowns. `MANIFEST.json` — cryptographic file integrity.

## Sequential campaign candidates, not campaigns yet

| Phase | First built product capability | Hard exit result |
|---|---|---|
| **P0** Domain and seam compatibility | Approved compatible PlasticOS specs consumed by both engines; Gate routes and permissions agree | Same tenant/type/IDs and action contract prove positive and negative fixtures |
| **P1** CRM -> graph bootstrap | CRM-sourced identity/values/actual associations become nodes and typed edges in CEG | Real Neo4j readback and initial CEG gap assessment, no fabricated relationship |
| **P2** Reliable bidirectional transport | EIE graph-sync and CEG inference feedback survive process/Gate interruption | No lost accepted results, no duplicate edges, recoverable original operation |
| **P3** Inference mesh and providers | Original v1.2 P0 reliability + DeepSeek/Perplexity migration + unrequested graph-eligible fields | One paid fact -> multiple legitimate derivations; CRM-independent graph fact persisted with lineage |
| **P4** Graph intelligence loop | CEG scores/matches against improved graph and prompts a next EIE acquisition | G1-G6 combined signed test rail passes, including second domain and restart replay |

**These are implementation phases, not contract-writing campaigns.** A later CTO execution campaign for each phase must actually implement code, run bounded native tests/integration, fix defects, and produce reviewable PR evidence through currently verified governance. Phases may be sequentially activated, while independent implementation slices inside a selected campaign can run concurrently without file collision. Do not compile LCTO campaign scripts, operating commands or publication permissions into this ZIP.

## Done means

- Both engines use **one approved tenant-domain semantic source** through compatible, native consumer publications; no PlasticOS-specific behavior hardcoded in generic EIE/CEG code. Historical/archived CEG PlasticOS YAML is not runtime authority.
- Real source records and associations seed a coherent graph with tenant IDs, types, source provenance and evidence; CEG alone writes graph nodes/edges.
- EIE continuously closes cheap inference paths, searches only strategic missing prerequisites and uses the observed result to enrich CEG, even where the user's CRM has no corresponding field.
- The external `converge` response and CRM writeback remain scoped to consumer-approved output; graph-eligible intelligence has an independent typed and admitted path to CEG, never a bypass of `evidenceonly`/schema checks.
- EIE -> CEG and CEG -> EIE work survives failure/restart; receipt stages are truthful; unsupported Gate actions are not silently claimed to succeed.
- CEG actually consumes graph state for score/match/readiness and communicates new gaps back to EIE, with source lineage, tenant isolation and bounded cost.
- One end-to-end PlasticOS + a minimal unrelated-domain sentinel pass the six G1-G6 proof gates. Independent green PR suites or HTTP ACKs cannot substitute for observed graph state/decision results.

## Source and environment boundaries

Observed at immutable default-branch SHAs on 2026-11-18: EIE `29d4eb54942e446a9ac917d2ebe2d9733a4e7aec`; CEG `5d06649ed5587463c11b02594ce26b5ef4ad1733`; Gate `b451b68b98b315f57f0c4f9b99090a437e9dac23`; `.github` `00500268eb24de29a5e647a447d6f992d609f6f5`; Cursor-Governance `59c0b3e0fae7418c67b7e3be76c4e3f412ad49dd`. Runtime domain packs, Neo4j data, signing keys and live service configuration are **Unknown**. CEG's 2026-11-16 report says the integrated 3-service rail **had not been run as of that report**; this is not a claim about any subsequent deployment.

**Priority:** P0 first; don't make later campaigns wait on irrelevant optional improvements. Source-inspection before edits; repair at the earliest authoritative owner. Do not rewrite Odoo, CEG scoring business semantics, Gate internals or global `.github` law. Existing feature flags remain default-off until isolated proof and separately authorized activation. Publication/merge/production remain outside this development pack.
