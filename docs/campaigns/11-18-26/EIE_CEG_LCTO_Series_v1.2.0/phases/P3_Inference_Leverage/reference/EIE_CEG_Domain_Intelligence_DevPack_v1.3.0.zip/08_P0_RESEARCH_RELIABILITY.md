# P0 | Research reliability and inference-first surgical patch

**Priority:** Required for core EIE provider-modernization PR. This document strengthens v1.0.0 without authorizing new services, schemas, ownership boundaries, or an execution campaign. Where earlier pack prose could be read differently, the bounded behavior below controls.

**Pinned code baseline:** `Quantum-L9/Enrichment.Inference.Engine` `29d4eb54942e446a9ac917d2ebe2d9733a4e7aec`. Inspect current HEAD immediately before implementation and reconcile only affected functions. Observed behavior, not proposed behavior, is identified below.

## What the source actually does

1. `convergence_controller.py::run_convergence_loop` (approximately lines 280-560): planner and provider call run before `bridge.run()` inference on each pass. The rule engine and its confidence/provenance handling already work after provider enrichment. The controller's response assembler builds v2 `field_evidence` from its confidence tracker. The current zero-variation branch fails with `no_variations_authorized`.
2. `enrichment_orchestrator.py::_collect_variations` (approximately lines 506-548): first call is sequential; if insufficient, the remaining authorized calls are concurrent invocations of the same closure and payload, not meaningfully distinct research. `_process_variation_results` (approximately lines 550-574) carries validated data/tokens but drops the `SonarResponse.citations` and `.search_results` recorded by `perplexity_client.py`. The orchestrator's `sonar_config.disable_search` early return reports `completed` with empty fields without performing extraction/inference.
3. `consensus_engine.py::_field_score` (approximately lines 209-231) **already prevents repeating an identical reply from increasing its confidence score**. Do not rewrite the consensus math to fix acquisition waste. Its scores are explicitly uncalibrated.
4. `field_evidence.py::_produced` maps a provider field to `pass:N/consensus`, not the fetched provider reply or source. `docs/contracts/converge/response.v2.md` is frozen: `observed` means supplied by the consumer and is never newly admitted; `inferred` means derived by a versioned deterministic rule; `external_claim` means asserted by another source, NOT independently verified. Its `source_ref` is a resolvable **provider reply reference**, not an arbitrary URL; source independence is unknown (`null`).
5. `prompt_builder.py::SYSTEM_TEMPLATE` currently asks models to research every entity thoroughly even when supplied text alone suffices. `validation_engine.py::validate_response` removes citation-like metadata from the normalized field map; its schema/type validation already exists and should be reused.

## Surgical sequence, by code owner

### P0-A. Run existing rule inference before any research call

**Edit:** `app/engines/convergence_controller.py`.

- Extract the existing post-provider inference block into a *small private helper* within the same module (or reuse it directly if smaller). Invoke it after consuming relevant GraphReturnChannel targets and **before** `planner.plan_pass` on pass 1, and again after new provider fields on each pass. Do not duplicate the business rule logic.
- Input to inference is only consumer-supplied facts, graph-seeded inputs and subsequently returned provider facts. Never feed a field derived by the same bridge back as if it were new independent evidence. Preserve versioned rule provenance, input confidence bounds, retraction of superseded derivations, and no-overwrite of consumer values.
- Rerun only when inputs can have changed; no pointless extra work. The existing D-9 v2 readiness, required-field population, field bars, `U_action` target selection, deadline and max-pass constraints remain owned by existing code.
- When all *newly producible* required outputs are satisfied by legitimate rule inference, return a valid existing v1/v2 response with zero external calls. When a required field is **only consumer-supplied**, it remains `observed` (unadmitted) in response v2; do not seed the tracker with fake 1.0 confidence or echo it as newly enriched. A no-work case may yield zero new fields only if the existing response/state and downstream side-effect semantics safely support that as an explicit no-op, not an invented successful enrichment. Verify `handlers.py::_persist_and_sync` behavior before selecting the no-op path.
- Distinguish provider authorization from rule execution. If the planner authorizes zero provider calls but deterministic inference already produced a valid output, do not retroactively invalidate it. If unresolved required outputs remain, preserve `no_variations_authorized` or equivalent current bounded failure.

**Acceptance:** Valid existing rule derivations produce zero paid calls; missing external fact is never filled by a model guess or a synthetic confidence; previous inference changes/retractions still work; no change to `field_evidence` status meanings.

### P0-B. Remove duplicate provider fanout; don't break legitimate retries

**Edit:** `app/engines/enrichment_orchestrator.py` (and only target call-budget coordination required in controller/optimizer).

- In the canonical converge path, default to **one purposeful provider request per pass**, regardless of a higher *maximum* variations allowance. If incomplete, let the next existing convergence pass use its targeted fields. Do not fan out the same closure/prompt N times solely to create agreement.
- Additional calls are permitted only for a *different unresolved target or evidence plan* (e.g. distinct source coverage) and must stay under the existing caller cap, shared deadline and token budget. Genuine transport retry under the existing breaker and retry owner is not a second research variation; do not disable safe 429/5xx retries.
- Preserve actual call count, token usage and cost/reporting integrity. If a call produced conflicting candidate values, surface them through existing withheld/conflict behavior instead of hiding dissent behind a later repeated answer.
- Fix `disable_search`: **no web search does not mean no LLM extraction**. DeepSeek Flash no-web should still process provided text when necessary. Deterministic no-call is chosen by controller only after readiness is established. Never return `completed, fields={}` as a surrogate for paid research skipped.

**Acceptance:** Incomplete first reply triggers focused next-pass work, not a parallel identical-repeat burst. No-search document extraction executes without web calls. Existing retry/deadline/idempotency behavior remains intact.

### P0-C. Carry provenance all the way to a field, without inventing a new schema

**Edit:** `app/services/perplexity_client.py` (API migration from original design), `app/engines/enrichment_orchestrator.py`, `app/engines/convergence_controller.py`, `app/engines/convergence/field_evidence.py`, and a bounded prompt adjustment in `app/services/prompt_builder.py`.

- Keep the provider-return envelope that already exposes `citations` / `search_results`; do not throw these away during `_process_variation_results`. DeepSeek Search/Fetch must similarly retain **actual** tool results and whether retrieval executed. Assign a stable *within-response provider reply id* and bind each validated field candidate to that reply and, when available, a specific retrieved source.
- Request field-to-source attribution from the model, but accept an association as web-grounded only when the referenced URL/document is present in the **actual returned Search/Fetch/tool result set** and relevant evidence can be traced to that returned source. A model-cited URL alone is not proof of retrieval or support. Do not require a global crawler, semantic source scorer, LLM judge or second validation engine.
- Reuse existing `EnrichResponse.enrichment_payload` and/or `feature_vector` to carry compact per-field `provider_reply_id`, provider/model, retrieval-happened signal, supported URLs (and returned title/date when present) so `field_evidence`'s existing `source_ref` can resolve to a real provider reply. The v2 `sources[]` structure is **unchanged**; use `source_type=provider` and a reply reference. Do not store arbitrary page content or change fixed v2 `Source` fields. Retain raw source records only insofar as necessary for traceability and within existing data retention bounds.
- Preserve model-provided **input-only** extractions as `external_claim` from a provider, with actual input/reply lineage; do NOT label them deterministic `inferred`, consumer `observed`, independently confirmed or source-verified. Preserve versioned `inferred` exclusively for actual domain-rule derivations. An ambiguous model-only inference without traceable input should remain unadmitted.
- **Apply the field-support check at the existing provider candidate admission/filtering boundary**, before `synthesize` and before confidence tracker updates: if a field is being presented as a sourced *external web fact*, no retrievable field-specific source means it is withheld/unadmitted, even when model self-confidence exceeds the numeric bar. Simple input-only extraction does not require web citations; deterministic inference requires rule provenance instead. Preserve the existing `external_claim`/`unknown`/`conflicting` distinction; no new response state or blanket web-citation check.
- A provider's supplied URLs can establish **attribution**, not guaranteed truth or independence. A website's self-description remains an `external_claim`. If distinct retrieved sources disagree and the existing contract cannot resolve it without inventing authority, return unadmitted conflict candidates.

**Acceptance:** A returned researched value has a field-specific provider reply ref resolving to actual source metadata; unsourced purported web facts do not become admitted facts; document-only transformations work without citations; v2's frozen shapes and existing proposal behavior remain untouched.

### P0-D. Keep the prompt honest and gap-focused

**Edit:** `app/services/prompt_builder.py` only where the current prompt is the actual provider route; adapt deepseek-specific content in its selected branch.

- Replace unconditional "Research this entity thoroughly" wording in no-web mode with "Extract/normalize only from the supplied inputs; do not introduce external facts; omit unknowns."
- Research mode asks only for unresolved target fields and concise evidence references per field, without spraying every known CRM attribute into a search request. Preserve domain schema, KB selection and exact requested field types.
- The existing response normalization still filters fields through schema/type validation. No new prompt compiler, quality-scoring agent, or extra model to judge outputs.

## Minimal proof, not a test bureaucracy

**Required focused regressions (R01-R08, in numbered order below):**

1. **Known data / true rule inference:** no paid call; v2 inferred entries have rule id/version and input refs; consumer-only observed inputs are not admitted as new enrichments.
2. **No-web supplied document:** DeepSeek extraction executes if necessary, web count=0, provider-reply and input lineage present; `disable_search` does not generate false-success empty output.
3. **Simple sourced public fact:** one search/fetch, one field, matching actual retrieved source, field-level reply ref resolvable; supported fact admitted only at existing field bar.
4. **Missing or invented URL:** no retrieved field-specific source for a web-required field -> withheld/unadmitted, never successful researched fact.
5. **Contradictory web sources:** conflict survives; correlated repeated model assertions cannot erase it.
6. **Incomplete reply:** next pass is targeted; no duplicate identical fanout; actual call count is accurate.
7. **No authorized provider call with unsatisfied required field:** existing bounded failure, not `completed` with empty fields.
8. **Cross-contract regression:** v1, v2, Odoo/Gate/CEG writeback fixtures, shared deadline, existing field thresholds and deterministic-provider test-only guard remain valid.

Use existing test files and fixtures, no new test harness or broad provider evaluation pipeline. Credentialed API smoke belongs to the provider migration already covered by the pack. Do not run a 24-record research benchmark as a prerequisite to opening a PR; comparable staging evaluation can be a later production-enablement step.

## Hard non-goals

- No new repo, layer, service, pipeline orchestrator, generic tool router, provider plugin registry, evidence database, confidence model, search crawler, or validator suite.
- No changes to `app/services/consensus_engine.py` without a failing test proving the actual code wrong; duplicate calls are an acquisition defect.
- No new v2 evidence states, changed `Source` contract, API shape, Odoo/CEG/Gate writeback, automatic graph writer, or alternate publisher.
- No silent fallback to local deterministic mode in production; no new Google Custom Search dependency.
- Do not fix unrelated existing code while here. A proven upstream blocker outside EIE is reported, not modified through this pack.

## Future CTO campaign handoff, **not activated here**

This pack is **a developer design handoff**. A future separately authorized LCTO/CTO execution campaign can consume it, rebind the actual current EIE/`.github`/Cursor-Governance revisions, verify applicable projections and source permissions, allocate one core owner plus an independent manual-review owner, and compile the latest governed `make pr` publication path. This ZIP does not create an agent swarm, executable campaign contracts, a PR, a merge or a deployment. Do not turn future packaging into an implementation prerequisite or an excuse to reopen the frozen functional objective.
