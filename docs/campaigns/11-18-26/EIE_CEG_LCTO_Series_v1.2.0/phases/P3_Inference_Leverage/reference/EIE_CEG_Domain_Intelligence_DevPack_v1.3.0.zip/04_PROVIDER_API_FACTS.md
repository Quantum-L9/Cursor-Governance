# External API facts and validation obligations (verified 2026-11-18)

**Important:** These notes pin information reviewed now. The executor must reopen official docs and verify endpoint/SDK request and response shapes against current behavior before implementing; APIs are versioned externally. Pricing is context, not a hard-coded routing formula.

## DeepSeek
- Official 2026-11-13 update adds `deepseek_web_search` and `deepseek_read_url` server tools to model APIs. A model **decides whether** to call them; declarations alone are not evidence that the tool executed.
  - https://api-docs.deepseek.com/updates/?release=releasing-the-full-suite-of-application-apis
  - https://api-docs.deepseek.com/guides/web_tools/
- Current low-cost model slug `deepseek-flash`; stronger model slug `deepseek-v4-pro`. Flash supports non-thinking and thinking; web tool syntax differs among Messages, Responses and Chat Completions API. `web_search` in Responses API is a different tool and supported on `deepseek-v4-pro`; do not accidentally map it to Flash. Use `deepseek_web_search` for Flash if using server tools.
  - https://api-docs.deepseek.com/quick_start/pricing/
  - https://api-docs.deepseek.com/guides/responses_api/
- Standalone API: Search `POST /v1/tools/search` and Fetch `POST /v1/tools/fetch`, Bearer token, structured results and URL/page content respectively. Search and Fetch currently priced at $0.75 per 1,000 *successful* standalone requests each. Server tool calls currently not billed separately (model tokens still charged); independently verify current billing if actual cost estimates are needed.
  - https://api-docs.deepseek.com/guides/search/
  - https://api-docs.deepseek.com/api/search/
  - https://api-docs.deepseek.com/api/fetch/
- DeepSeek model prices vary by peak/off-peak and cache usage; don't hardcode assumptions into field routing. Compare measured spend at representative context and model output length.

## Perplexity
- Provider migration target: Sonar Chat Completions (`chat.completions.create`) -> Agent API (`responses.create` or documented current API) with *non-identical* request/response semantics and citations. Sonar Chat Completions retirement was announced for 2026-09-27; do not assume the legacy endpoint reliably works now.
  - https://docs.perplexity.ai/docs/agent-api/migrate-from-sonar (canonical provider guide; availability of documentation URL may depend on environment)
  - https://github.com/perplexityai/api-platform-developers/blob/main/skills/migrate-sonar-to-agent-api/SKILL.md (provider-maintained support guide, corroborating migration)
  - https://community.perplexity.ai/t/sonar-is-moving-to-the-agent-api/5802 (provider announcement)
- Do not assume `sonar-reasoning`, `sonar-pro`, `search_mode`, `temperature`, or `choices[0]` have direct Agent API equivalents. Honor documented presets/model mapping and response fields; preserve citations and usage in EIE's existing internal result.

## Google
- Custom Search JSON API is closed to new customers; existing customers transition by 2027-01-01. The historic free daily quota is not a new integration plan.
  - https://developers.google.com/custom-search/v1/overview

## Provider comparison, bounded to this campaign
- Favor deterministic/no-call for available truth; DeepSeek Flash no-web for input-only transformations; DeepSeek Search/Fetch for source-constrained simple external facts; DeepSeek thinking/V4 Pro for difficult reasoning; Perplexity Agent when research depth/coverage demonstrably adds value.
- This is a **policy intent**, not a claimed benchmark: do not assume DeepSeek is categorically better at every research field. A 20-30-case fixture review must capture accuracy, source coverage, model search behavior, cost and latency before enabling production defaults.
- Secret existence is **operator supplied, not verified**. Executor must prove target deployment can read secret without disclosure.
