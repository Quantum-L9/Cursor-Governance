# Cross-engine acceptance, fixtures, sequencing and future CTO handoff | v1.3.0

## What "built" must mean

A domain-neutral system able to seed a typed entity/relationship graph from sparse CRM facts, identify strategically useful missing intelligence beyond CRM fields, acquire the cheapest defensible prerequisites, persist attributed facts/relationships in CEG, and improve a **real CEG decision** through repeatable, recoverable EIE<->CEG exchange. The acceptance environment is a temporary tenant-controlled test rail, never production data.

## Minimum fixture: PlasticOS, with no unapproved assumptions

Define one synthetic but source-shaped PlasticOS tenant fixture, at an approved effective spec revision. Illustrative source input:

- Tenant `plasticos` (only if permitted by the actual pack and test DB); CRM-sourced facility/company identity `Example Recycler`, source resource and record id, website `example-recycler.test`, city Charlotte, NC. Data is synthetic. A second source-linked facility/material/product instance/edge is included **only where the loaded spec actually declares it**.
- CRM has no contamination tolerance, material grade, process-capability, or downstream matching fields. Domain ontology may declare those properties, including prerequisite-only fields; the CRM need not create them.
- A controlled source document or fixture includes one typed, attributable fact, e.g., `contamination_tolerance = 2%` (the actual accepted unit/type must be spec-valid). Existing rule examples may derive `material_grade` then `tier` **only if their actual preconditions hold**, including processed polymer and monthly capacity. No arbitrary grade or cost assumption is valid.
- Include at least one *actual fixture-declared* provider association or approved source relationship, with unique evidence ref. Do not invent company->facility or facility->material edges if the effective spec does not provide endpoints.
- Define one minimal non-PlasticOS cartridge as domain-neutral sentinel; it must exercise generic mapping, inference and typed graph projection without source-code domain branches.

**Don't infer absent facts:** A synthetic fixture may provide explicit source observations for testing; it is never represented as production-verified. `observed` association means membership in the fixture's authenticated provider view, not purchasing interest or capability.

## Six product gates (G1-G6), owned by future CTO integrator

| Gate | Required observed proof | Failure that gate catches |
|---|---|---|
| **G1 Graph bootstrap** | CRM source ID + field mapping creates correct typed graph nodes and one declared evidenced relationship; CEG Neo4j readback validates tenant isolation/identity | A field scanner returns a report but no graph is constructed, or multiple source entities alias wrongly |
| **G2 CRM-independent intelligence** | Domain-declared field **absent from CRM** acquired or legitimately inferred and persisted/read back from CEG; CRM response/writeback remains scoped | Complete EIE response masks loss of the richer graph fact, or writes unwanted CRM field |
| **G3 Economic inference leverage** | Deterministic prepass zero-call; one acquired fact unlocks multiple actual derived fields; complementary cheap facts unlock critical output; unique value and cost comparisons tested | Duplicate provider fanout, zero-cost closure ignored, duplicated path value, model guess admitted as rule |
| **G4 Crash-safe collaboration** | Process kill after EIE persist before CEG ACK; separate kill after CEG feedback accepted before EIE consume; both replay and converge without duplicate graph/evidence or repeated paid calls | Process-local queue/outbox loss, false accepted/completed, unsafe replay |
| **G5 Graph-backed decision and feedback** | Actual CEG `match`/permitted `score` uses newly populated graph fields/evidence, affecting readiness/gate/score or candidate eligibility; CEG new gap triggers justified EIE pass | Cosmetic graph sync not consumed in a real decision, fake readiness, unsupported score action |
| **G6 Domain neutrality** | Same generic execution owners work with second minimal, non-PlasticOS cartridge; no new per-domain Python branches | Prototype hardcodes PlasticOS, only one domain can load or match |

## Phase-specific tests and receipts

**P0:** Positive dual-spec load and typed route fixture; negative tenant/ref/revision/type mismatch; Gate correct actor/key and unauthorized caller refusal; active deployed packs separately verified or blocked. Receipt: exact domain revision/sha/diff and route/permission matrix.

**P1:** Two source-shaped provider resources, one valid association and one unsupported association; graph readback before/after import; repeat seed idempotently; CEG health report shows actual domain gaps; nullable and unknown fields not fabricated. Receipt: graph node/edge identities and CEG readback query outputs from test rail.

**P2:** Inject Gate outage, EIE process termination, restart, duplicate packet, queue saturation, CEG ACK loss and conflicting edge evidence. Assert pending state survives; no research replay; correct tenant entity, bounded retry/cost; acknowledged `targets_queued` means durable count. Receipt: before/after store records, CEG readback, replay receipt. Avoid introducing a large chaos-test framework; two representative crash points are mandatory.

**P3:** Reuse **exact** prior `05_TEST_AND_ROLLOUT.md` T01-T16, `08_P0_RESEARCH_RELIABILITY.md` R01-R08 and `09_P0_INFERENCE_MESH_SV_HARVEST.md` M01-M08. Add one **graph-eligible, unrequested field** persistence fixture. Run bounded provider SDK smoke where credentials available; otherwise record precise blocked source, no false provider proof. Receipt: source lineage, call count/tokens, source-backed field confidence and graph readback.

**P4:** One signed combined rail including Gate, EIE, CEG, PostgreSQL and Neo4j; cross-engine integration and scoring readback, second cartridge sentinel, interruption/replay. Verify CEG `remote_score_enabled` only if explicitly authorized; local secured score tests may prove behavior without enabling production Gate action. Receipt: per-gate pass/fail and exact blocker, runtimes/flags, stable graph IDs, evidence ref, actual CEG result delta, cost and end-to-end trace ID.

## Essential negative test cases (targeted, no test factory)

- Invalid tenant or cartridge digest -> refused before data read or write.
- Unknown CRM source field -> preserved as unmapped provenance/report, not mislabeled as approved ontology property.
- CEG missing/undeclared `evidenceonly` field -> withheld with explicit reason; never counted as persisted graph intelligence.
- Provider result with no actual retrieval evidence -> unadmitted if web sourcing is required.
- Model-generated claim -> never counted as deterministic rule inference or CRM observed association.
- Two independent inference paths -> same field's value counted at most once for leverage.
- Gate `score-invalidate` unsupported -> not reported as successful; no accidental permission extension.
- Feature flags false -> honest disabled state; no 'works' assertion based on unactivated path.
- Changed tenant spec during sweep -> pinned revision refusal/replan; never silently switch to a different graph schema.
- Failed transport followed by retry -> CEG authoritative graph result is correct, no duplicate edge, no extra paid call.

## Campaign conversion is a subsequent decision

**DO NOT** treat this ZIP as an LCTO campaign. It is an architect-level, evidence-grounded **development artifact**. On later user request, turn **one selected P0-P4 phase at a time** into an execution-ready campaign that:

1. Rebinds HEAD/relevant source, domain authority, current `.github` semantics/projections and Cursor-Governance's latest LCTO/architect delegation and `make pr` policy. The source SHA snapshot in this pack is planning evidence, not future execution authority.
2. Converts phase work items to implementable PR-scoped slices with exact write surfaces, owners, noncolliding parallelism, native tests, shared integration owner, release conditions and recovery boundaries. A campaign is **not** just a contract: it must drive implementation, focused tests, integration, remediation and a reviewable publication handoff, subject to actual authorization.
3. Runs fastest safe independent code lanes, with one CTO integrator responsible for cross-repo compatibility and outcomes; does not multiply agents editing the same controller or spec artifact.
4. Reuses completed phase receipts and immutable artifacts. Does not rerun closed work without changed evidence; no speculative dependency factories or extra CI matrix.
5. Treats PR publication, merges, deployment, secrets, production data reads/writes and remote score enablement as distinct controlled actions. Future authorized campaign may use `make pr`, but this dev pack neither invokes nor authorizes it.

## Practical release frontier

- **After P0:** Shared domain/seam preconditions understood; domain fixture executable, production pack not necessarily installed.
- **After P1:** 2D CRM data **actually seeds a domain graph**; even without paid enrichment, the first product claim can be demonstrated in isolated test environment.
- **After P2:** Cross-engine collaboration is **replay-safe** under two required crash conditions, not just functional when healthy.
- **After P3:** EIE expands graph facts beyond CRM using strategically optimized inference and source-backed research.
- **After P4:** **First end-to-end product proof**: graph intelligence demonstrably changes a real CEG decision and feeds an EIE next step. Only then consider production enablement, customer-scale migration and agentic RevOps.

## Known environment and authority unknowns

- Whether the intended CEG runtime has the actual admitted PlasticOS domain pack and `plasticos` Neo4j tenant database.
- Whether Gate/EIE/CEG keys, actor policies, live registrations and the optional flags have been configured in deployment.
- Whether current EIE PostgreSQL schema provides durable reusable storage for both outbound graph tasks and inbound inference feedback.
- Whether live CRM credentials and Odoo/HubSpot source association data are available for a real-source read.
- Whether EIE/Ceg `score-invalidate` is required at all, or represents unsupported/stale choreography.
- Whether quantified improvement to commercial scoring/matching can be attributed in production rather than only demonstrated in controlled fixtures.

Unknowns are **targeted proof requests**, not invitations to overbuild; each blocks only the step that logically depends on it.
