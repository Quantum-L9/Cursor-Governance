# Source-aligned implementation map

> **v1.3 development scope:** Original EIE-only mappings below are preserved as the **P3** workstream. The cross-repo, CRM-bootstrap, durability and scoring source owners are enumerated in `11_PHASED_BUILD_AND_WORK_PACKAGES.md` and `12_CROSS_ENGINE_SEAM_AND_LOSS_LEDGER.md`. Nothing below forbids separately authorized P0/P1/P2/P4 corrections at CEG or Gate. No Odoo source rewrite.


**Read pinned SHA** `29d4eb54942e446a9ac917d2ebe2d9733a4e7aec`; recheck actual HEAD before code mutation.

| Existing source | Observed behavior | Bounded expected work |
|---|---|---|
| `app/engines/handlers.py` | Gate canonical `handle_converge` runs controller, persists completed result and defers CEG sync; 30s operation budget | No external action/response changes. Adapt only if required to retain behavior. |
| `app/engines/convergence_controller.py` | Builds planner targets then calls `enrich_entity`, only afterwards runs inference bridge | Extract/reuse existing post-provider inference to run before planner/provider and again after new facts; preserve graph feedback, derivation retraction, D-9 v2. Do not assign synthetic confidence to observed input or produce false no-work success. |
| `app/engines/enrichment_orchestrator.py` | `L9_ENRICHMENT_PROVIDER` selects Perplexity vs test-only deterministic; `_collect_variations` reuses identical payload | One purposeful provider request per pass by default; no identical concurrent fanout; fix `disable_search` empty-completed path; retain field-to-reply/source metadata through validation; keep current result envelope or smallest neutral internal adapter |
| `app/services/perplexity_client.py` | SDK `chat.completions.create()` and Sonar model IDs; `SonarResponse` already has citations/search_results but caller drops them | Migrate to Perplexity Agent API; retain actual retrieval/source records and a stable reply id in the caller; preserve usage, breaker/deadline and internal compatibility |
| `app/services/prompt_builder.py` | Prompts currently say “Research this entity thoroughly” even for no-web tasks | No-web prompt must extract from supplied input only; research prompt targets gaps with field-specific source refs, no new prompt framework |
| `app/engines/search_optimizer.py` | `SonarConfig` specializes Sonar model and search parameters | Do not force new provider through Sonar-only parameters. Narrow provider-neutral selection at caller seam; retain existing optimizer where Sonar relevant |
| `app/engines/meta_prompt_planner.py` | Field priority, required bars, variations and mode | Reuse gap ranking; no new planner / extra control-plane service |
| `app/engines/inference_bridge_adapter.py`, `app/engines/inference_bridge_v2.py` | Existing condition rules and derivation graph | Invoke existing rule engines over known facts pre-research; versioned provenance preserved |
| `app/engines/convergence/field_evidence.py` | Tracks `observed`, `inferred`, `external_claim`, conflicts/unknown; inferred requires rule ID/version internal provenance | Preserve `inferred` solely for versioned rules; model outputs are provider `external_claim`, including no-web extraction; use existing Source.source_ref as resolvable provider reply id with field-level retrieval metadata in existing diagnostics. Do not edit frozen v2 schema |
| `app/services/consensus_engine.py` | Score is uncalibrated and provider repetitions are correlated | Current `_field_score` already deduplicates repeated identical assertion support; DO NOT rewrite without proven regression. Avoid duplicate provider acquisition at orchestrator; preserve thresholds |
| `app/core/config.py`, `docs/contracts/config/env-contract.yaml`, `.env.example` | Perplexity default; deterministic tests guarded; openai/anthropic env fields are dormant | Add minimal DeepSeek credentials/model/feature settings, default-off rollout, no plaintext secret; preserve deterministic restrictions |
| `tests/test_enrichment_orchestrator.py`, `tests/test_convergence_controller.py`, `tests/test_field_evidence_response_v2.py`, `tests/unit/test_deterministic_enrichment.py`, `tests/integration/test_converge_api.py`, `tests/contracts/test_converge_request_v2_dispatch.py` | Existing regression surface | Add focused fixtures for no-call, branch routing, source provenance, disagreement, timeout, model output and v2 contract |

## Separate low-risk lane
- `tools/ai_review.py` and `.github/workflows/perplexity-code-review.yml` currently use Perplexity chat completions for manual review. Convert to DeepSeek Flash or stronger reasoning *without changing* verdict contract, workflow trigger, posting semantics, blocking mode, permissions, or PR-scoped review behavior. Keep an independent PR if doing concurrent implementation. This lane is **non-blocking** for the core enrichment provider change.

## Search and demo utilities excluded from core mutation
- `tools/pplx_research.py`: specialized manual research utility; record deprecated API use but defer unless explicitly required for this deliverable.
- `app/services/simulation_bridge.py`: synthetic demo fixture; no runtime source migration.
- `odoo_modules/plasticos_research_enrichment/`: old noninstalled addon; live Odoo producer resides in `cryptoxdog/IB-Odoo_19`. Do not patch.
- `app/services/openai_client.py` and `app/services/anthropic_client.py`: dormant `BaseSource` adapters, not live in canonical EIE path; do not generalize them or retrofit dormant waterfall.

## Precise concurrency boundary
Core changes to the orchestrator/controller/config/provider API are one shared code lane. The manual-review script/workflow lane is independent and can be implemented concurrently. An integration owner owns final cross-path validation; never run two agents concurrently editing `enrichment_orchestrator.py`, `convergence_controller.py`, or `app/core/config.py`.

## P0 function anchors at pinned EIE source
- `convergence_controller.py::run_convergence_loop`: inference after provider today; `_as_response_v2` constructs evidence from tracker and pass provenance; `_assemble_convergence_response` builds only fields produced during passes. A no-call path must respect those ownership and status semantics.
- `enrichment_orchestrator.py::_collect_variations`: first call then same-function concurrent fanout; `_process_variation_results` keeps `result.data` but not `SonarResponse.citations` / `.search_results`; `disable_search` early return currently signals empty `completed`.
- `field_evidence.py::_produced`: source is `pass:N/consensus`; frozen v2 Source.source_ref is an internal reply reference and Source.independent remains null.
- `consensus_engine.py::_field_score`: same-provider repetition is already not scored as independent support.

See `08_P0_RESEARCH_RELIABILITY.md` for patch and acceptance; its exact instructions take precedence over any ambiguous high-level phrasing here.

## P0 inference-mesh owner map (v1.2, additions to above)
- `app/engines/inference/rule_loader.py::score_unlock_potential`: **confirmed mapping mismatch**, it reads object-style ontology while convergence gives raw `dict` YAML; re-use the planner's working YAML metadata access instead of a new model or global scorer. Make unique output credits and declared weights work.
- `app/engines/meta_prompt_planner.py::_identify_missing_fields` / `_rank_fields`: include missing rule prerequisites even when not requested, and apply leverage ranking in initial discovery rather than bypassing it. Preserve consumer-required field priority and caller schema, D-9 controls.
- `app/engines/inference_bridge_v2.py::_compute_unlock_values`, `app/engines/inference_bridge_adapter.py::_condition_unlock_values`: existing immediate unlock graph and condition-rule index; minimally extend to **unique finite multi-hop reachable outputs** with only supported conditional credit, not a new graph framework.
- `app/engines/convergence_controller.py::run_convergence_loop`: calculate inference/active unlocks before Pass 1 research and after each provider result; compare available actions to no-call/stop. Reuse existing `PassResult`, `CostTracker`, `SonarConfig`/provider routing and evidence handling.
- `app/engines/search_optimizer.py` and existing cost estimates: select the *source-adequate acquisition method* using compatible known cost/time estimates, not cheapest model in isolation; absent success rates/weights imply ordinal decision, not fabricated expected ROI.
- `domains/plasticos/spec.yaml`: **three observed conditional inference rules**, zero `derived_from` entries and `scoring_weight` keys at this pinned revision. Do not add arbitrary weights or inference edges merely to make demonstrations green; domain-owned optional priorities need evidence.

The EIE donor-comparison artifact is `09_P0_INFERENCE_MESH_SV_HARVEST.md`. Canonical SV text remains read-only in `Quantum-L9/.github@00500268eb24de29a5e647a447d6f992d609f6f5` and **does not require binding a new runtime SV projection into EIE**.
