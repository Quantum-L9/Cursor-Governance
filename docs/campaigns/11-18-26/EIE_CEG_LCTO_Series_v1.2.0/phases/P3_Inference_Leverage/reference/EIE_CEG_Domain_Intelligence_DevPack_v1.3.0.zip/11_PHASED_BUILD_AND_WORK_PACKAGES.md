# Sequential build phases | Implementation-ready development scope, NOT a campaign pack | v1.3.0

## Sequencing rule

Five sequential campaign candidates **P0 to P4**, each independently bounded and producing real tested work; later conversion creates *separate* CTO execution campaigns. These are **development work packages**: concrete file owner, corrective behavior, integration proof, stop/exit and dependency, not merely abstract contracts. They do not contain guessed commands, agent invocation scripts, authorization, or PR/merge/deploy instructions. Use the current upstream LCTO/make-pr policy only at future campaign compilation.

Order is based on earliest functional dependency:

```
P0 Domain/Seam Compatibility
          |
P1 CRM -> CEG Graph Seed
          |
P2 Durable EIE <-> CEG Transport
          |
P3 Inference Mesh + Provider Intelligence (prior v1.2.0 work)
          |
P4 Closed-loop Graph Intelligence (score/match/gap feedback)
```

**Overlap allowed within a phase** only when independent write owners are verified. A prepared Phase N+1 analysis/fixture does not mean a later executable campaign has started or passed P(N). Preserve parallel work inside a future phase-specific CTO campaign, not five competing top-level coordinators.

## P0 | Bring the two engines onto the same approved domain and seam contract

**Objective:** All subsequent paths address the *same* tenant, compatible domain nodes, IDs, field types, rules and graph endpoints, with Gate action ownership that actually routes both ways.

**Work items (real implementation / artifacts):**

- **P0.1 Tenant domain source resolution.** Inventory active published EIE `domains/<tenant>/...` and CEG domain pack/loader (CEG's repo-level executable `domains/plasticos/spec.yaml` was **not visible** at inspected SHA). Find authoritative PlasticOS pack source in actual intended environment before claiming it deployed. Respect existing EIE `DomainYamlReader` revision receipts and CEG `DomainPackLoader`; do **not** promote archived YAML. If source unavailable, build only an explicit isolated test fixture and leave production-promotion blocked.
- **P0.2 One domain meaning, two compatible consumer views.** Compare labels, node property names/types, `evidenceonly`, sync endpoints, id properties, ref namespaces, observed associations, edge types/direction, inference rules, role/material/facility mapping, gate/scoring field requirements and version digest. Edit **domain artifacts at their proper current owner** only, not generic PlasticOS branches in EIE/CEG. Record explicit mapping/provenance where representations differ; no silent rename or conflation.
- **P0.3 Core route/permission handshake.** Verify live registry action ownership for `sync`, `health-assess`, `graph-inference-result`, `enrichment-sweep`, `enrichment-sweep-results`, `match`, optional `score`. Confirm exact caller policies, signing/verifying keys, tenant and permitted node identities. Use the existing `Constellation.Gate` canonical action registry and SDK; avoid new action names unless proven strictly necessary. Reconcile EIE's unsupported `score-invalidate` path against **actual** CEG score-cache semantics: remove dead calls if no invalidation is required; otherwise use an authorized existing owner rather than guessing a new action.
- **P0.4 Minimal cross-repo compatibility fixture.** Add/update existing tests or fixture resources that validate the selected tenant spec and graph sync/health request types from both engines. Verify the same fixture fails on a deliberate type/ID/edge mismatch and succeeds without drift. Do not add a new generator/synchronizer service.
- **P0.5 Runtime preflight proof request.** Capture unavailable production facts as explicit blocked checks: actual admitted pack, writable target Neo4j database, active Gate keys, real Graph/Sweep flags. A green repository test is not environment proof.

**Source owners:** EIE `app/engines/domain_yaml_reader.py`, `app/engines/converge_request_v2.py`, `domains/<tenant>/spec.yaml`; CEG `engine/config/loader.py`, `engine/config/schema.py`, `engine/config/tenant_mapping.py`, `engine/sync/row_contract.py`; Gate `routing/action_ownership.py`, `config/node_registry.yaml` and their existing tests.

**Exit P0:** One controlled PlasticOS fixture is admitted to **both** engines and typed sync + readiness packets route with correct tenant and identity; wrong revision/type/tenant refuses. The real deployment's pack and key availability are separately proved or explicitly `BLOCKED`, not papered over. The shared schema/identity mapping is recorded and frozen as the premise for P1.

**Not included:** customer data import, deep inference/provider change, production flag flips.

## P1 | 2D CRM data to a real seeded CEG graph

**Objective:** Given a sparsely populated real-format CRM entity with actual source IDs and at least one valid association, create tenant-scoped CEG nodes and evidenced relationships under the approved ontology. The resulting graph must contain more structured meaning than the CRM's raw rows.

**Work items:**

- **P1.1 Intake adapter.** At the existing EIE CRM/integration owner, connect `CRMClientBase.get_field_metadata()`, `query_records()` and (when source supports it) actual association reads into `scan_crm_fields` and existing domain mapping. Respect HubSpot/Odoo/Salesforce connector-specific native calls; do not copy provider-specific mapping to generic orchestration. Existing `app/services/domain_spec_workflow.py` is a candidate integration owner; verify against current code before edits.
- **P1.2 Domain mapping and identity.** Build typed node records for declared Company/Facility/Material/etc **only where that tenant spec defines them**; preserve normalized source_system, object type, source record ID and stable tenant-qualified graph IDs. Distinguish company versus facility and material profiles; do not flatten one source CRM partner row into every graph concern by assumption. Ambiguous matches remain unresolved until evidence/approved resolution.
- **P1.3 Initial node sync.** Pass graph nodes through EIE `PacketRouter.notify_graph_sync()` or an existing Gate sync primitive to CEG, which validates and writes with `SyncGenerator`. Batch within existing limits; use existing idempotency and tenant permissions. No EIE Neo4j client or generic new graph writer.
- **P1.4 Actual relationships.** Extract only real provider associations / declared source links, using existing HubSpot `read_associations` and `observed_relationship_producer` when applicable. For an Odoo PlasticOS fixture, define relationship mapping from the *approved tenant spec and actual source fields*, then use CEG's already-existing typed relationship sync if the source adapter can supply evidence. Missing association is unknown, not fabricated. Node endpoints must exist before edge sync. `observed` asserts source membership only, not business relevance.
- **P1.5 Readback and coverage.** Query **CEG Neo4j** via the existing authorized graph read/test interface: correct IDs, distinct nodes, typed edges, source refs, absence of undeclared properties and no duplication on replay. Establish the initial domain gap set via CEG health-assess, not an EIE guess.

**Source owners:** EIE `app/services/crm/{base,hubspot_client,odoo_client,salesforce_client,observed_relationship_producer}.py`, `app/services/crm_field_scanner.py`, `app/services/domain_spec_workflow.py`, `app/engines/packet_router.py` (where necessary); CEG `engine/sync/generator.py`, `engine/handlers.py::handle_sync`, `engine/config/tenant_mapping.py`, `engine/health/api.py`.

**Exit P1:** Synthetic-but-source-shaped PlasticOS CRM data creates at least two correctly distinguished domain node instances or types (as actually declared) and one justified edge; a live CRM connector read may be separately demonstrated if credentials/access are present. Graph readback, namespace and association evidence, tenant isolation, replay dedupe, and an initial health-gap report all pass. An unavailable actual CRM source is recorded as a remaining environment gate, never a blocker to fixture implementation.

**Not included:** complete customer CRM sync engine, automatic full-history import, writing invented custom CRM fields, inference/provider migration.

## P2 | Durable, typed bidirectional EIE <-> CEG exchange

**Objective:** The product does not lose accepted/persisted intelligence if a worker crashes, a queue fills, or Gate/CEG is temporarily unavailable.

**Work items:**

- **P2.1 Outbound durable graph work.** Replace process-local-only `SideEffectCoordinator._graph_pending` as the *sole* durable record of pending sync. Reuse existing EIE PostgreSQL/store and idempotency identities; add the smallest table/record shape only if existing stores cannot represent pending payload/status. Persist original typed graph-eligible payload, tenant, entity, spec revision, operation key and delivery state before marking it safely deferred. Recover pending tasks after process restart. Do not repeat paid provider work to retry graph transport.
- **P2.2 Receipt semantics.** Separate `EIE_RESULT_DURABLE`, `GRAPH_PENDING`, `GRAPH_APPLIED/ACKNOWLEDGED` in existing operational diagnostics, **not** frozen `EnrichResponse` response states. Only graph ACK scoped to the expected entity/batch marks graph leg complete, and graph readback is required for final product proof. Failure/unknown remain retryable; bounded retry/circuit breaker applies.
- **P2.3 Durable inbound graph feedback.** EIE `GraphReturnChannel` is currently an in-process bounded tenant queue whose full-state path drops results. Reuse an existing durable EIE store to record accepted `graph-inference-result` payloads before acknowledging, with tenant/entity/rule identity and replay-safe dedupe. Drain only after application or stable handoff. Keep existing in-memory queue as acceleration only; never sole accepted truth. If durable intake unavailable, refuse/degrade rather than report accepted and discard.
- **P2.4 CEG feedback producer.** Preserve CEG `engine/gate_egress.py` Gate-only emitter and `handlers.py` domain-authorized inference rules; explicitly reconcile `graph_inference_feedback_enabled` (currently default-off), callback keys, confidence floor, and caller policy. Actual automated feedback triggering requires a justified EIE-owned trigger; an admin subaction's existence is not proof of a self-running bidirectional loop.
- **P2.5 Observed relationship replay.** Preserve CEG evidence-ref conflict checks and typed edge sync; an identical observation replays once, a changed conflicting assertion is refused with a visible outcome, and unknown transport ACK doesn't create duplicate edges.
- **P2.6 Existing Gate route hygiene.** Confirm why the EIE `score-invalidate` fire-and-forget path is unsupported in inspected Gate and whether CEG needs a cache invalidation action; fix at the existing owner only. Do not invent worker permission to invoke operator-only `score`.

**Source owners:** EIE `app/services/side_effect_coordinator.py`, `app/services/graph_return_channel.py`, `app/services/pg_models.py` / existing migrations/stores, `app/engines/handlers.py`, `app/engines/packet_router.py`; CEG `engine/gate_egress.py`, `engine/handlers.py`, `engine/sync/generator.py`; Gate only if its *current* canonical registry/policy is actually incompatible.

**Exit P2:** Crash after EIE persisted convergence but before graph ACK; recover and sync without re-researching. Crash after EIE graph feedback ACK but before consuming result; recover and apply once. Replay same node and edge, no duplicate or cross-tenant data. Queue-full/stale revision/Gate failure yields visible pending/refused state, never false `accepted` or `completed` graph claim. Verify against actual process restart and Neo4j readback, not mocks only.

**Not included:** new Redis stream/broker, distributed workflow framework, scoring internals, wide historical backfills.

## P3 | Inference Mesh Optimization + research/provider modernization

**Objective:** Execute the whole **existing v1.2.0 scope** after P1/P2 graph-state foundation. P0 reliability and source evidence work stay inseparable from inference/provider changes; no speculative architecture restart.

**Work items:**

- **P3.1 Deterministic closure first.** EIE `run_convergence_loop` runs existing versioned inference rules on all eligible known/graph facts before spending money. Fix existing `rule_loader` YAML/object mismatch and initial-pass unlock ranking. Zero, `false`, and empty/unknown obey declared types/meaning.
- **P3.2 Value-directed target choice.** Collect missing rule prerequisites even when absent from CRM / consumer target list; rank by unique reachable outputs, declared priority/gate necessity, evidence quality, cost/latency and no-call alternatives. Actual rule conditions and confidence floors decide whether downstream derivation materializes; no double credit.
- **P3.3 Provider reliability.** Eliminate duplicate identical variations, repair no-search false empty completion, bind retrieved search/citation facts to actual field evidence, and preserve D-9 v2 and source independence. DeepSeek no-web, sourced Search/Fetch and Perplexity Agent escalation follow `01`-`09`; no LLM-Router.
- **P3.4 Internal graph projection distinct from consumer response.** Correct the **critical cross-boundary loss**: existing external `converge` restricts to requested schema and `admitted_fields` syncs admitted v2 outputs; unrequested useful prerequisites are not automatically persisted. Use existing EIE enrichment state/feature/evidence stores and CEG's typed sync to materialize **separately eligible** facts or declared edges. Preserve frozen v2/CRM writeback; never leak unknown/unadmitted data. `evidenceonly` cannot simply bypass sync safety: domain owners must explicitly declare a writable typed graph representation or retain as evidence in its lawful owner, with visible withheld reasons.
- **P3.5 Close another inference cascade.** After a sourced acquisition, update EIE state and rerun cheap rules before new research; persist unique new facts with provenance. CEG graph results can become eligible input only with correct tenant/subject identity, provenance and confidence.
- **P3.6 Optional independent lane.** Retain the manual DeepSeek AI reviewer script/workflow update from v1.2 as **nonblocking**; do not make CI security/refactoring or review workflow modernization an obstacle to core product intelligence.

**Source owners:** EIE `app/engines/{convergence_controller,meta_prompt_planner,enrichment_orchestrator,inference_bridge_v2,inference_bridge_adapter,search_optimizer}.py`, `app/engines/inference/rule_loader.py`, `app/services/{perplexity_client,prompt_builder,consensus_engine}.py` (consensus not rewritten), `app/engines/convergence/field_evidence.py`, `app/engines/handlers.py`, `app/engines/packet_router.py`; approved tenant domain spec. CEG only for **spec-declared graph shape** if a new data representation is necessary; this work must not modify CEG business scoring semantics.

**Exit P3:** Existing `08` R01-R08 and `09` M01-M08 all pass; additionally one previously unrequested (but domain-declared) legitimate field remains **not written to CRM**, yet survives a CEG graph readback after an EIE research/inference run. Distinguish model-only claims, sources and actual rule derivations. Focused provider smoke with credentials or explicit blocked environmental requirement; no unjustified paid second call.

**Not included:** CEG ranking redesign, quantitative L9 SV solver, a CRM custom-field generator, broad Odoo offers changes, speculative autonomous agent memory.

## P4 | End-to-end graph intelligence, feedback and controlled readiness

**Objective:** Demonstrate that the enriched graph changes an actual authorized CEG score/match/readiness outcome and can drive another bounded EIE enrichment decision.

**Work items:**

- **P4.1 Readiness → enrichment → graph update.** Activate isolated EIE `enrichment-sweep` with Gate `health-assess` and existing ledger using test-tenant settings/keys. CEG returns critical gaps; EIE ranks and consumes only declared targets, then enriches through canonical converge, not a second enrichment controller. Recover after interruption. A CEG outage must not trigger fabricated readiness.
- **P4.2 Graph-backed CEG decision.** Execute allowed `match` and/or `score` under CEG's current domain spec. `remote_score_enabled` is default-off; use the existing secured local/test handler until explicit operator activation of remote score. Verify the graph is actually read and an evidence-backed dimension/gate is affected; do not equate a nonempty score with correct enrichment consumption. Preserve the tenant's review/admission rules for edge relevance.
- **P4.3 CEG → EIE feedback.** Use documented graph inference feedback and readiness results to expose a new valid gap/input; EIE acquires only where marginally justified. No CEG-triggered paid research without EIE ownership/authorization. EIE and CEG revisions and source references must remain inspectable.
- **P4.4 One representative PlasticOS journey.** Sparse CRM record → typed nodes/actual associations in Neo4j → health gaps → EIE inferred/researched unseen fields → CEG typed write → altered score/match → remaining gap → bounded second EIE pass. Prove stable identity, actual graph-state changes, evidence chain and deliberate no-CRM-writeback.
- **P4.5 Non-PlasticOS sentinel.** Same generic path passes a minimal second cartridge fixture to prove no hardcoded PlasticOS path. Use current test machinery, not a second product implementation.
- **P4.6 Interrupted replay and readiness receipt.** Deliberately restart EIE and simulate one Gate rejection; replay gets the same correct persisted graph, no duplicate edge, same admissible decision, no false success. Report exact source revisions, test environment, flags, token/research spend, observed outcomes and remaining production prerequisites.

**Source owners:** EIE `app/engines/enrichment_sweep.py`, `app/engines/sweep_handlers.py`, `app/engines/handlers.py`; CEG `engine/health/api.py`, `engine/health/gap_prioritizer.py`, `engine/handlers.py` and existing scoring/matching test harnesses; existing Gate action/permission owner. A runtime policy change occurs only at owner and with later authorization.

**Exit P4:** G1-G6 from `13_ACCEPTANCE_AND_HANDOFF.md` pass through a real signed Gate + EIE + CEG + Neo4j test rail. Live CRM/source availability and production rollout remain separately assessed. If one outcome cannot be proven, record exact missing fact and fix the earliest owning surface; do not claim product completion from three independent unit suites.

**Not included:** blanket production activation, autonomous customer CRM mutation, GDS/KGE redesign, broad multi-tenant onboarding product UX.

## Conversion of these phases to campaigns (DEFERRED)

Only when user later requests a specific phase to become an execution campaign: rebind current HEAD, resolved domain authority, applicable L9 projections, Gate action semantics, exact native test/make-pr interface and issue/PR state; choose noncolliding code lanes and one integrator; make each campaign **implement real code + focused tests + cross-repo proof + bounded remediation + publication handoff** rather than publishing contract prose. No phase may be marked done until its own integration exit conditions are verified. Follow-on phase can use previous receipts/artifacts, but reconfirm changed interfaces. This dev pack grants **no** merge, deployment or production data mutation authority.
