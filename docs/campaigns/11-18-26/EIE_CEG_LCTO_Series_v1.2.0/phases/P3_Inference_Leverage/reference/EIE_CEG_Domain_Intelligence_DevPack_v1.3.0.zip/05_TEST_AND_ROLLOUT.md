# Minimal verification matrix and rollout

**v1.3 scope:** This is the preserved **P3** test matrix, not a complete EIE+CEG readiness certificate. P0/P1/P2/P4 have their own concrete exits and six product gates in `13_ACCEPTANCE_AND_HANDOFF.md`. P3 external responses remain frozen; a separately admitted, CEG-typed **internal graph projection** may carry eligible unrequested knowledge without CRM writeback changes.

Keep validation proportional: R01-R08 in `08_P0_RESEARCH_RELIABILITY.md` plus M01-M08 in `09_P0_INFERENCE_MESH_SV_HARVEST.md` are the **required P0 core regressions**. Combine overlapping witness fixtures rather than doubling test infrastructure. Reuse existing unit/contract/integration tests plus one credentialed smoke per provider. No new test harness, LLM judge or blanket source validator. Discover exact commands from the current repo; none are guessed in this development pack.

| ID | Case | Expected proof |
|---|---|---|
| T01 | Rule-derived target or consumer-known-only no-op | Zero paid calls; rule output has versioned derivation; original input only `observed` and unadmitted; state/side effect compatible |
| T02 | Domain rule derives one field from known facts | Rule runs before research; provenance retained; zero provider calls |
| T03 | Unknown public company capacity with no data | Not fabricated; external search or unknown |
| T04 | Mixed existing data includes `False`, `0`, `None` | False/0 survive, null remains unknown |
| T05 | Structured normalization from an input document | Flash no-web; correct type; no web tool; attributed provider `external_claim` not deterministic `inferred`; explicit input/reply provenance |
| T06 | Simple public fact researched | Actual search tool result observable; field tied to retrieved source and resolvable provider reply id |
| T07 | Flash web search tool declared but unused | No unsourced external fact admitted as researched |
| T08 | Conflicting public sources | Conflict/unknown or source-specific resolution; no confidence inflation |
| T09 | First incomplete provider reply | No identical concurrent fanout; next pass targets missing field; count actual calls; existing consensus score preserved |
| T10 | DeepSeek timeout / 429 / malformed JSON | Bounded failure or justified fallback; never accepted default; no nested unbounded retry |
| T11 | Perplexity Agent migration | Live or sandbox credentialed request, correct parser/citations/usage, no obsolete request fields |
| T12 | Shared 30s budget nearly spent | No new expensive call beyond remaining deadline; degraded/failed as existing contract |
| T13 | Field evidence v2, output schema, graph sync | Accepted-only fields; no change to subject identity, proposal semantics, CEG sync/writes |
| T14 | Deterministic provider staging/prod attempt | Existing startup guard refuses synthetic provider |
| T15 | Mixed tenant ids / same idempotency key | No cross-tenant cache or leakage; existing replay semantics |
| T16 | Manual DeepSeek AI review workflow (independent) | Manual trigger only; pass/block marker preserved; missing-secret path handled |

## Small comparative evaluation (production-enablement, not a pre-PR blocking gate)
- Start with approximately 8-12 representative cases across deterministic, input-only, public lookup and difficult public claims. Expand to 24 only if staging results leave accuracy, costs, or source attribution unclear.
- Capture per case: requested fields, correct/incorrect/unknown, independent evidence URL, calls by provider/model/search/fetch, token usage, calculated dollar usage where supported, latency, timeout/response state, v2 evidence and writeback readiness.
- Compare prior Perplexity behavior to new default; do not equate uncalibrated model confidence with accuracy.
- Acceptance for PR: focused R01-R08 and M01-M08 behavior, including proven first-pass leverage and multi-hop nonduplication, no false-success on `disable_search`, no unauthorized schema drift, credentialed provider smoke or explicitly blocked runtime credential. For later production-default enablement: zero paid calls on deterministic cases, zero web calls on input-only cases, source-required external fields not admitted without attributable retrieval evidence, and documented correctness/latency/cost comparison. If savings are unproven, do not claim economic improvement or flip defaults.

## Staged rollout
1. Rebase on current EIE main and verify existing tests. Inventory any changed endpoint/config ownership; do not rewrite unrelated architecture.
2. Implement under a default-off provider-routing switch, preserve existing API behavior behind rollback. Do not turn on an untested Perplexity legacy endpoint as a fallback if it is retired: rollback to last verified working provider route/feature setting or explicit degraded status.
3. Run targeted tests and credentialed DeepSeek + Perplexity Agent smoke using existing secrets; redact outputs, verify budget and citations.
4. Run minimal staging comparisons; expand only where evidence is insufficient. Make routing selectable for staging only after source and provider tests; separately authorize any production default.
5. PR publication is separate from merge/deploy. Production enablement requires its own authorized deployment gate, config/secret injection and smoke evidence; this ZIP grants none.

## Stop conditions
- Provider docs/client behavior disagree: stop affected provider mapping and keep other lanes moving.
- V2 cannot truthfully represent model inference with existing contract: stop that admission behavior, do not invent `observed` or `external_claim`.
- A provider-only P3 change unexpectedly requires unrelated external API changes: block that provider slice. Known scoped graph-domain changes belong at P0/P1/P3 and the current CEG owner; do not use this stop rule to skip product graph hydration.
- Runtime secret not supplied to EIE: report exact injection gap without exposing value. User should not be asked to generate another key before checking existing Infisical/Actions scopes.

## New P0 cases supersede weaker wording above
`08_P0_RESEARCH_RELIABILITY.md` defines the exact R01-R08 behaviors, including missing/retrieved URL checks, contradictory sources, real `disable_search` execution, zero-provider authorization and the explicit v2 observed/inferred/external_claim distinction. Do not pass an older generic T-case while failing its stronger R-case.

## Inference-mesh proof and cost comparisons (v1.2)
- Assert **both directions**: one sourced acquisition -> multiple valid derived outputs, and multiple cheap supported facts/inference steps -> one important previously blocked outcome.
- A comparative case should prove a higher-cost call wins only when its *distinct, declared-value* downstream gain justifies it; when probabilities or comparable units are not evidenced, test a stable qualitative order and report objective-relative optimality `unknown`.
- Count actual provider calls, actual derived output identities, separately billed search/fetch when measurable, exact remaining required gaps and source lineage. Predicted unlocks and realized derived fields are different diagnostic metrics.
- Ensure at least one initial-pass test would fail under the existing discovery-mode ranking bypass or raw-YAML `score_unlock_potential` zero-weights defect. At least one reconvergent-path test must fail if the same output is counted twice.
- These tests are required for the P3 core implementation PR, not a demand for a new benchmark harness, new CI class, or independent Strategic Value engine. They do not prove live production ROI or L9 quantified SV.
