# LOCKED P3 architectural decisions | preserved in v1.3.0

**Scope reinterpretation:** This document preserves v1.2.0 **Phase P3** inference/provider behavior. The expanded EIE + CEG product architecture is governed by `10_PRODUCT_ARCHITECTURE_AND_BOUNDARIES.md`, with phased cross-repo work in `11_PHASED_BUILD_AND_WORK_PACKAGES.md`. EIE/CEG/Gate changes justified by phases P0/P1/P2/P4 are IN SCOPE at their existing owners; this P3 document must not silently veto them. This is still a development design, not code-implementation or deployment authority.

The provider/inference choices are frozen *within P3*; an observed source contradiction or changed API requires an explicitly bounded reconciliation, not a redesign.

## Invariants

1. **Existing canonical owner wins.** Reuse EIE's `run_convergence_loop`, `enrich_entity`, `InferenceBridge`, `MetaPromptPlanner`, `ConfidenceTracker`, `SonarConfig` where still applicable, existing persistence/side-effect coordinator, Gate and CEG contracts. No parallel coordinator, registry, queue, generalized plugin framework or LLM-Router.
2. **Inference and gaps precede web research.** Use existing domain inference engines over consumer-known facts before provider dispatch, with explicit inputs and provenance. Existing inputs do not become independently verified solely because supplied by consumer. Do not accidentally conflate null/unknown with false or zero.
3. **Deterministic no-call first, with truthful status.** Run existing rules over available consumer/graph facts before planning research. A rule-produced required output meeting the existing readiness bar needs no provider call. Consumer-supplied values remain `observed`, unadmitted to newly produced `fields` in response v2; they cannot be assigned synthetic tracker confidence to force convergence. A known-only no-op is returned only through compatible existing status/side-effect behavior. If an output field needs external evidence, no-call is not permission to fabricate it.
4. **DeepSeek no-web second.** For transcription, schema normalization and extraction from explicitly supplied text, use `deepseek-flash` without web tools when rules alone are insufficient. In frozen v2 evidence, model-produced fields are attributed provider `external_claim` entries with input/reply lineage (not `observed`, not rule-derived `inferred`, not a verified public fact). Only actual versioned domain rules produce `inferred`. Untraceable model-only speculation remains unadmitted.
5. **Grounded simple search next.** For external facts, use DeepSeek standalone Search/Fetch or Flash web tools. For fields where source evidence is a prerequisite, require actual search/fetch tool-result evidence; declaring an optional server tool is insufficient. Record usable source URLs/title/date and the field they support.
6. **Escalate deliberately.** Escalate to Flash thinking, then where necessary `deepseek-v4-pro`, then Perplexity Agent for genuinely complex/ambiguous/contradictory research, coverage gaps or independent corroboration. A second call is justified by a named unresolved field and expected evidence gain, not merely a low mean score or a fixed number of variations. Provider outage may trigger a bounded alternative only when it meets the same evidence requirement and the remaining deadline; fail visibly otherwise.
7. **Source independence is not assumed.** Multiple calls to the same provider/search index are correlated until proven otherwise. Existing consensus scoring already prevents identical replies inflating the field score: preserve that math. Avoid duplicate same-prompt acquisition; a genuinely new request requires an unresolved target or distinct retrieval need. Preserve D-9 v2: worst required field sets action uncertainty; U_mean diagnostic only; every required field must meet its own bar.
8. **One budget, one retry owner.** Respect existing caller `max_variations`, shared 30-second converge deadline, request token ceiling, budget accounting and circuit breaker; don't create nested SDK retry trees. Do not let fallback create open-ended API spend or exceed deadline.
9. **No response-contract drift.** Preserve canonical `EnrichRequest`, `EnrichResponse`, frozen v2 evidence states/source shape/identity, proposal behavior, no unadmitted fields synced to CEG, and Odoo writeback contract. Never map a DeepSeek model-only result into `inferred`: that state is reserved for actual versioned deterministic rules. Reuse internal provider-reply lineage and existing `feature_vector`/raw payload surfaces; when an external source is required, missing genuine field-specific retrieval evidence must prevent field admission. If the frozen contract cannot express a material obligation, block that lane instead of altering the contract.
10. **No accidental egress from tests.** Existing explicit local/dev/test deterministic source remains test-only and never a hidden provider fallback in staging/prod. Secrets remain environment-provided.
11. **No Google search dependency.** The legacy Google Custom Search JSON API is closed to new customers and sunsets 2027-01-01. If usable search is free through existing local/cached data, consume it; do not scrape Google or introduce a new Google connector.
12. **Provider selection is implementation detail, not new L9 canonical semantics.** The architect fixes the behavioral intent; exact wire shapes are selected from current provider docs and proven by tests before use.

## Small routing decision table

| Input / gap condition | First action | Required outcome |
|---|---|---|
| No newly required work; consumer already has values | No call / compatible no-op | Consumer inputs remain observed and unadmitted as new fields; no false success/side effect |
| Existing rule derives a missing required output | Existing inference before planning | Store versioned derivation with inputs; no model call |
| Explicit document/text to normalize, no new external assertion | Flash no-web | Typed transformation with precise input provenance; unknown when unsupported |
| Simple public fact needing sources | DeepSeek Search/Fetch + Flash extraction (or Flash web tool with proven tool results) | Field-level source trace; bounded cost |
| Multiple ambiguous/conflicting sources | Flash thinking / DeepSeek V4 Pro as warranted | Evidence-sensitive resolution, else conflict or unknown |
| Coverage/quality remains insufficient | Perplexity Agent escalation | Independent research opportunity; do not assume independence |
| Budget/deadline/provider exhausted | Bounded degraded/failed/unknown per existing contract | Never silently accept guessed facts |

## Explicit non-goals (P3 provider/inference substream only)
- No broad source waterfall repair. Existing `WaterfallEngine` is currently dormant and broken by conflicting provider configs: don't activate it.
- No custom HTML scraping, crawler, search-index infrastructure or separate microservice.
- No redesign of CEG scoring/matching business semantics or Odoo offers/profiles in P3. Graph schema compatibility/projections and **actual CEG scoring/match proof** are separately in scope in P0/P1/P4. No rewrite of the Odoo repository.
- No re-run of ERP normalizer or Odoo migration.
- No unrelated API client upgrades, refactors, CI rewrites or new org-level law.
- No automatic rollout to production or merging any PR.

## P0 acceptance overlay (mandatory)
`08_P0_RESEARCH_RELIABILITY.md` is part of this locked design. Resolve the actual observed source defects there before claiming core provider modernization is complete: pre-research inference, no duplicate identical variation fanout, correct `disable_search` behavior, field-specific provider source trace. No new orchestrator/validator or rewrite of `consensus_engine.py`. This is still a development handoff, not a CTO execution campaign.

## P0 local product invariant and canonical Strategic Value reuse
**Acquire the smallest, cheapest piece of information that unlocks the greatest downstream intelligence.** This is the controlling EIE product behavior. `09_P0_INFERENCE_MESH_SV_HARVEST.md` is an accepted additive contract, not an option. It orders the provider modernization and P0 reliability changes toward useful **multi-hop unlocks and decision-relevant outputs**, not only minimum token count. The EIE-local acquisition score is an ordinal operational heuristic unless comparable, evidence-backed business utility/cost/probability inputs exist. It is **not** a full `l9.strategic.value@1` numerical claim or an EIE copy of canonical `.github` semantics. Preserve hard requested fields, per-field readiness and evidence truthfulness, and do not require Q/V/5-bucket SV machinery.

**Priority order:** safety/contract/source integrity and resource hard limits are noncompensable; among admissible choices, derive with existing rules before paying; then acquire the cheapest **supported** prerequisite with the highest attainable distinct downstream value, recomputing after each actual result. Use real rules/weights, never invented dependencies or probabilities. The research call with the lowest standalone price is not necessarily the lowest-cost route to the consumer's objective.
