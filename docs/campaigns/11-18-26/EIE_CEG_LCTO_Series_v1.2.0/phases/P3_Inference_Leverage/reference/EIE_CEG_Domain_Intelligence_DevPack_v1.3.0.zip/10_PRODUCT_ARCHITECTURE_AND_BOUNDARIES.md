# EIE + CEG | Product architecture and immutable boundaries | v1.3.0

## Product promise

**"We turn 2D CRM data into 3D domain intelligence graphs."**

A client's CRM is a starting set of records and observations, never the ceiling of the knowledge model. The approved tenant/domain spec declares a richer ontology, valid node/edge types, field names and types, identities, derivations, evidence obligations, and domain-relevant downstream requirements. EIE identifies and backfills knowledge **the client never created a CRM column for**, while CEG owns the persistent entity-and-relationship graph and converts that knowledge into readiness, evidence-based scoring, matching and useful next gaps.

**EIE local invariant:** acquire the smallest, cheapest piece of information that unlocks the greatest downstream intelligence, subject to explicit source/evidence, confidence, permission, budget and declared domain conditions. The next item may be an unrequested prerequisite, not merely a missing CRM field. The same fact may unlock several unique downstream fields. Conversely, several cheap facts may unlock one important gating field.

**Two cooperating engines, not competing graphs:**

1. **Source:** The connected CRM and other approved external sources provide initial observations (entity records, native field metadata and actual associations), with stable source references.
2. **Domain definition:** One approved tenant-cartridge semantic source is projected for EIE and CEG through their existing native publication and validation mechanisms. An EIE inference dependency DAG is a rule graph, not a substitute for the CEG entity graph.
3. **Graph creation:** CEG materializes admitted, typed nodes/relationships with tenant-scoped stable IDs, evidence, provenance, and domain-approved meaning. No direct EIE Neo4j writes.
4. **Gap discovery:** CEG evaluates graph readiness/gates; EIE combines those declared gaps with domain rule dependencies and value/unlock information. The CRM schema does not constrain the internal universe of discoverable domain fields.
5. **Acquisition:** EIE infers first, then selects the least costly defensible retrieval/extraction/research needed to unlock meaningful downstream intelligence. Its external response and consumer CRM writeback remain bounded to their own frozen request/approval contracts.
6. **Hydration:** EIE proposes graph-eligible facts and relationships through Gate, using the tenant's typed projection. CEG decides what can be written and persists accepted additions.
7. **Decision:** CEG scores and matches against actual persisted, evidenced graph state. Readiness/scoring gaps can inform further EIE acquisition, without CEG performing independent paid research or EIE owning scoring.
8. **Feedback and iteration:** Subsequent observations, outcome evidence, re-evaluation, and inexpensive inference can enrich the same stable graph without identity churn, duplicate links or invented corroboration.

## Explicit ownership

| Concern | Authoritative owner | Non-owner boundary |
|---|---|---|
| Meaning of PlasticOS nodes, attributes, relationships, acquisition priorities, and valid inference rules | Approved **tenant/domain** artifact, consumed in compatible projections | Neither engine hardcodes PlasticOS semantics or creates a second canonical spec |
| Domain spec publication/admission | Each repository's **existing** native/approved publication pipeline; shared semantic origin must be resolved in Phase 0 | A copy in a test folder or archived CEG YAML is not production authority |
| Consumer CRM source record, native associations and source-side IDs | CRM via existing EIE connector | CEG may store source ref but does not mutate CRM |
| Source reads, schema mapping, inference and research decisions | EIE | CEG does not select paid research providers |
| Typed graph persistence, node/edge identity, relationship admission, graph fact retrieval | CEG | EIE never writes Neo4j directly |
| Readiness and graph gap evaluation | CEG `health-assess` | A failed/unavailable CEG response is unknown, not EIE-invented readiness |
| Graph facts vs CRM outputs | EIE proposes graph-eligible facts with evidence; CEG admits and persists; CRM writes separately authorized | A frozen `converge` response's requested schema is not the graph's universe |
| Matching, commercial scoring and graph inference relevant to decisions | CEG under tenant spec and enabled actions | EIE qualitative acquisition heuristics do not become business scores |
| Cross-node transport/caller permissions | Existing Constellation.Gate owner/SDK | No direct HTTP between engines, no new routing plane |
| L9 canonical strategic value | `Quantum-L9/.github` | EIE harvests qualitative comparison rules, not a global SV runtime |

## Seven locally locked invariants

1. **Spec-first graph:** Every persisted domain field or relation must be admitted by a compatible approved spec, and observed external associations must retain source provenance and tenant identity. Missing declaration = no write, plus visible omission, never silent dropping as a claimed success.
2. **Intelligence beyond CRM:** An internal graph-eligible fact is not lost merely because the client never requested, defined or approved a corresponding CRM field. A CRM-facing `converge` result MUST still obey frozen request/v2 field admission and writeback controls. Implement independent internal graph projection from existing enriched/inferred/evidenced state when justified; do not silently broaden the external response.
3. **One graph writer:** CEG owns all durable graph writes and validates node/edge declarations. A sync ACK without a readback does not prove downstream scoring effectiveness.
4. **No false observation:** `observed` source association, `external_claim`, deterministic `inferred`, CEG-inferred/graph-sourced, unknown and conflicting do not collapse into one certainty score. Do not promote a model result to a direct observation.
5. **Loss-aware cross-engine delivery:** A receiver's `accepted` means only the documented durable milestone. No process-local queue can be the sole durable holding place for accepted work. Retries are bounded, idempotent, tenant-isolated and safely recoverable after restart.
6. **Value-bounded research:** Use actual unique downstream unlocks and declared strategic priorities, not naive missing-count, synthetic success probabilities, or fabricated quantified L9 SV scores. Stop on marginally unjustified acquisition and preserve actual spend.
7. **Feedback with ownership:** CEG's graph inference/readiness and EIE's enrichment are mutually reinforcing, but feedback never bypasses Gate or independently expands the approved domain schema. Both sides retain causal/evidence and execution lineage.

## The three forms of graph data and why they differ

- **Rule graph**: EIE's dependency DAG, controlling which prerequisites can unlock inference rules; ephemeral execution mechanism, not customer graph persistence.
- **Entity/relationship graph**: CEG's domain-authorized Neo4j nodes and typed/evidenced edges; persistent tenant intelligence, independent of CRM field coverage.
- **Consumer projection**: An API response or CRM writeback with only fields permitted by that specific consumer/contract; intentionally narrower than EIE's working state and CEG's graph.

**Critical implementation trap:** `handlers._run_canonical_converge()` currently restricts response fields to the consumer schema, and `admitted_fields()` selects from admitted response evidence. `packet_router.project_graph_sync_row()` drops undeclared / `evidenceonly` properties. Simply enriching unrequested prerequisites will not guarantee they reach CEG. Phase 3 must provide a separately governed **internal graph-eligible projection** using existing state and Graph sync, while preserving the frozen v2 external response. This is a focused local compatibility question, not permission to widen v2 or bypass CEG's typed validation.

## Feature boundaries and non-goals

- **In scope across phases:** EIE, CEG, existing tenant spec artifacts/admission surfaces, and bounded Gate registry/permission compatibility corrections; source-aligned code changes and tests for those owners only.
- **Not in scope:** Rewrite Odoo/HubSpot/Salesforce, add arbitrary CRM fields, rebuild Gate, add a message broker, invent a second graph DB, build a new ontology agent, introduce product/business-specific conditionals into generic engines, expand offers, revamp GDS/KGE, automatic sales actions, or turn this development design into an executable CTO campaign.
- **Runtime enablement:** Test fixtures and an isolated multi-service deployment first. Production flag activation, secrets, data access, merges and migrations require later separate authority. Current source snapshots are not evidence of a deployed end-to-end system.
- **Optional downstream:** Broader RevOps autonomous agents and user-facing CRM writeback expansion follow only after the graph produces real, evidence-backed score/match results.

## Counterexamples this architecture must defeat

- Same company appears in two CRM resources: source references remain distinguishable; one tenant graph identity is resolved only when source/approved rule allows it, never by unverified name similarity.
- Same field inferred from two paths: derived target credited once and provenance retained; no fake independence.
- A field is absent from CRM but declared by the domain: EIE may acquire it, CEG may persist it, but CRM output remains unchanged unless authorized.
- CEG receives unknown/untyped property or wrong tenant association: refuses/withholds with visible reason, no partial "success" label.
- Worker dies after `accepted` or after EIE `completed`, but before CEG applies graph sync: work replays safely and graph eventually converges after recovery.
- Graph or Gate unavailable: no synthetic readiness, no false graph-complete acknowledgment, no duplicate expensive provider calls solely to recover graph transport.
