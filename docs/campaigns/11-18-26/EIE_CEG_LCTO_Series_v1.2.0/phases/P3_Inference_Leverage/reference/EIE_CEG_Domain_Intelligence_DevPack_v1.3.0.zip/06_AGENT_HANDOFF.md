# Future sequential CTO / LCTO handoff design (NOT ACTIVATED)

## In-scope future repository targets (NOT permission grants)

```yaml
phase_target_repositories:
  eie: https://github.com/Quantum-L9/Enrichment.Inference.Engine
  ceg: https://github.com/Quantum-L9/Cognitive.Engine.Graphs
  bounded_gate_seam: https://github.com/Quantum-L9/Constellation.Gate
read_only_semantic_and_governance:
  canonical_l9: https://github.com/Quantum-L9/.github
  future_publication_owner: https://github.com/Quantum-L9/Cursor-Governance
permissions_and_commands: must_be_reverified_before_campaign_conversion
```


**Target revision inspected:** EIE `29d4eb54942e446a9ac917d2ebe2d9733a4e7aec`. Canonical `.github` head observed `00500268eb24de29a5e647a447d6f992d609f6f5`; Cursor-Governance head observed `59c0b3e0fae7418c67b7e3be76c4e3f412ad49dd`. Revalidate at actual execution; these refs are not permissions or a produced/verified GAR projection bundle.

**Operator intent:** Deliver the complete EIE + CEG product across **five sequential execution campaigns only when subsequently requested**. Preserve original P3 inference/provider work intact, including P0 research reliability and leverage optimization; broaden distinct phases P0/P1/P2/P4 to necessary CEG and Gate owners without duplicate governance systems. Each future campaign must implement real source changes, run source-native focused and cross-repo tests, own remediation and produce a reviewable PR through verified current LCTO transport. Nothing here authorizes campaign activation, default deployment or merges.

## Implementation approach (original P3 lane, NOT the five-phase sequence)

**Before this P3 lane:** complete/reuse P0 domain compatibility, P1 initial CRM graph and P2 durable two-way handoffs. All original provider-specific tasks below remain valid for P3 and can be parallelized with the independent manual reviewer edit, without shared-file collision. **For phase P0/P1/P2/P4 implementation work see `11_PHASED_BUILD_AND_WORK_PACKAGES.md`.**
1. When the operator later invokes execution, inspect exact current target paths/tests and provider docs; bind the then-current EIE head and authoritative governance projections. Treat this source map as a starting point, not executable commands.
2. Core P3 lane **internal P0 reliability and inference first**: implement `08_P0_RESEARCH_RELIABILITY.md` AND `09_P0_INFERENCE_MESH_SV_HARVEST.md` alongside DeepSeek client and scoped provider branch, Perplexity Agent migration, traceable field evidence, deadlines/costs and config. One implementation owner edits shared orchestration/config files. Do not launch a separate research reliability lane or new framework.
3. Independent lane: manual AI review script + workflow DeepSeek swap. It may run concurrently with core but cannot touch core/shared provider files. It must not stall core delivery.
4. At a later authorized campaign, the integration owner resolves branch topology and current governance authority, verifies API v1/v2 plus both P0 suites (R01-R08 and M01-M08), and publishes a reviewable PR only through the verified, current Cursor-Governance ceremony with actual operator/executor permission. No publication action is authorized *now*. Do not improvise push or guessed commands.
5. Return files changed, behavior matrix, test results including actual provider smoke, measured cost/accuracy, PR link and precise unresolved blockers. A green test is not runtime production readiness.

## No command authorization
This is a **development pack**, not a compiled execution/GMP campaign. Exact repo-native commands, Cursor-Governance `make pr` ownership, and publication permissions must be resolved from currently inspected code and operator/executor session authority; the pack deliberately emits no guessed terminal commands.

## Early questions the coding agent must answer from reality rather than operator clicks
- Does current `main` still use legacy Perplexity `chat.completions.create`, and can it be migrated without breaking the internal `SonarResponse` contract?
- Does DeepSeek's actual chosen API return field-attributable citation/tool execution data? If not, use standalone Search/Fetch for source-required fields.
- How will no-web model-produced fields remain attributed provider `external_claim` entries with input/reply lineage, while only versioned domain-rule outputs are `inferred`, without changing frozen v2?
- Which exact existing env/Infisical profile is bound to deployed EIE, not just CI?
- Does existing automated AI-review workflow consume any Perplexity-specific response beyond textual review and verdict marker?

**Do not relitigate:** provider hierarchy, no-Google choice, existing D-9 v2 readiness, frozen external response contracts, no new router, no unrelated CEG scoring changes, no human approval for normal internal implementation choices within an authorized phase.

## Conversion trigger for a future CTO campaign
Only after explicit operator authorization, convert **one selected phase P0-P4** from this development pack into a current-source-bound, governed CTO/LCTO execution campaign with actual implementation work, integration testing and remediation. Do not compile the entire multi-phase pack into a single undifferentiated campaign. Rebind EIE source revision and read-only authority/governance, resolve actual projection/permissions and executable command ownership, then specify lane topology and a single final publication owner. Keep `08_P0_RESEARCH_RELIABILITY.md` and `09_P0_INFERENCE_MESH_SV_HARVEST.md` as mutually consistent **P3** functional acceptance objectives unless source evidence requires a bounded correction. This pack itself never launches agents, executes tests, publishes a PR or deploys.

## Conversion-specific donor and authority notes
The SV harvest is **donor semantic reuse**, not a new runtime `strategic_value_model` engine, domain projection binding or quantitative L9 SV claim. Preserve `.github` as the read-only semantic owner; do not mutate it for the P3 EIE implementation lane. At CTO campaign compilation re-resolve current `.github` canonical source revision and EIE HEAD, ensure user-specified inferred-field leverage objective still matches source contracts, then delegate bounded EIE implementation under the same sole core code owner. No extra agents implementing the same planner/inference/controller files concurrently.
