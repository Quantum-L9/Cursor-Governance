# P0 Inference Mesh Optimization | L9 Strategic Value donor harvest | v1.2.0

**Status:** ACCEPTED DEVELOPMENT INTENT, NOT IMPLEMENTATION. **Priority:** P0, governing functional outcome of the existing provider and research reliability work. The operator's EIE-local product invariant is:

> **Acquire the smallest, cheapest piece of information that unlocks the greatest downstream intelligence.**

This means information **valuable to declared consumer outcomes**, not raw field-count maximization or an ungrounded claim that a full L9 Strategic Value assessment was executed.

## 1. Donor authority and semantic boundary

**Donor:** `Quantum-L9/.github` at inspected `main` SHA `00500268eb24de29a5e647a447d6f992d609f6f5` (2026-11-18). Canonical anchors:

- [`semantics/invariants.yaml`](https://github.com/Quantum-L9/.github/blob/00500268eb24de29a5e647a447d6f992d609f6f5/semantics/invariants.yaml): `L9-SV-001`, `L9-SV-002`, and admitted qualitative `L9-SVQ-001`, `L9-SVQ-002`.
- [`semantics/strategic_value_model.yaml`](https://github.com/Quantum-L9/.github/blob/00500268eb24de29a5e647a447d6f992d609f6f5/semantics/strategic_value_model.yaml): causal accounting, marginal information and optional compute, comparison to baseline, uncertainty, no duplicate effect credit; retained former candidate meanings are model/contract text, **not separately admitted invariant IDs**.
- [`semantics/vocabulary.yaml`](https://github.com/Quantum-L9/.github/blob/00500268eb24de29a5e647a447d6f992d609f6f5/semantics/vocabulary.yaml): `decision_relevant_information_value`, `value_propagation_mesh`, `capability_unlock`, `future_work_elimination`, `decision_boundary`.
- [`semantics/contracts.yaml`](https://github.com/Quantum-L9/.github/blob/00500268eb24de29a5e647a447d6f992d609f6f5/semantics/contracts.yaml): `l9.contract/strategic-value-assessment@1`, including claim applicability and nonduplication requirements.
- [`docs/adr/ADR-029-strategic-value-foundation-and-composition-provenance-criteria.md`](https://github.com/Quantum-L9/.github/blob/00500268eb24de29a5e647a447d6f992d609f6f5/docs/adr/ADR-029-strategic-value-foundation-and-composition-provenance-criteria.md): 2026-11-08 admission record.

**Beneficiary:** `Quantum-L9/Enrichment.Inference.Engine` at inspected `main` SHA `29d4eb54942e446a9ac917d2ebe2d9733a4e7aec` (2026-11-18). This pack compares source text observed at those revisions. It does **not** claim producer-validated projection consumption, formal `l9.authority-resolution/v1`, a validated `harvest.json`, a global semantic admission, or a new EIE projection binding. A future CTO campaign must rebind both heads and resolve its applicable projections/authority.

**Applicability:** The quantitative `L9-SV-001`/`002` full five-bucket accounting and numerical method obligations apply when an assessment **claims quantified Strategic Value**. EIE's near-term acquisition ordering is an **ordinal/qualitative domain optimization**, so harvest its transferable safeguards without claiming full SV calculation. Do not copy canonical law into EIE or grant EIE Numerical Reasoning/CEG business authority.

## 2. Harvest disposition, minimal local meaning

| Donor meaning | EIE local reuse | Disposition / consequence |
|---|---|---|
| `decision_relevant_information_value` | Favor facts that help meet declared required fields, domain outcomes and downstream decisions, not merely fields that are blank | **CONFIGURE existing planner**, not a new SV score |
| Feasible baseline / `L9-SV-001` comparison principle | Compare acquiring the next fact to what the current in-memory facts, rules and graph already produce, plus bounded `STOP`/`WAIT` | **MERGE WITH EXISTING** no-call and convergence logic; not full causal valuation |
| Mesh / `L9-SV-002`, causal-accounting model, former SV-004/006 | Trace multi-hop unlocks and count each *distinct material output* once across reconvergent rules and paths; preserve negative/failed paths | **HARDEN existing unlock scoring**; no loop-bonus or duplicate field credits |
| Capability unlock / dependency unlock | Missing intermediate prerequisites may be acquired even when not directly in consumer target schema, if they can unlock required outputs | **CONFIGURE planner gap candidates**, never expand returned output schema |
| Information and compute marginal value / former SV-009/010/013 | Favor the least costly available way to produce *useful* supported evidence, including inference-only, no-web LLM, targeted search, reasoning, wait or stop | **USE existing controller/router/budget**, not Q/V solver |
| `L9-SVQ-001` qualitative appraisal | If weights, comparable costs or research-success estimates are not grounded, use a conservative priority ordering and say it's a heuristic | **REUSE claim boundary**; no fabricated exact SV or ROI |
| `L9-SVQ-002` and forecast/realization split | Predicted unlock count is a plan, actual derived fields and downstream consumption are separate results | **REUSE existing pass result/trace**; do not claim realized business compounding just because a rule fired |
| Uncertainty/sensitivity | Conflicting external evidence or low input confidence can block a theoretically attractive inference path | **REUSE v2 evidence + D-9 v2**; unknown stays unknown |

**Reject/defer:** Full five-bucket SV framework, numerical owner receipts, Q/V belief recursion, stochastic optimizer, Strategic Planner projection/binding inside EIE, new value/accounting tables, additional canonical invariant, new source schema, broad graph rearchitecture, inference-agent swarm, and EIE-level matching/revenue priority policy. Defer statistical calibration until a real beneficiary/business objective needs it and evidence permits.

## 3. Observed source gaps to fix, at owning code

1. **Initial decision is blind to current unlock map.** `app/engines/convergence_controller.py::run_convergence_loop` calls `MetaPromptPlanner.plan_pass()` before `InferenceBridge.run()`. It prioritizes from a **previous** pass's unlock map, so Pass 1 can pay for broad research before free rule cascades identify the best prerequisite. Invoke existing rule engine after graph seeding, before planning, and again after provider evidence. Preserve observed input provenance (no synthetic confidence) and existing derivation invalidation/retraction.
2. **Value scorer reads the wrong shape.** `app/engines/inference/rule_loader.py::score_unlock_potential` uses `hasattr(domain_spec, 'ontology')` object-style access. `MetaPromptPlanner` receives the raw mapping from `handlers.py`, so the scorer's property map is empty on this canonical path and weighted downstream contribution is **zero**. Reuse `MetaPromptPlanner._property_metadata`/`_named_property`-style YAML traversal; handle dict/list nodes and properties without a second metadata schema.
3. **First discovery pass bypasses leverage ranking.** `app/engines/meta_prompt_planner.py::_rank_fields` immediately returns all gaps in discovery mode. Use the existing ranked candidates for the first pass too, subject to caller-required field preservation and D-9 v2 thresholds. The budget/variation authorization owner does not move.
4. **Missing prerequisite is not always a direct gap.** `_identify_missing_fields` mostly considers present entity keys, required fields and hints. Walk the **existing declared rule dependency/condition index** backward from unresolved valuable/required outputs to form additional *acquisition candidates* for absent prerequisites. No speculative inference edge; do not expand the requested output schema. Deduplicate field names.
5. **Multi-hop value is underrepresented.** `inference_bridge_v2.py::_compute_unlock_values` counts immediate blockers, while condition rule unlock analysis is rule-local. Extend ranking using the **current finite declared graph/rule registry** with bounded reachability. Credit distinct unresolved downstream output identities, not every path or repeated condition; only executable known-version rules can generate derived values. For multi-premise rules, conditional partial credit must not be represented as guaranteed output.
6. **No real cost comparison yet.** `app/engines/search_optimizer.py` estimates Sonar-only cost and `CostTracker` uses one token rate. For acquisition-choice comparison, re-use existing estimate surfaces and provider-measured usage, with a minimal cost lookup for configured choices. If cost/success chance is unknown, do not substitute 0 or invent normalized ROI; choose conservative ordinal ordering constrained by source adequacy, deadlines and existing budget. Track token plus separately billed search/fetch where returned. Avoid growing a new cost modeling service.
7. **PlasticOS example is thin, not proof of general design failure.** `domains/plasticos/spec.yaml` has three explicit conditional rules (two for `material_grade`, one for `tier`), no `derived_from` edges or `scoring_weight` declarations. Reuse the existing rules (do **not** fabricate a second ontology). Domain owners can optionally declare justified weights/priorities later. A real `processed_polymers`, `capacity_tons_month`, `contamination_tolerance` path should already unlock grade then tier if its conditions hold. Other domains may have richer DAG declarations.

## 4. Smallest algorithm, NOT a new framework

At each **existing** convergence pass, within its deadline and token budget:

1. Start from the request's actual known and graph-returned evidence. Apply existing versioned rules in deterministic closure, preserving source type, confidence floors, provenance, input validity and retractions.
2. Identify unresolved required/valuable outcomes using the existing D-9 per-field readiness criteria. If met, return via existing compatible assembly/status. If no feasible beneficial action, stop honestly (not an empty `completed` enrichment).
3. Use the existing rule index + derivation graph to find missing prerequisites that could unlock those outcomes. Compute **unique downstream outcome identities** reachable through currently supported rules. Ignore already satisfied outcomes and avoid recounting one field via multiple routes.
4. Order candidate **(missing prerequisite, acquisition method)** combinations by the declared objective/required-field priority, attainable unique downstream unlock, evidence adequacy, estimated incremental call/tool cost and time. When expected success or comparable weights are absent, rank **ordinally** rather than claim an exact optimum or use a fragile division by zero. Do not let a cheap but unverifiable retrieval beat an adequately supported one.
5. Execute the smallest defensible acquisition: **no call** for rule closure, **DeepSeek no-web** for supported input extraction, **simple source-grounded DeepSeek Search/Fetch** for public facts, then **DeepSeek reasoning / Perplexity Agent** when a named difficult gap justifies the extra effort. Keep the existing caller `max_variations`, 30-second budget, retry/circuit breaker and D-9 ownership. A second purposeful call is permitted when it produces a **distinct missing prerequisite or source** and remains valuable; identical fan-out for consensus is not.
6. Associate returned evidence with exact field/provider reply and underlying retrieval source where required, invoke inference again and recalculate before further purchase. Track predicted unlocks versus *actually realized derived outputs* locally for diagnostics, without asserting realized Strategic Value or creating new persistence tables. Repeat only within existing pass limits, budget and material gain; stop with explicit unknown/conflict otherwise.

A reasonable qualitative comparison when no authoritative utility function is supplied is: (a) required/gate-necessary outcomes first, (b) reachable **distinct** downstream weighted outputs where weights genuinely exist, (c) known cost/evidence/latency tiers, (d) stable deterministic tie-break. **Do not** override an explicit required field or gate requirement merely to save pennies. Existing `priority_fields` and consumer-required fields remain authoritative within their roles.

The two directions matter: **one paid fact -> several zero-cost inference outputs**, AND **multiple cheap supported facts/rule cascades -> the ability to produce one important otherwise blocked output**. Always re-evaluate after evidence changes.

## 5. Minimal proof matrix (reuse existing tests, no new harness)

| ID | Witness | Required outcome |
|---|---|---|
| M01 | All required outputs derivable from supplied facts and supported versioned rules | Zero external calls; actual derived fields with lineage, no fabricated source confidence |
| M02 | Polymer + capacity known, contamination tolerance unknown; sourcing tolerance permits grade and then tier | One targeted sourced acquisition, two actual downstream inference outputs if thresholds/conditions met; no redundant second purchase |
| M03 | Two valid inference paths reconverge on same target | Target is credited once, not once per path; no invented confidence gain |
| M04 | Target output absent from entity; only a nonrequested prerequisite exists in the rule registry | Planner can select the prerequisite without adding it to requested response fields |
| M05 | Moderate-cost acquisition unlocks more declared-value outcomes than a cheaper isolated fact | Where input weights/costs are comparable and declared, higher **net attainable value** wins, with same constraints and deadline |
| M06 | Domain supplies no scoring weights or trustworthy research-success probabilities | Returns stable ordinal target selection; marks economic optimum/quantified Strategic Value as unknown, never zero-valued proof |
| M07 | Acquisition returns weak/conflicting source or a condition rule does not fire | No hypothetical downstream output admitted; next choice recomputed from actual state or honest stop |
| M08 | First pass with current missing prerequisites; second pass after a sourced result | Initial ordering uses current unlock knowledge; after result, cheaper inferential closures run before any new provider request; no identical fanout |

**Test placement:** Extend existing `tests/test_rule_loader.py`, `tests/test_meta_prompt_planner.py`, `tests/test_inference_bridge_adapter.py`, `tests/test_convergence_controller.py`, and v2 evidence tests as necessary, rather than creating a mesh test framework. These tests are additive to mandatory `08_P0_RESEARCH_RELIABILITY.md` R01-R08 and provider migration smoke. Combine overlapping fixtures to minimize runtime and duplicated assertions.

## 6. Implementation scope / handoff

**Owning EIE files:** `app/engines/convergence_controller.py`, `app/engines/meta_prompt_planner.py`, `app/engines/inference/rule_loader.py`, `app/engines/inference_bridge_adapter.py` / `inference_bridge_v2.py` only where a current rule needs adjustment, `app/engines/search_optimizer.py` / existing cost estimate seam, and tests. Source-evidence and DeepSeek provider patches remain governed by `08_P0_RESEARCH_RELIABILITY.md` plus the original pack. **One core code owner** spans shared controller/planner/provider surfaces to avoid collisions. Existing provider and manual-review lanes remain bounded as already declared.

**P3 contract boundaries:** No edits to `.github` canonical SV law, CEG scoring/matching business authority, Odoo repository, existing EIE API schema or frozen v2 evidence contract merely for inference optimization. P0/P1/P2/P4 are **separately authorized in this development design** to address bounded CEG/Gate domain/transport integration. A typed internal graph projection for unrequested but admitted intelligence is explicitly in P3; it must not bypass CEG schema admission or widen the consumer API. A named cost optimization is **not** proof of a quantified L9 Strategic Value assessment. L9-SVQ appraisal principles support the qualitative ranking, not an extra SV runtime dependency. `L9-SV-001` and `002` must not be represented as fully implemented by this ranking heuristic.

**Future CTO conversion:** This is an **architectural development handoff**, not an activated campaign. Only later, on explicit user request, convert this P3 slice into a separately sequenced CTO/LCTO execution campaign, after reusing prior phase results with current projection/authority checks, scoped implementation ownership, integration tests and authorized PR publication. Do not add campaign orchestration scripts, PR commands, deploy permissions or parallel coders touching the same source files to this ZIP.
