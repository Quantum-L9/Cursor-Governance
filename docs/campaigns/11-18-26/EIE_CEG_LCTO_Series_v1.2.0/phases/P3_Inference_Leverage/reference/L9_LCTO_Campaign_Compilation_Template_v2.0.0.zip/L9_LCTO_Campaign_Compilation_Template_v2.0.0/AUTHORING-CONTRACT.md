# Authoring contract for reusable campaigns

## 1. Compile actual intent rather than vague priorities

`CAMPAIGN.json` uses a **local noncanonical authoring shape**: `l9.local.lcto-campaign-authoring/v2`. It is a compact intermediate input for generating human-readable briefs and linting work ownership. It is neither a new admitted L9 schema nor a Program Execution campaign source. The compiler must not infer absent source facts, permissions, runtime capabilities or target commands.

Required sections: `campaign`, `scope`, `authorization`, `sources`, `facts`, `findings`, `lanes`, `gates`, `critical_path`. IDs are unique within each collection. Build requires one source, lane, gate and critical-path entry. Optional read-only assurance lanes are legitimate. Never fill data with fictional citations. Unknowns may be explicit, but a missing required authoring field is not an unknown fact: fill or withhold compilation.

The starter JSON is a drafting aid, not an activated instruction. The synthetic valid fixture is a structural acceptance example, **not** a real source snapshot.

## 2. Capture separately what each evidence class proves

Every `sources[]` entry identifies `id`, `owner`, `kind`, `revision`, `coordinate`, `grade`, and `observation`. Observed *code* sources require full immutable source SHA; other observations identify their actual timestamp/run/version. `grade` is one of `OBSERVED`, `REPORTED`, `INFERRED`, `UNKNOWN`. UNKNOWN requires `resolution_gate`. A citation to a release page does not establish index installability; a successful deployment workflow does not establish exact live process/data/rollback; an HTTP readiness result does not prove cross-client persistence. Use only applicable stage distinctions, not a universal release ceremony.

Every `facts[]` item has `statement`, `source_ids`, `grade`, `revalidate_when`. On recompilation, update the source-backed fact or supersede it explicitly. **Closed facts are not rediscovery homework.** Changing facts with different authority, scope or observation time can invalidate dependent gates.

## 3. Find the real bottleneck and prove its removal

Every `critical_path[]` step declares `owner_lane`, `blocking_cause`, `prerequisite_gates`, `proof_to_unlock`, and `unlocks_gates`. State the *causal* blocker, not a wishlist of work. Source-only workaround, shadow writer, downgraded check or incompatible artifact pin is not an unlock. Keep true serial dependencies only; otherwise unrelated lanes proceed. If a correction to upstream source changes an immutable release, the release and dependent consumer/version identities must be revalidated.

## 4. Model swarm ownership, not just agent count

Each `lanes[]` entry names role `writer` or `assurance`, its `writable_repositories`, `read_only_repositories`, `write_paths` keyed by writable repo URL, `depends_on_lanes`, `wait_for_gates`, objective, acceptance and exclusions. Source repo URLs are full canonical GitHub paths. Read-only lanes declare `writable_repositories: []` and no write paths.

No concurrent writers share a path, prefix, glob, branch or generated lockfile. The compiler conservatively rejects possibly overlapping path patterns, even if someone asserts that agents will be careful. If a real dependency requires editing the same file twice, reserve that file to **one** owner and sequence the consumer, rather than asking two agents to write there. If a true out-of-scope owner must change, the affected work blocks pending exact scope authorization; never silently expand a lane's `repository_access`.

Generated lane briefs start with the repository_access YAML fence. That header is not a technical sandbox. Current host access, launch adapter, coding-agent projections, permissions and role registration still govern. The compiler does not supply a copied child system prompt. A lane report or `CTO-STATUS: ready-to-merge` is not a merge.

## 5. Gates must be falsifiable and stage-correct

Each `gates[]` row declares `id`, `owner_lane`, `depends_on`, `claim`, `required_proof`, `negative_controls`, `status`, and optional `receipt_refs`, `executed`, `skipped_required_steps`, `wake_action` and `non_applicable_reason`.

Statuses: `NOT_RUN`, `PASS`, `FAIL`, `BLOCKED`, `NOT_APPLICABLE`. A PASS needs actual receipts, `executed: true`, no skipped required step and prior gates PASS/NOT_APPLICABLE. A BLOCKED requires a specific `wake_action`, not a guessed workaround. NOT_APPLICABLE requires a rationale. Green CI without a mandatory test step is explicitly invalid. The build validates *declared* evidence shape and ordering, **not** whether an external receipt is authentic. Review external source claims independently.

Findings statuses: `OPEN`, `FIXED`, `ALREADY_SATISFIED`, `INVALID`, `BLOCKED`, `OUT_OF_SCOPE`. Fixed/satisfied/invalid require receipts, blocked requires wake action, out-of-scope requires rationale. Every in-scope finding must receive disposition; the template never drops a problem because an adjacent PR is green.

## 6. Authorization and stage boundaries

The authorization object has explicit `implementation`, `publication`, `merge`, `production`, and `secrets` dispositions. Publication is `governed_make_pr_after_owner_verification` per current operator selection. Merge must be either `requires_current_operator_authority` or `exact_subject_grant_recorded`, never a generic assumption that activation allows merges. LCTO currently coordinates merges subject to operator authority; child publishers own CI/review remediation and are prohibited from merging. Remote/production mutation is not granted by a well-formed campaign source.

An approved campaign should continue until all applicable gates pass or a genuinely external reserved approval blocks further dependent work. Request one bundled mobile-friendly decision only when necessary, keep unrelated lanes active, and never lie that blocked means done.

## 7. Validate at the right level

The authoring tool enforces: valid IDs, required fields and no replacement tokens; source references and unknown routing; unique lane/gate/finding IDs; acyclic lane/gate graph; conservative exclusive path ownership; no read-only writer; resolved referenced IDs; non-skipped PASS receipts and predecessor order; exact generated lane headers; deterministic regenerated docs and file hashes. Its verdict is structural only.

No authoring tool can prove actual repository permission isolation, correct source meaning, merged PRs, production identity, acceptance tests or L9 global admission. Use the source owners' native tests and independent evidence at execution. Do not substitute synthetic tests for the real gate.
