#!/usr/bin/env python3
"""Offline authoring scaffold for LCTO execution briefs, NOT a runtime/compiler or authority.

Commands:
  check --spec FILE
  build --spec FILE --out DIR [--zip ZIP]
  verify-pack --dir DIR
  verify-template --root DIR

No network access, repository mutation, PRs, shell execution, admissions or releases.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo

KIND = "l9.local.lcto-campaign-authoring/v2"
URL_RE = re.compile(r"^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/?$")
SHA_RE = re.compile(r"^[0-9a-f]{40}$")
ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,55}$")
TOKEN_RE = re.compile(r"(?:REPLACE_[A-Z0-9_]+|\{\{[^}]+\}\})")
GATE_STATUSES = {"NOT_RUN", "PASS", "FAIL", "BLOCKED", "NOT_APPLICABLE"}
FINDING_STATUSES = {"OPEN", "FIXED", "ALREADY_SATISFIED", "INVALID", "BLOCKED", "OUT_OF_SCOPE"}
SOURCE_GRADES = {"OBSERVED", "REPORTED", "INFERRED", "UNKNOWN"}
ALLOWED_MODES = {"writer", "assurance"}


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def text(v):
    return "" if v is None else str(v)


def md(v):
    return text(v).replace("|", "\\|").replace("\n", " ")


def lines(items, prefix="- ", empty="- None identified"):
    return "\n".join(prefix + text(x) for x in items) if items else empty


def table(headers, rows):
    h = "| " + " | ".join(headers) + " |"
    rule = "|" + "|".join("---" for _ in headers) + "|"
    return "\n".join([h, rule] + ["| " + " | ".join(md(y) for y in row) + " |" for row in rows])


def unique(items, kind, errors):
    ids = [x.get("id") for x in items if isinstance(x, dict)]
    if len(ids) != len(set(ids)):
        errors.append(f"duplicate {kind} id")
    for x in items:
        if not isinstance(x, dict) or not isinstance(x.get("id"), str) or not ID_RE.fullmatch(x["id"]):
            errors.append(f"{kind}: missing or invalid id")
    return set(ids)


def cycle(nodes, deps, kind, errors):
    visiting, visited = set(), set()
    def visit(node):
        if node in visited:
            return
        if node in visiting:
            errors.append(f"{kind} dependency cycle at {node}")
            return
        visiting.add(node)
        for parent in deps.get(node, ()):
            if parent not in nodes:
                errors.append(f"{kind} {node} refers to unknown predecessor {parent}")
                continue
            visit(parent)
        visiting.remove(node)
        visited.add(node)
    for node in nodes:
        visit(node)


def glob_probe(p):
    p = re.sub(r"\[[^\]]*\]", "x", p)
    return p.replace("**", "probe/sub").replace("*", "probe").replace("?", "x")


def scopes_overlap(p, q):
    if p == q or p in ("**", "*", ".") or q in ("**", "*", "."):
        return True
    a, b = glob_probe(p), glob_probe(q)
    if fnmatch.fnmatchcase(a, q) or fnmatch.fnmatchcase(b, p):
        return True
    # Ordinary directory prefix and one-sided wildcard scopes.
    pa, pb = p.rstrip("/*"), q.rstrip("/*")
    if not any(c in pa for c in "*?[") and not any(c in pb for c in "*?["):
        return pa == pb or pa.startswith(pb + "/") or pb.startswith(pa + "/")
    if any(c in p for c in "*?[") and any(c in q for c in "*?["):
        pref_a = re.split(r"[*?\[]", p, 1)[0]
        pref_b = re.split(r"[*?\[]", q, 1)[0]
        if pref_a.startswith(pref_b) or pref_b.startswith(pref_a):
            return True  # Conservative uncertainty: require explicit narrow scopes.
    return False


def validate_spec(d):
    e = []
    if not isinstance(d, dict):
        return ["spec root must be object"]
    if d.get("schema") != KIND:
        e.append("schema must be " + KIND)
    def scan_tokens(value, where="root"):
        if isinstance(value, dict):
            for k, v in value.items():
                scan_tokens(v, f"{where}.{k}")
        elif isinstance(value, list):
            for i, v in enumerate(value):
                scan_tokens(v, f"{where}[{i}]")
        elif isinstance(value, str) and TOKEN_RE.search(value):
            e.append(f"unresolved authoring token at {where}")
    scan_tokens(d)
    campaign = d.get("campaign") or {}
    for f in ("id", "title", "version", "objective", "observable_done", "priority_zero"):
        v = campaign.get(f)
        if not isinstance(v, str) or not v.strip() or TOKEN_RE.search(v):
            e.append(f"campaign.{f} must be filled")
    if not ID_RE.fullmatch(campaign.get("id", "")):
        e.append("campaign.id must be safe short identifier")
    if campaign.get("status") not in ("DRAFT_NOT_ACTIVATED", "EXECUTION_BRIEF_APPROVED"):
        e.append("campaign.status must express approval, not simulated execution")
    scope = d.get("scope") or {}
    for key in ("include", "exclude"):
        if not isinstance(scope.get(key), list) or not scope[key]:
            e.append(f"scope.{key} must contain explicit entries")
    approvals = d.get("authorization") or {}
    if approvals.get("publication") != "governed_make_pr_after_owner_verification":
        e.append("authorization.publication must use current governed make pr")
    if approvals.get("merge") not in ("requires_current_operator_authority", "exact_subject_grant_recorded"):
        e.append("authorization.merge must not invent standing blanket approval")
    for key in ("production", "secrets"):
        if key not in approvals:
            e.append(f"authorization.{key} must be explicit")
    for k in ("sources", "facts", "findings", "lanes", "gates", "critical_path"):
        if not isinstance(d.get(k), list):
            e.append(f"{k} must be an array")
    if e:
        return e
    source_ids = unique(d["sources"], "source", e)
    fact_ids = unique(d["facts"], "fact", e)
    finding_ids = unique(d["findings"], "finding", e)
    lane_ids = unique(d["lanes"], "lane", e)
    gate_ids = unique(d["gates"], "gate", e)
    cp_ids = unique(d["critical_path"], "critical_path", e)
    if not d["sources"]:
        e.append("at least one source required")
    if not d["lanes"]:
        e.append("at least one execution or assurance lane required")
    if not d["gates"]:
        e.append("at least one acceptance gate required")
    if not d["critical_path"]:
        e.append("critical_path cannot be empty")
    for s in d["sources"]:
        sid = s.get("id")
        if s.get("grade") not in SOURCE_GRADES:
            e.append(f"source {sid}: invalid evidence grade")
        if not s.get("owner") or not s.get("coordinate") or not s.get("observation"):
            e.append(f"source {sid}: owner/coordinate/observation required")
        if s.get("grade") == "OBSERVED" and s.get("kind") == "code" and not SHA_RE.fullmatch(s.get("revision", "")):
            e.append(f"source {sid}: OBSERVED code must pin a 40-char source revision")
        if s.get("grade") == "UNKNOWN" and not s.get("resolution_gate"):
            e.append(f"source {sid}: UNKNOWN must have resolution_gate")
        if s.get("resolution_gate") and s["resolution_gate"] not in gate_ids:
            e.append(f"source {sid}: unknown resolution_gate {s['resolution_gate']}")
    for f in d["facts"]:
        fid = f.get("id")
        if f.get("grade") not in SOURCE_GRADES or not f.get("statement"):
            e.append(f"fact {fid}: grade/statement required")
        if not f.get("source_ids") or any(s not in source_ids for s in f.get("source_ids", [])):
            e.append(f"fact {fid}: source_ids missing or unresolved")
        if not f.get("revalidate_when"):
            e.append(f"fact {fid}: revalidate_when required (may say on activation)")
    for f in d["findings"]:
        fid = f.get("id")
        if f.get("status") not in FINDING_STATUSES or not f.get("statement"):
            e.append(f"finding {fid}: status/statement required")
        if f.get("owner_lane") not in lane_ids and f.get("status") != "OUT_OF_SCOPE":
            e.append(f"finding {fid}: owner_lane not in lanes")
        if f.get("status") == "OUT_OF_SCOPE" and not f.get("disposition_reason"):
            e.append(f"finding {fid}: out-of-scope requires rationale")
        if f.get("status") in ("FIXED", "ALREADY_SATISFIED", "INVALID") and not f.get("receipt_refs"):
            e.append(f"finding {fid}: closed status requires evidence receipt")
        if f.get("status") == "BLOCKED" and not f.get("wake_action"):
            e.append(f"finding {fid}: blocked requires exact wake action")
        if not f.get("source_ids") or not all(s in source_ids for s in f.get("source_ids", [])):
            e.append(f"finding {fid}: missing or unknown source ids")
    writes = []
    for lane in d["lanes"]:
        lid = lane.get("id")
        if lane.get("kind") not in ALLOWED_MODES:
            e.append(f"lane {lid}: invalid kind")
        wr = lane.get("writable_repositories", [])
        ro = lane.get("read_only_repositories", [])
        if not isinstance(wr, list) or not isinstance(ro, list):
            e.append(f"lane {lid}: repository lists required")
            continue
        if len(wr + ro) != len(set(wr + ro)) or any(not URL_RE.fullmatch(u) for u in wr + ro):
            e.append(f"lane {lid}: duplicate or malformed repository access")
        if lane.get("kind") == "assurance" and wr:
            e.append(f"lane {lid}: assurance lane cannot be writable")
        if lane.get("kind") == "writer" and not wr:
            e.append(f"lane {lid}: writer must name writable repository")
        owned = lane.get("write_paths") or {}
        if set(owned) - set(wr):
            e.append(f"lane {lid}: write path repo missing from writable access")
        if lane.get("kind") == "writer" and not any(owned.values()):
            e.append(f"lane {lid}: writer needs exclusive write paths")
        if lane.get("kind") == "assurance" and any(owned.values()):
            e.append(f"lane {lid}: assurance must have no write paths")
        for repo, paths in owned.items():
            for path in paths:
                if path in ("*", "**", ".", "") or path.startswith("/") or ".." in path.split("/"):
                    e.append(f"lane {lid}: unsafe or overbroad write path {path}")
                writes.append((lid, repo, path))
        if not lane.get("objective") or not lane.get("acceptance"):
            e.append(f"lane {lid}: objective/acceptance must be explicit")
        for g in lane.get("wait_for_gates", []):
            if g not in gate_ids:
                e.append(f"lane {lid}: unknown barrier {g}")
    cycle(lane_ids, {x["id"]: x.get("depends_on_lanes", []) for x in d["lanes"]}, "lane", e)
    for i, (a, repo1, path1) in enumerate(writes):
        for b, repo2, path2 in writes[i+1:]:
            if a != b and repo1 == repo2 and scopes_overlap(path1, path2):
                e.append(f"WRITE COLLISION: {a}:{path1} versus {b}:{path2} in {repo1}; assign one owner or split scopes")
    for g in d["gates"]:
        gid = g.get("id")
        if g.get("status") not in GATE_STATUSES:
            e.append(f"gate {gid}: invalid status")
        if g.get("owner_lane") not in lane_ids:
            e.append(f"gate {gid}: unknown owner")
        if not g.get("claim") or not g.get("required_proof"):
            e.append(f"gate {gid}: claim and required_proof required")
        if g.get("status") == "PASS":
            if not g.get("receipt_refs") or not g.get("executed", False) or g.get("skipped_required_steps", False):
                e.append(f"gate {gid}: false-green PASS missing receipts/execution or mandatory steps skipped")
        if g.get("status") == "NOT_APPLICABLE" and not g.get("non_applicable_reason"):
            e.append(f"gate {gid}: NOT_APPLICABLE requires rationale")
        if g.get("status") == "BLOCKED" and not g.get("wake_action"):
            e.append(f"gate {gid}: BLOCKED requires wake action")
    cycle(gate_ids, {x["id"]: x.get("depends_on", []) for x in d["gates"]}, "gate", e)
    gate_by_id = {g["id"]: g for g in d["gates"]}
    for g in d["gates"]:
        if g.get("status") == "PASS":
            for p in g.get("depends_on", []):
                if p in gate_by_id and gate_by_id[p]["status"] not in ("PASS", "NOT_APPLICABLE"):
                    e.append(f"gate {g['id']}: PASS while prerequisite {p} is incomplete")
    for c in d["critical_path"]:
        cid=c.get("id")
        if c.get("owner_lane") not in lane_ids:
            e.append(f"critical path {cid}: unknown lane")
        if any(g not in gate_ids for g in c.get("prerequisite_gates", []) + c.get("unlocks_gates", [])):
            e.append(f"critical path {cid}: unknown gate reference")
        if not c.get("blocking_cause") or not c.get("proof_to_unlock"):
            e.append(f"critical path {cid}: causal blocker/proof required")
    # Prevent silent closure with all gates passing and unresolved findings.
    if d["gates"] and all(g.get("status") in ("PASS", "NOT_APPLICABLE") for g in d["gates"]):
        unresolved = [f["id"] for f in d["findings"] if f.get("status") in ("OPEN", "BLOCKED")]
        if unresolved:
            e.append("all gates terminal but findings unresolved: " + ", ".join(unresolved))
    return e


def header(lane):
    wr = lane["writable_repositories"]
    ro = lane["read_only_repositories"]
    a = ["```yaml", "repository_access:", "  writable:" if wr else "  writable: []"]
    a.extend(["    - " + u for u in wr])
    a.append("  read_only:" if ro else "  read_only: []")
    a.extend(["    - " + u for u in ro])
    a += ["  unlisted_repositories: no_access", "```", ""]
    return "\n".join(a)


def render(d):
    c = d["campaign"]
    auth = d["authorization"]
    sources = d["sources"]
    lanes = d["lanes"]
    gates = d["gates"]
    critical = d["critical_path"]
    facts = d["facts"]
    findings = d["findings"]
    out = {}
    out["README.md"] = f"""# {c['title']} | LCTO execution handoff {c['version']}

**Status:** {c['status']}. **Launch:** Explicit activation only. **Campaign ID:** `{c['id']}`.

## Target outcome

{c['objective']}

**Observable definition of success:** {c['observable_done']}

**Priority zero:** {c['priority_zero']}

## Contract boundaries

- This document is an operator-authorized campaign brief only where the operator's exact scope and approval actually support it. It is not an admitted global semantic source or a runtime proof.
- The current Cursor-Governance LCTO mode, child-prompt renderer and publication authority own execution mechanics. This pack supplies task intent, reservations, evidence and testable gates, not an alternate launcher.
- Agents prepare and maintain their PRs to ready-to-merge; LCTO owns integration and actual merge authority is determined by the current operator/host switch.
- Preserve source truth as OBSERVED / REPORTED / INFERRED / UNKNOWN; no successful workflow can imply unexecuted gate steps ran.

## Scope

**Included:**\n{lines(d['scope']['include'])}

**Excluded:**\n{lines(d['scope']['exclude'])}

## Reading order

`00-LCTO-LAUNCH.md` -> `07-RECONCILED-FACTS.md` -> `01-SOURCE-EVIDENCE.md` -> `02-CRITICAL-PATH.md` -> `03-CONCURRENCY.md` -> `lanes/` -> `04-DEFINITION-OF-DONE.md` -> `05-PUBLICATION-SECURITY.md` -> `06-FINDING-REGISTER.md` -> `08-FINAL-RECEIPT.md`.

**No execution claimed by this compiled pack.** The compiler only validated declaration structure, ownership graph and byte integrity. Current authority, actual CI and runtime gates remain execution obligations.
"""
    out["00-LCTO-LAUNCH.md"] = f"""# Operator activation brief | {c['id']}

**HOLD until explicit operator activation.** The campaign source is `{c['status']}`, not a self-start trigger. Use the current existing Start Session and `/lcto` only when the host verifies they apply. Attach this complete pack.

**Objective:** {c['objective']}

**Priority zero:** {c['priority_zero']}

Operate as LCTO. Resolve current authoritative revisions and live mode status before consequential action. Consume the recorded facts and reconciliation, not an invented new census. Render swarm child system prompts from the **current** Cursor-Governance LCTO owner; never copy a prompt from this pack. Bootstrap one fixed reusable pool within current host capacity (no more than the actual mode's maximum), assign independent disjoint lanes immediately and preserve their reservations; leave dependent work behind its declared gates while other lanes progress.

The publishing agent owns its branch and PR until CI and reviews are current and merge-ready. Agents report only by CTO-* transcript/Task results, never by a child cross-session send. LCTO alone integrates and routes remediation back to owners. Publication is governed `make pr` from the verified SSOT with current WS, PR base, L4 and permissions; never raw agent push or a bypass route. Ask the operator only for an exact, unavoidable approval and present one consolidated mobile-friendly decision with prerequisites attached. Protected production, secrets and merge approvals remain enforced by their real owners.

**Stay on the campaign until:** every applicable acceptance gate and finding is resolved with actual source, index/artifact, CI, runtime or operational receipts as appropriate, or a precise unbypassable external authority boundary remains BLOCKED. Do not stop at diagnosis, PR creation, release, green-but-skipped CI or deployment workflow success. Do not expand scope, guess a source command, rewrite immutable release identities or fabricate closure. Route one high-leverage next action if blocked.

**Do not authorize a merge, release or production mutation merely by reading this launch brief.** Actual authorization is in the source and current host policy.
"""
    out["01-SOURCE-EVIDENCE.md"] = "# Exact source evidence and discriminating facts\n\n" + table(
        ["Source ID", "Owner", "Kind", "Revision / observation", "Coordinate", "Grade", "Next check"],
        [(s["id"], s["owner"], s.get("kind", "other"), s.get("revision", "UNKNOWN"), s["coordinate"], s["grade"], s["observation"]) for s in sources]) + "\n\n## Fact ledger\n\n" + table(
        ["Fact", "Evidence", "Grade", "Claim", "Revalidate"],
        [(f["id"], ", ".join(f["source_ids"]), f["grade"], f["statement"], f["revalidate_when"]) for f in facts]) + "\n\nDo not upgrade reported configuration, source assertions or workflow success into authenticated runtime proof. Unknown stays UNKNOWN.\n"
    out["02-CRITICAL-PATH.md"] = "# Root cause and unlock order\n\nThe critical path is the smallest *actual dependency graph*, not a serial queue for all work. Only listed successors wait. Recheck changing facts at their declared hinge, not by restarting a census.\n\n" + table(
        ["Step", "Owner", "Real blocker", "Required prior gates", "Proof to unlock", "Unblocks"],
        [(q["id"], q["owner_lane"], q["blocking_cause"], ", ".join(q.get("prerequisite_gates", [])) or "none", q["proof_to_unlock"], ", ".join(q.get("unlocks_gates", [])) or "none") for q in critical]) + "\n\n**Proof distinctions:** Where relevant, source implementation, artifact publication, consumer availability, deployment, runtime operation and observed outcome are distinct. Apply only stages the objective needs; never invent a release ceremony.\n"
    rows = []
    for lane in lanes:
        owns = ", ".join(f"{repo}: {', '.join(paths)}" for repo, paths in (lane.get("write_paths") or {}).items()) or "READ-ONLY"
        rows.append((lane["id"], lane["title"], lane["kind"], owns, ", ".join(lane.get("depends_on_lanes", [])) or "none", ", ".join(lane.get("wait_for_gates", [])) or "none"))
    out["03-CONCURRENCY.md"] = "# Swarm scheduling and exclusive ownership\n\n" + table(
        ["Lane", "Assignment", "Kind", "Exclusive files / patterns", "Lane predecessor", "Gate barrier"], rows) + """

- Size the pool to useful concurrent lanes and current mode capacity. An assurance lane can operate while a writer waits. Reuse idle slots rather than spawning replacements as scaling.
- Every writer is the exclusive owner of its declared paths, lockfiles, generated outputs and branch. The compiler refuses possible write-scope collisions; any necessary shared file goes to one owner and is sequenced, never edited concurrently.
- Each child brief begins with exact `repository_access`. This is descriptive scope, not a technical access-control grant. Host permissions must enforce it.
- Agents own their PR remediation to ready-to-merge; the LCTO owns cross-lane review and integration and never edits a lane's branch to fix a bug.
- Keep source and integration branches bound to the current live base/stack. Never force-stack unrelated PRs or block independent lanes on an unrelated merge.
- On Claude Code cloud, the active LCTO launch adapter owns repository attachment, role registration and derived child prompts. On Cursor, use the native Task continuation semantics. Do not improvise child system prompts or session transport.
"""
    out["04-DEFINITION-OF-DONE.md"] = "# Evidence-based definition of done\n\n" + table(
        ["Gate", "Owner", "Dependency", "Claim", "Required proof", "Status", "Receipt"],
        [(g["id"], g["owner_lane"], ", ".join(g.get("depends_on", [])) or "none", g["claim"], g["required_proof"], g["status"], ", ".join(g.get("receipt_refs", [])) or "NOT_RUN") for g in gates]) + "\n\n## Negative controls\n\n" + "\n".join(f"- **{g['id']}**: " + ("; ".join(g.get("negative_controls", [])) or "Only when an applicable failure class is source-verified") for g in gates) + "\n\nNo gate passes from a job's green banner when mandatory steps were skipped. A source file, PR, release artifact, deployed image and real runtime are distinct evidence stages. A PASS is eligible only when the actual required proof executed and the final exact head/result is bound. A BLOCKED gate needs one actual wake condition, not a fabricated retry. NOT_APPLICABLE requires the rationale recorded in CAMPAIGN.json.\n\nAll in-scope findings must be FIXED, ALREADY_SATISFIED, INVALID, or explicitly BLOCKED with owner and wake action. An unresolved BLOCKED cannot be called DONE.\n"
    out["05-PUBLICATION-SECURITY.md"] = f"""# Governed publication and reserved boundaries

**PR publication:** {auth['publication']}. The operator-selected `make pr` is owned by the **current** Cursor-Governance SSOT, not necessarily the target repo's Makefile. At execution inspect the current SSOT publishing Makefile, includes, authority routing, preflight and gate. Establish literal target workspace, actual PR base, current source/head, L4 permit, `OPEN_PR=1` and `PUSH_ONLY!=1`; do not invent a command path from this pack. Reuse its validation rather than performing a redundant full ceremony beforehand. The PR URL and exact current head prove publication, not a command's exit alone.

**Merge policy:** {auth['merge']}. An agent never merges. LCTO can only execute a merge when the real merge authority switch and exact subject authorize it; operator approvals remain necessary where reserved. A blanket campaign intent must not be extrapolated to other PRs.

**Production boundary:** {auth['production']}. **Secrets:** {auth['secrets']}.

**Reserved operator approvals / actions:**\n{lines(d.get('reserved_approvals', []))}

Publication, release, deployment, migrations and durable-data changes are different operations with potentially different owners. Resolve exact live controls before each. No raw agent push, bypass of CI, immutable artifact rewriting, new shadow publisher or unauthorized read-only repo edits. If a real external boundary is blocking, provide one consolidated, mobile-friendly request and continue all independent lanes.
"""
    out["06-FINDING-REGISTER.md"] = "# Finding ownership and terminal dispositions\n\n" + table(
        ["Finding", "Grade/status", "Owner", "Source", "Observed problem", "Disposition / next action"],
        [(f["id"], f["status"], f.get("owner_lane", "none"), ", ".join(f.get("source_ids", [])) or "none", f["statement"], f.get("disposition_reason") or f.get("wake_action") or ", ".join(f.get("receipt_refs", [])) or "OPEN") for f in findings]) + "\n\nNo in-scope finding disappears: FIXED + real proof, ALREADY_SATISFIED + proof, INVALID + disproof, BLOCKED + owner/wake. OUT_OF_SCOPE must cite why the finding is not a prerequisite. Optional adjacent improvements are not compulsory defects.\n"
    out["07-RECONCILED-FACTS.md"] = "# Current-state reconciliation and no-rework directives\n\n" + table(
        ["Previously established fact", "Grade", "Evidence", "Recheck only when"],
        [(f["statement"], f["grade"], ", ".join(f["source_ids"]), f["revalidate_when"]) for f in facts]) + "\n\nThis ledger is a snapshot, not a magic truth override. Later independently verified, exact-subject evidence supersedes an earlier observation; conflicting claims must be reconciled and the affected gates invalidated. Do not rediscover already-closed facts every wave. Do recheck fast-changing dependencies at the defined hinge.\n"
    out["08-FINAL-RECEIPT.md"] = "# Final integrated campaign receipt | not pre-populated\n\n**This file is a report structure, not proof that anything executed.** LCTO fills it from current independent receipts after execution.\n\n" + lines([
        "Campaign ID and activation authorization / actual host mode state",
        "Final immutable source/authority SHA and affected scope",
        "Per-lane PR URL, exact head, review/CI/merge state and owner",
        "Actual test/CI steps and skips (false-green checks forbidden)",
        "Dependent releases, public artifact availability, deployments and runtime identity where applicable",
        "Negative controls, security boundaries, backup/restore and rollback where applicable",
        "Each gate with evidence link and exact final status",
        "Every finding disposition and residual UNKNOWN/BLOCKED with wake condition",
        "One minimal operator decision if external approval is genuinely still required",
        "Terminal verdict: COMPLETE only with all applicable evidence, otherwise BLOCKED/PARTIAL",
    ]) + "\n"
    for lane in lanes:
        p = f"lanes/{lane['id']}.md"
        prereq = ", ".join(lane.get("depends_on_lanes", [])) or "none"
        barriers = ", ".join(lane.get("wait_for_gates", [])) or "none"
        out[p] = header(lane) + f"# Lane {lane['id']} | {lane['title']}\n\n**Role:** {lane['kind']} lane; CTO is coordinator, integration/merge owner. This brief is **not** the child system prompt.\n\n**Objective:** {lane['objective']}\n\n**Lane predecessor:** {prereq}. **Activation barrier gates:** {barriers}.\n\n## Reserved write surfaces\n\n" + (lines([f"{repo}: {path}" for repo, paths in (lane.get("write_paths") or {}).items() for path in paths]) if lane.get("write_paths") else "None. This is a strictly read-only evidence lane.") + "\n\n## Required acceptance\n\n" + lines(lane["acceptance"]) + "\n\n## Explicit exclusions\n\n" + lines(lane.get("exclusions", [])) + "\n\nMode and repo-access boundaries must be verified by current host. Coding workers do not call cross-session messaging tools; they report CTO-* lines in own transcript or Task result. Publication via current verified `make pr` only when this lane is writable and authorized. Each publisher owns its PR to ready-to-merge, then becomes idle and waits for CTO assignment. No lane merges or production mutation without separate authorization.\n"
    out["validate_pack.py"] = """#!/usr/bin/env python3
\"\"\"Standalone byte/header integrity check for a compiled campaign handoff.
This is NOT an L9 conformance or remote runtime validator.
\"\"\"
import hashlib, json
from pathlib import Path
R = Path(__file__).resolve().parent
m = json.loads((R / 'MANIFEST.json').read_text())
actual = {p.relative_to(R).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in R.rglob('*') if p.is_file() and p.name != 'MANIFEST.json'}
assert actual == m['files'], 'campaign pack file census/hash mismatch'
c = json.loads((R / 'CAMPAIGN.json').read_text())
b = (json.dumps(c, sort_keys=True, ensure_ascii=False, indent=2)+'\\n').encode()
assert hashlib.sha256(b).hexdigest() == m['source_spec_sha256'], 'source-spec mismatch'
for lane in c['lanes']:
    p = R / 'lanes' / (lane['id'] + '.md')
    content = p.read_text()
    assert content.startswith('```yaml\\nrepository_access:\\n'), 'lane header missing'
    assert '  unlisted_repositories: no_access' in content.split('```', 3)[1], 'lane not closed world'
print('PASS: exact file inventory, digests, source binding, first-position lane access headers')
print('NOT RUN: source validity, independent CI, real execution, publication or deployment')
"""
    return {k: v.rstrip() + "\n" for k, v in out.items()}


def make_manifest(files: dict[str, bytes], campaign: dict):
    return {
        "manifest_schema": "l9.local.pack-digests/v1",
        "status": "STRUCTURALLY_VALIDATED_NO_AUTHORITY_OR_RUNTIME_PROOF",
        "campaign_id": campaign["campaign"]["id"],
        "source_spec_sha256": sha256(json.dumps(campaign, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8") + b"\n"),
        "files": {k: sha256(v) for k, v in sorted(files.items())},
        "limits": "Structural validation is not source, authority, CI, release, production or completion proof",
    }


def normalized_json(d):
    return (json.dumps(d, sort_keys=True, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def verify_pack(root: Path):
    errors = []
    manifest = load_json(root / "MANIFEST.json")
    actual = {p.relative_to(root).as_posix(): sha256(p.read_bytes()) for p in root.rglob("*") if p.is_file() and p.name != "MANIFEST.json"}
    if actual != manifest["files"]:
        errors.append(f"manifest mismatch: {set(actual)^set(manifest['files'])} or content hashes")
    spec = load_json(root / "CAMPAIGN.json")
    errors += validate_spec(spec)
    if not errors:
        for name, expected in render(spec).items():
            p = root / name
            if not p.is_file() or p.read_text(encoding="utf-8") != expected:
                errors.append(f"render drift or absent derived document: {name}")
    for lane in spec["lanes"]:
        p = root / "lanes" / (lane["id"] + ".md")
        if not p.exists() or not p.read_text().startswith(header(lane)):
            errors.append(f"lane {lane['id']}: repository_access header missing/mismatched/not first")
    if manifest.get("source_spec_sha256") != sha256(normalized_json(spec)):
        errors.append("manifest source_spec_sha256 mismatch")
    return errors


def build(spec: Path, out: Path, zip_path: Path | None):
    d = load_json(spec)
    errors = validate_spec(d)
    if errors:
        raise ValueError("\n".join(errors))
    if out.exists() and any(out.iterdir()):
        raise ValueError(f"destination is not empty: {out}")
    out.mkdir(parents=True, exist_ok=True)
    files = {k: v.encode("utf-8") for k, v in render(d).items()}
    files["CAMPAIGN.json"] = normalized_json(d)
    for k, value in files.items():
        target=out/k
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value)
    manifest = make_manifest(files, d)
    (out / "MANIFEST.json").write_bytes(normalized_json(manifest))
    err = verify_pack(out)
    if err:
        raise ValueError("generated pack self-check failed: " + "; ".join(err))
    if zip_path:
        zip_path.parent.mkdir(parents=True, exist_ok=True)
        with ZipFile(zip_path, "w") as z:
            for p in sorted(out.rglob("*")):
                if p.is_file():
                    name = out.name + "/" + p.relative_to(out).as_posix()
                    info = ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
                    info.compress_type = ZIP_DEFLATED
                    info.external_attr = 0o644 << 16
                    z.writestr(info, p.read_bytes())
        with ZipFile(zip_path) as z:
            if z.testzip() is not None:
                raise ValueError("zip integrity failure")
    return manifest


def verify_template(root: Path):
    manifest=load_json(root/"MANIFEST.json")
    actual={p.relative_to(root).as_posix(): sha256(p.read_bytes()) for p in root.rglob("*") if p.is_file() and p.name!="MANIFEST.json"}
    errs=[]
    if actual!=manifest.get("files"):
        errs.append("template manifest mismatch")
    for req in ("README.md","AUTHORING-CONTRACT.md","DESIGN-HARVEST.md","examples/STARTER-CAMPAIGN.json","tools/compile_campaign.py","tests/test_compiler.py"):
        if req not in actual:
            errs.append("template missing " + req)
    return errs


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    cmd=parser.add_subparsers(dest="command",required=True)
    p=cmd.add_parser("check");p.add_argument("--spec",type=Path,required=True)
    p=cmd.add_parser("build");p.add_argument("--spec",type=Path,required=True);p.add_argument("--out",type=Path,required=True);p.add_argument("--zip",type=Path)
    p=cmd.add_parser("verify-pack");p.add_argument("--dir",type=Path,required=True)
    p=cmd.add_parser("verify-template");p.add_argument("--root",type=Path,required=True)
    args=parser.parse_args()
    if args.command == "check":
        errors=validate_spec(load_json(args.spec))
    elif args.command == "build":
        errors=[]
        manifest=build(args.spec,args.out,args.zip)
        print(f"BUILD: {manifest['campaign_id']} files={len(manifest['files'])} status={manifest['status']}")
    elif args.command == "verify-pack":
        errors=verify_pack(args.dir)
    else:
        errors=verify_template(args.root)
    if errors:
        for e in errors:
            print("FAIL:", e)
        raise SystemExit(1)
    print("PASS: bounded structural verification. NOT RUN: L9 authority/CI/remote publication/runtime")

if __name__ == "__main__":
    main()
