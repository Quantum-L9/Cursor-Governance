# L9 LCTO Campaign Compilation Template v2.0.0

**Classification:** candidate for reuse/admission. **Execution:** not activated. **Authority:** none granted by this ZIP. **Purpose:** produce precise, evidence-first, collision-free LCTO campaign handoff packs faster.

This template distills reusable execution behaviors from a field-refined donor campaign, with the campaign's subject, release names, infrastructure, PR numbers, old findings and host configuration deliberately removed. It is an **authoring scaffold** with a local structural packager. It does **not** define new global L9 law, create a second CTO operating plane, replace Cursor-Governance publication, or execute any campaign.

## Shortest compilation workflow

1. Copy `examples/STARTER-CAMPAIGN.json` to your campaign workspace as `CAMPAIGN.json`. Fill the actual scope, explicit operator approval boundaries, source refs, already-closed facts, findings, earliest root blocker, exact work paths, lane assignments, gate dependencies and testable proofs. The starter intentionally fails verification until filled.
2. Independently read current target code, live GitHub PR/release/workflow heads and applicable L9 authority. Record exact source revisions and uncertainty, never inferred citations. Reuse evidence previously established until its declared recheck hinge. Resolve release/index/deployment/runtime identities separately when material.
3. Check the source locally using the template's offline authoring tool:

```sh
python3 tools/compile_campaign.py check --spec /path/to/CAMPAIGN.json
```

4. Produce a self-contained campaign folder and ZIP:

```sh
python3 tools/compile_campaign.py build \
  --spec /path/to/CAMPAIGN.json \
  --out /path/to/new-campaign-pack \
  --zip /path/to/new-campaign-pack.zip
```

5. Hand the generated ZIP to an **existing** Start Session `/lcto` session, after deliberate operator activation. The compiled `00-LCTO-LAUNCH.md` is a task brief, **not** a substitute for LCTO's host-rendered child system prompt.

Generated Markdown is derived from the single source `CAMPAIGN.json`. **Revise source and rebuild** rather than manually changing derived documents or inventing a last-minute priority addendum. The offline compiler refuses an existing populated output folder, risky path overlaps, unresolved authoring placeholders, cyclic gates, unscoped writers and false-green terminal claims.

## Output contract

A build emits the following donor-strength components: `README.md`, `00-LCTO-LAUNCH.md`, `01-SOURCE-EVIDENCE.md`, `02-CRITICAL-PATH.md`, `03-CONCURRENCY.md`, `04-DEFINITION-OF-DONE.md`, `05-PUBLICATION-SECURITY.md`, `06-FINDING-REGISTER.md`, `07-RECONCILED-FACTS.md`, `08-FINAL-RECEIPT.md`, `lanes/<id>.md` for each lane, `CAMPAIGN.json` and `MANIFEST.json` with exact digests. Lane briefs begin with the exact `repository_access` header, including read-only assurance agents with empty writable lists.

The source describes both work and *nonwork*: reserved approvals, exclusions, closed facts, read-only areas, already satisfied gates and future recheck hinges. The generated launch brief says HOLD until operator activation. It does not trigger a swarm.

## Conformance with existing owners

- **Cursor-Governance LCTO:** current `commands/lcto.md`, `governance/cto-mode/MODE.yaml` and the `ops/autonomy/cto_mode.py` adapter remain the source of live mode/child prompts/pool behavior. No text in this pack is an alternate system prompt. On the inspected 2026-11-18 revision LCTO uses a fixed reusable pool of up to five, transcript-only child reporting, publisher-owned PR remediation, CTO-only integration and operator merge authorization when required. **Re-read at activation** rather than treating this as frozen global law.
- **PR publication:** the SSOT `make pr` pathway is owned by current Cursor-Governance. Inspect its current Makefile, routing registry, publish/preflight scripts and gate before invoking a verified command with actual target `WS`, branch/base and L4 state. Publishing is distinct from merging, releasing and deploying.
- **Program Execution:** `environment/program-execution/templates/campaign-source-v2/CAMPAIGN_SOURCE.yaml` in Cursor-Governance is the authoritative *separate* direct Program Execution ingress. This document pack is an LCTO execution brief, **not** `l9.program-execution.campaign-source.v2`, a Blueprint, a PEC workspace or an alternative Program Execution compiler. When a task selects Program Execution, use its own template and validator instead of passing this JSON as that source.
- **L9 semantics:** current global authority and any applicable projection must be resolved from its owning source at an exact immutable revision. A well-formed packet is not an admitted projection, policy or architecture decision.

## Validation and safety

The included fixture `examples/SYNTHETIC-VALID.json` is fictional and structural only; no real repository, workflow or approval is asserted. Run the bundled negative-control regression suite:

```sh
python3 -m unittest discover -s tests -v
```

`build`, `check`, `verify-pack`, and `verify-template` are offline filesystem operations. They never open a PR, release, deploy, use API tokens, or claim product conformance. `tools/compile_campaign.py` is a **local documentation renderer and validator** only. `MANIFEST.json` proves bytes and completeness of this artifact, not live truth, authorization or success.

## Version design

Relative to v1.0.0, v2.0.0 retains the previous generic execution principles but adds a structured root-cause/critical-path graph, source and finding ledger, closed-fact reconciliation, actual per-lane first-position headers, acceptance proof distinctions, a single declarative campaign source, derived-document regeneration and validator negative controls. See `DESIGN-HARVEST.md` for the evidence-bound feature comparison and known donor limitations.
