# Evidence-bound design harvest

This document preserves *why* the template was hardened. It contains no old target code, secrets, production instructions, repository-specific branches, releases or PR identifiers.

| Reusable feature observed in the field-refined donor | Where the source pack expressed it | Normalized v2 template realization |
|---|---|---|
| Activation distinct from document preparation; approved work should continue without repeated questioning | `00-LCTO-LAUNCH.md`, `README.md` | Generated launch brief holds until explicit activation, then owns through all gates with only genuine reserved approvals |
| Highest causal blocker ahead of downstream version/consumer work | `01-VERIFIED-FINDING-AND-SOURCE-EVIDENCE.md`, `02-RELEASE-RECOVERY-CRITICAL-PATH.md` | Declarative `critical_path[]`, prerequisite/unlock gates and source-backed proof before downstream progression |
| Code/release/index/deployment/live state are not interchangeable | `01-VERIFIED-FINDING-AND-SOURCE-EVIDENCE.md`, `04-DEFINITION-OF-DONE.md` | Source evidence grades, gate proof requirements, stage-correct instructions and explicit skipped-test falsification |
| Independent work starts immediately while true dependencies block only successor tasks | `03-LCTO-CONCURRENCY.md` | Disjoint lane worksets, explicit lane/gate DAGs and independent assurance lanes |
| First-position repository access controls | `lanes/*.md` | Auto-generated per-lane access fences, path reservations and membership checks |
| Closed census findings should stay closed unless freshness changes | `07-CENSUS-RECONCILIATION.md` | `facts[]` with exact references and `revalidate_when`; separate source and reconciliation views |
| Findings must be disposed rather than disappearing after PR activity | `06-CHANGE-AND-EVIDENCE-REGISTER.md` | `findings[]` with terminal receipt/wake/rationale requirements |
| Existing publication mechanism must not be bypassed for convenience | `05-PUBLISH-AUTHORITY-AND-SECURITY.md` | Verified SSOT `make pr` as publication only; distinct merge/release/deploy gates |
| Final results must be an auditable integrated receipt | `04-DEFINITION-OF-DONE.md` | Generated gate ledger and terminal receipt skeleton, no premature DONE |
| Deliverable self-integrity matters | `validate_pack.py`, `MANIFEST.json` | Full digest inventory and deterministic replay of generated Markdown from one local source |

## Why the previous generic v1.0.0 was insufficient

The previous template had valuable governance prose and a basic manifest, but no `critical_path[]`, no generated **first-position** actual lane briefs, no machine-tested lane/gate DAG, no automated source-to-doc reconciliation, and no structural refusal when a positive gate skipped required execution. Its authoring YAML and Markdown could diverge. v2 makes these reusable behaviors operational without embedding the donor's product.

## Improvements beyond the donor

1. **No append-only precedence ambiguity.** The donor had a document version that carried a later reconciliation addendum; a human had to determine which prose wins. v2 uses one structured fact source and regenerates all derived sections, making old/new references consistent by construction.
2. **Actual negative-control linter.** The donor's package validator checked hashes, file presence, and first-position headers, but not dependency cycles, scope overlaps, unknown proof routes or fake PASS statuses. v2 tests these with known-bad synthetic mutations.
3. **Canonical execution owner is not shadowed.** The donor described its LCTO pool and merge controls from its then-current context. v2 leaves the child system prompt, mode registration, pool transport and approval switches with the existing live Cursor-Governance owner and explicitly rebinds at activation.
4. **Separate immutable pack from mutable execution outcomes.** v2 compiles a sealed execution handoff and a blank terminal-receipt outline. It never pre-fills “success” or rewrites the handoff to fake a result. Runtime/decision receipts are collected by the executing owner.
5. **No campaign-specific default gates.** Release, index, restore and tenant tests apply only when the actual goal needs them. The smallest acceptance graph is emitted from explicit `gates[]` and `critical_path[]` rather than a universal seven-gate ritual.
6. **Distinguishes an LCTO handoff from Program Execution input.** The existing direct `campaign-source.v2` and Blueprint/PEC route remains separately owned; this local renderer cannot be used to claim that it ran Program Execution.

## Evidence limits

The donor was an **execution-ready artifact** with its own declared source and validation limits; it contained no post-execution receipts. The campaign's success was reported by its operator, not independently reconstructed from this ZIP. These design improvements are source-derived and structurally testable; they do not claim causal proof that any individual feature made the run succeed.

The donor ZIP's SHA-256 is recorded in `MANIFEST.json` as a provenance digest. No historical source revision, merged outcome or temporary environment from that campaign is admitted as new canonical L9 law by this packaging operation.
