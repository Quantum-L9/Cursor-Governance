"""Deterministic offline positive and known-bad negative controls for authoring lint only."""
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("local_campaign_compiler", ROOT / "tools" / "compile_campaign.py")
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)
VALID = json.loads((ROOT / "examples" / "SYNTHETIC-VALID.json").read_text())

class CampaignCompilationChecks(unittest.TestCase):
    def test_synthetic_positive(self):
        self.assertEqual(mod.validate_spec(VALID), [])

    def test_unfilled_starter_rejected(self):
        data=json.loads((ROOT / "examples" / "STARTER-CAMPAIGN.json").read_text())
        self.assertTrue(any("unresolved authoring" in x for x in mod.validate_spec(data)))

    def test_write_collision(self):
        d=copy.deepcopy(VALID)
        d["lanes"][1].update(kind="writer", writable_repositories=["https://github.com/example/sample-app"],
            read_only_repositories=["https://github.com/example/source-authority"],
            write_paths={"https://github.com/example/sample-app": ["docs/example/**"]})
        self.assertTrue(any("WRITE COLLISION" in x for x in mod.validate_spec(d)))

    def test_two_disjoint_writers(self):
        d=copy.deepcopy(VALID)
        d["lanes"][1].update(kind="writer", writable_repositories=["https://github.com/example/sample-app"],
            read_only_repositories=["https://github.com/example/source-authority"],
            write_paths={"https://github.com/example/sample-app": ["docs/other/README.md"]})
        self.assertEqual(mod.validate_spec(d), [])

    def test_readonly_writer_refused(self):
        d=copy.deepcopy(VALID)
        d["lanes"][1]["write_paths"]={"https://github.com/example/sample-app":["docs/foo.md"]}
        self.assertTrue(any("assurance must have no write paths" in x for x in mod.validate_spec(d)))

    def test_gate_cycle(self):
        d=copy.deepcopy(VALID)
        d["gates"][0]["depends_on"]=["G1"]
        self.assertTrue(any("gate dependency cycle" in x for x in mod.validate_spec(d)))

    def test_lane_cycle(self):
        d=copy.deepcopy(VALID)
        d["lanes"][0]["depends_on_lanes"]=["B"]
        d["lanes"][1]["depends_on_lanes"]=["A"]
        self.assertTrue(any("lane dependency cycle" in x for x in mod.validate_spec(d)))

    def test_missing_source(self):
        d=copy.deepcopy(VALID)
        d["facts"][0]["source_ids"]=["SRC-DOES-NOT-EXIST"]
        self.assertTrue(any("source_ids missing" in x for x in mod.validate_spec(d)))

    def test_unknown_evidence_requires_resolution_gate(self):
        d=copy.deepcopy(VALID)
        d["sources"][0]["grade"]="UNKNOWN"
        self.assertTrue(any("UNKNOWN must have resolution_gate" in x for x in mod.validate_spec(d)))

    def test_false_green_skipped_step(self):
        d=copy.deepcopy(VALID)
        d["gates"][0].update(status="PASS",executed=True,skipped_required_steps=True,receipt_refs=["synthetic:receipt"])
        self.assertTrue(any("false-green" in x for x in mod.validate_spec(d)))

    def test_downstream_pass_refused(self):
        d=copy.deepcopy(VALID)
        d["gates"][1].update(status="PASS",executed=True,skipped_required_steps=False,receipt_refs=["synthetic:receipt"])
        self.assertTrue(any("prerequisite G0" in x for x in mod.validate_spec(d)))

    def test_out_of_scope_needs_reason(self):
        d=copy.deepcopy(VALID)
        d["findings"][0]["status"]="OUT_OF_SCOPE"
        self.assertTrue(any("out-of-scope requires" in x for x in mod.validate_spec(d)))

    def test_compile_pack_and_archive(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/"synthetic-pack"
            archive=Path(tmp)/"synthetic-pack.zip"
            mod.build(ROOT/"examples"/"SYNTHETIC-VALID.json",out,archive)
            self.assertEqual(mod.verify_pack(out), [])
            with ZipFile(archive) as z:
                self.assertIsNone(z.testzip())
                self.assertEqual(len([n for n in z.namelist() if n.endswith(".md") and "/lanes/" in n]),2)
            self.assertTrue((out/"lanes/B.md").read_text().startswith("```yaml\nrepository_access:\n  writable: []\n"))
            # Structural validation catches changed generated material even if someone rehashes it.
            p=out/"02-CRITICAL-PATH.md"
            p.write_text(p.read_text()+"\nmanual drift\n")
            self.assertTrue(any("manifest mismatch" in x for x in mod.verify_pack(out)))
            m=mod.load_json(out/"MANIFEST.json")
            m["files"]["02-CRITICAL-PATH.md"]=mod.sha256(p.read_bytes())
            (out/"MANIFEST.json").write_bytes(mod.normalized_json(m))
            self.assertTrue(any("render drift" in x for x in mod.verify_pack(out)))

if __name__ == "__main__":
    unittest.main()
